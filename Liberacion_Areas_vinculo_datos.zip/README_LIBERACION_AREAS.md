# Módulo «Liberación de Areas» – integrado al aplicativo IN Piura

Rama base: `claude/field-verification-desktop-app-mL0rL` · 28-sep-2026

## Qué cambia en el repo

| Archivo | Cambio |
|---|---|
| `streamlit_app.py` | +1 import, +1 opción de menú («Liberacion de Areas»), +1 ruta `elif`; catálogo vigente sin retirados |
| `database.py` | +12 códigos en `BLOQUES_RETIRADOS` (descartados en V6) |
| `requirements.txt` | + `shapely>=2.0.0` (pyproj ya estaba) |
| `liberacion_areas/` | Paquete nuevo: `la_core`, `la_db`, `la_kobo`, `la_export`, `pagina`, `la_schema.sql` |
| `datos/unidades_liberacion_areas.csv` | Catálogo V6: 117 bloques + 60 lotes SUS, con asistente (mismo CSV de los formularios Kobo) |
| `tests/test_liberacion_areas.py` | 8 pruebas (lógica + integración PostgreSQL con el DDL real de `database.py`) |
| `tests/casos_prueba_liberacion_areas.json` | Envíos ficticios F-LA-01/02/03/04/06 |

Ninguna tabla ni fila existente se borra; el único cambio sobre datos existentes es `activo = 0` en los 12 bloques retirados.

## Cómo se enlaza con lo existente

- **Conexión**: la misma `DATABASE_URL` de `st.secrets`, con `sslmode=require`, keepalives y reintentos como `database.py`. Una conexión por ejecución de la página.
- **Migración**: al abrir la página, `inicializar_la()` crea las tablas `la_*` si faltan (aditivo, idempotente), carga el catálogo V6 si `la_unidades` está vacía y enlaza con `bloques`.
- **Bloques**: `la_unidades.bloque_id → bloques(id)` para cada bloque V6 y `la_unidades.bloque_ref_id → bloques(id)` para cada lote SUS, por **igualdad exacta de código** (mismo criterio que `bloque_lookup.py`). Llaves `ON DELETE SET NULL`, como en el Paso 6.
- **Vista `la_v_conciliacion_bloques`**: compara el catálogo V6 con la tabla `bloques` (OK / AREA_DISTINTA / NO_EXISTE_EN_APP / RETIRADO_EN_APP / ACTIVO_EN_APP_FUERA_DE_V6). Se muestra en la pestaña 6.
- **Vista `la_v_antecedentes_paso6`**: último registro de `verificacion_campo_odk` por bloque (tenencia, n.° de predios, titular, aceptación, acta, dictamen) como consulta inicial a prediantes, visible en la matriz predial.
- **KoboToolbox**: reutiliza `odk_kobo.KoBoClient` (paginación completa, SSL, token solo a su dominio) y los secrets `KOBO_TOKEN` / `KOBO_SERVER` que ya usa la página «ODK / KoBoToolbox». Los formularios F-LA se listan desde la cuenta; no hace falta copiar UID.
- **Fotos y actas**: versión mediana en `la_adjuntos` (BYTEA), igual que `adjuntos_odk`; queda la URL del original.

## Bloques retirados (catálogo vigente V6)

Los 117 bloques V6 coinciden en código, distrito y área con `BLOQUES_V5` de `streamlit_app.py`. Los 12 bloques del catálogo del aplicativo que ya no están en V6 (`1, 7, 25, 29, 32, 33, 46, 48, 68, 74, 75, M18B5`) se agregaron a `BLOQUES_RETIRADOS` en `database.py` (confirmado el 28-sep-2026):

- En el siguiente arranque, `inicializar_bd()` los marca con `activo = 0`: dejan de listarse en todo el aplicativo, pero sus filas y todo lo registrado para ellos (inspecciones, diagnósticos, etc.) quedan intactos. Es reversible: basta quitarlos de la tupla y poner `activo = 1`.
- `streamlit_app.py` separa `BLOQUES_V5_COMPLETO` (todos, para resolver microcuenca y zona de registros ya ingresados) de `BLOQUES_V5` (vigentes: 117), que alimenta desplegables, plantillas y la sincronización. Así un bloque retirado no se vuelve a ofrecer ni aparece como «faltante».

## Pruebas

```bash
python -m pytest tests/test_liberacion_areas.py -q
LA_TEST_DB="postgresql://…/base_vacia_de_pruebas" python -m pytest tests/test_liberacion_areas.py -q
```

Resultado: 8/8. La suite completa queda igual que antes del cambio (las 15 fallas previas de `test_fichas_dt.py` y `test_resumenes_bloques.py` se deben a que los 117 libros Excel no vienen en el ZIP de la rama).

---

## Actualización 30-sep-2026 · Tres vías de registro, plantillas, edición y reportes

### Tres vías de registro equivalentes

| Vía | Dónde | Cómo entra al sistema |
|---|---|---|
| 1. KoboToolbox | Pestaña **3 · Importar KoboToolbox** (API o exportación XLSX/JSON) | Sin cambios |
| 2. Digitación en el aplicativo | Pestaña **1 · Registro en campo** | Formulario construido con los mismos campos; coordenadas en UTM 17S |
| 3. Plantilla Excel ANIN | Pestaña **2 · Plantillas Excel / Kobo** (descargar → llenar → importar) | Una hoja por formulario + hojas de detalle |

Las tres usan un único diccionario de campos (`liberacion_areas/la_campos.py`) y terminan en el mismo envío
«aplanado» que produce Kobo, que pasa por `la_core.validar_envio` y `la_db.importar`: mismas reglas (catálogo V6,
asistente asignado, rango UTM 17S, lotes SUS, checklist de actas) y mismos estados NUEVO / DUPLICADO / OBSERVADO.
El origen de cada envío queda en `la_envios_raw.origen` (KOBO / APP / PLANTILLA).

- **Plantilla Excel** (`la_plantillas.generar_plantilla_excel`): F-LA-01 a F-LA-06, `F-LA-03_puntos`,
  `F-LA-03_vertices_SUS`, `F-LA-04_firmantes`, catálogo de unidades e instrucciones; listas desplegables, validación
  de rangos UTM, fechas y DNI. Puede prepararse por asistente (el desplegable muestra solo sus unidades).
  Re-importar el mismo archivo no duplica: cada fila tiene un identificador determinista (`xls-…`).
- **XLSForm para Kobo** (`la_plantillas.paquete_kobo`): ZIP con F-LA-01/02/03/04/06 y `unidades.csv`, generado del
  mismo diccionario (validado con pyxform). Úselo si aún no están desplegados o si cambió el catálogo; si ya tiene
  formularios F-LA en la cuenta, compare los nombres de campo antes de reemplazarlos.
- **F-LA-05** (búsqueda documental) se registra en el aplicativo o en la plantilla (no tiene formulario Kobo).

### Historial, edición, eliminación y restauración (pestaña 4)

- Lista por formulario con filtros (unidad, asistente, estado, origen), **Editar** / **Eliminar** con confirmación,
  detalle con fotos y exportación a Excel ANIN — igual que en Diagnóstico Territorial y Social.
- **Editar** carga el registro (de cualquier vía) en «Registro en campo»; al guardar se re-valida, se conserva el
  mismo identificador y sus fotos, y se recalculan los estados LA.
- **Eliminar** guarda antes una copia completa en la tabla nueva `la_bitacora`; las fotos no se borran. Los
  registros eliminados (envíos, documentos, predios) se pueden **Restaurar**. La bitácora se puede exportar.
- **Matriz predial**: ahora también se editan nombre, área dentro de la unidad, **núcleo**, alertas; y se puede
  eliminar un predio sin registros asociados. Cada cambio queda en la bitácora.

### Reportes (pestaña 7)

- Excel consolidado ANIN (resumen, matriz, semáforo, avance, cada formulario, documentos, titulares **sin DNI ni
  celular**, observados), filtrable por asistente o distrito.
- Expediente preliminar PDF por unidad y ZIP con los expedientes de todas las unidades con predios.

### Migración

Solo aditiva (se aplica sola al abrir la página): columnas `origen`, `editado`, `editado_por` en `la_envios_raw` y
`editado`, `editado_por` en `la_documentos`; tabla nueva `la_bitacora`. Ningún registro existente se borra ni se
modifica (salvo rellenar `origen` de los envíos ya importados).

### Pruebas

```bash
python -m pytest tests/test_liberacion_areas.py tests/test_liberacion_areas_registro.py -q
LA_TEST_DB="postgresql://…/base_vacia_de_pruebas" python -m pytest tests -q
```

---

## Actualización 04-oct-2026 · Vínculo automático de datos por unidad (aplicativo y KoboToolbox)

### Qué se corrige

| Problema | Causa | Corrección |
|---|---|---|
| Al elegir el bloque no aparecían ubicación ni centros poblados | La pestaña solo mostraba provincia y asistente | Ficha de la unidad: provincia, distrito, microcuenca, zona, área, centroide UTM 17S, MSAVI 2024, CCPP INEI con población, predios ya registrados y antecedente Paso 6 |
| F-LA-01 digitado en el aplicativo guardaba la unidad como `['27']` | El multiselect entrega una lista y se convertía con `str()` | `la_campos._normalizar` une la lista: `27 3` (igual que Kobo) |
| Formularios Kobo «no vinculan» | Los cálculos eran invisibles y dependen de `unidades.csv` cargado como multimedia | Nota visible con la ficha de la unidad, CSV ampliados y botón para subirlos y redesplegar |

### Aplicativo – pestaña «1 · Registro en campo»

- **Unidad → ficha** (`la_vinculo.ficha_unidad`); en lotes SUS, microcuenca y centroide vienen del bloque de referencia.
- **Asistente**: si está vacío, se toma el asignado a la unidad en el catálogo V6.
- **Predio registrado**: lista de predios de la unidad (titular, área, estado LA); «Predio nuevo» sugiere el siguiente número.
- **F-LA-01**: centro poblado de lista (CCPP INEI de las unidades elegidas) + «Otro»; comunidad precargada si ya fue registrada.
- **F-LA-04**: al elegir el predio se precargan tipo de acta (A-03 comunal / A-04), área comprometida y firmantes (titular, cónyuge o presidente comunal) desde la última ficha F-LA-02.
- **F-LA-06**: provincia → distrito en cascada; distancia al bloque V6 más cercano calculada desde el punto central.
- Lo precargado nunca reemplaza un valor escrito por el usuario. Todos los envíos (Kobo, aplicativo, plantilla) reciben `u_microcuenca`, `u_zona`, `u_area_ha`, `u_utm_este`, `u_utm_norte`, `u_msavi`, `u_ccpp` en `core.validar_envio`.

### KoboToolbox

- Tres archivos multimedia (los mismos para todos los F-LA): `unidades.csv` (ampliado), `centros_poblados.csv` y `predios.csv`.
- Nota visible tras elegir la unidad; F-LA-01 filtra los CCPP por las unidades elegidas; F-LA-02/03/04 eligen el predio de `predios.csv` (o «nuevo», con número sugerido y control de duplicados).
- Pestaña 2 › **Sincronizar catálogos con KoboToolbox**: sube los tres CSV a los formularios F-LA y los redespliega (API v2: `assets/{uid}/files/`, `deployment/`). Los envíos no se tocan.
- Los XLSForm se validaron con pyxform + ODK Validate y la lógica (filtros, cálculos, restricción de N.° de predio) con JavaRosa.
- **Requiere reemplazar los formularios F-LA desplegados** con el paquete nuevo (pestaña 2) una sola vez; luego basta sincronizar.

### Plantilla Excel (`LA-2026.10b`)

- Catálogo con microcuenca, zona, centroide, MSAVI y CCPP; columnas grises «Ref.» con BUSCARV en cada hoja de formulario (el importador las ignora).

### Archivos

`liberacion_areas/la_vinculo.py` (nuevo), `liberacion_areas/generar_atributos_bloques.py` (nuevo) → `datos/atributos_bloques_v6.csv`
(117 bloques, desde `BLOQUES_V5`, `traspaso_msavi_117.json` y `centros_poblados.py`), `tests/test_liberacion_areas_vinculo.py` (17 pruebas).
Sin migración de base de datos: no se crean ni modifican tablas.
