# -*- coding: utf-8 -*-
"""
Genera datos/atributos_bloques_v6.csv: atributos territoriales de cada bloque V6 que el módulo de
Liberación de Áreas vincula automáticamente al elegir una unidad (aplicativo y formularios Kobo).

Fuentes (todas del repositorio, sin datos inventados):
  - streamlit_app.py → BLOQUES_V5 (microcuenca, zona, área, centroide UTM 17S, MSAVI 2024), leído con `ast`
    sin ejecutar el aplicativo.
  - datos/traspaso_msavi_117.json → superficie y % bajo el umbral MSAVI 0.4976.
  - centros_poblados.py → centros poblados INEI asociados a cada bloque y su población (CPV 2017).
  - datos/unidades_liberacion_areas.csv → catálogo V6 (117 bloques + lotes SUS).

Uso:  python -m liberacion_areas.generar_atributos_bloques
Vuelva a ejecutarlo cuando cambie el catálogo de bloques o el de centros poblados.
"""
from __future__ import annotations

import ast
import csv
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DESTINO = RAIZ / "datos" / "atributos_bloques_v6.csv"
COLUMNAS = ["codigo", "microcuenca", "zona", "area_ha", "utm_este", "utm_norte", "msavi_2024",
            "bajo_umbral_ha", "bajo_umbral_pct", "n_ccpp", "poblacion_ccpp", "ccpp"]


def bloques_v5() -> dict[str, dict]:
    """BLOQUES_V5 de streamlit_app.py (lista literal de tuplas), sin importar el aplicativo."""
    arbol = ast.parse((RAIZ / "streamlit_app.py").read_text(encoding="utf-8"))
    for nodo in arbol.body:
        if isinstance(nodo, ast.Assign) and any(getattr(t, "id", "") == "BLOQUES_V5" for t in nodo.targets) \
                and isinstance(nodo.value, ast.List):
            filas = ast.literal_eval(nodo.value)
            return {str(b[1]): {"microcuenca": b[2], "area_ha": b[3], "utm_este": b[8], "utm_norte": b[9],
                                "msavi_2024": b[10], "zona": b[11] if len(b) > 11 else ""} for b in filas}
    raise RuntimeError("No se encontró la lista literal BLOQUES_V5 en streamlit_app.py")


def main() -> int:
    sys.path.insert(0, str(RAIZ))
    from centros_poblados import datos_bloque  # noqa: E402

    v5 = bloques_v5()
    msavi = {str(b["bloque"]): b for b in json.loads((RAIZ / "datos" / "traspaso_msavi_117.json")
                                                     .read_text(encoding="utf-8"))["bloques"]}
    with open(RAIZ / "datos" / "unidades_liberacion_areas.csv", encoding="utf-8") as f:
        bloques = [r["name"] for r in csv.DictReader(f) if r["tipo_unidad"] == "bloque"]
    faltan = []
    filas = []
    for cod in bloques:
        b = v5.get(cod)
        if b is None:
            faltan.append(cod)
            b = {}
        m = msavi.get(cod, {})
        cp = datos_bloque(cod)
        filas.append({
            "codigo": cod, "microcuenca": b.get("microcuenca", ""), "zona": b.get("zona", ""),
            "area_ha": b.get("area_ha", ""), "utm_este": b.get("utm_este", ""), "utm_norte": b.get("utm_norte", ""),
            "msavi_2024": round(float(b["msavi_2024"]), 4) if b.get("msavi_2024") else "",
            "bajo_umbral_ha": m.get("bajo_umbral_ha", ""), "bajo_umbral_pct": m.get("bajo_umbral_pct", ""),
            "n_ccpp": len(cp["centros_poblados"]), "poblacion_ccpp": cp["poblacion_total"] or "",
            "ccpp": " · ".join(cp["centros_poblados"]),
        })
    with open(DESTINO, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNAS)
        w.writeheader()
        w.writerows(filas)
    print(f"{len(filas)} bloques escritos en {DESTINO.relative_to(RAIZ)}")
    if faltan:
        print("Sin atributos en BLOQUES_V5:", ", ".join(faltan))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
