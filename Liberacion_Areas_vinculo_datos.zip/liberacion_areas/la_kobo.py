# -*- coding: utf-8 -*-
"""KoboToolbox para el módulo de Liberación de Áreas.
Reutiliza el cliente del aplicativo (odk_kobo.KoBoClient: paginación completa, SSL verificado,
token enviado solo al dominio del servidor) y los mismos secrets: KOBO_TOKEN y KOBO_SERVER."""
from __future__ import annotations

import re

import pandas as pd

from . import la_core as core

SERVIDOR_POR_DEFECTO = "https://kf.kobotoolbox.org"


def cliente(servidor: str | None = None, token: str | None = None):
    """KoBoClient con los secrets del aplicativo (KOBO_SERVER, KOBO_TOKEN).

    El token se busca igual que en la página «ODK / KoBoToolbox»: nivel superior de los
    secrets, sección [kobo] o variable de entorno; si no está, el escrito en esta sesión."""
    from odk_kobo import KoBoClient, normalizar_token, secreto_kobo, token_kobo
    servidor = servidor or secreto_kobo("KOBO_SERVER", SERVIDOR_POR_DEFECTO)
    token = normalizar_token(token) if token else token_kobo()[0]
    if not token:
        raise ValueError("Falta KOBO_TOKEN en los secrets del aplicativo.")
    return KoBoClient(servidor, token)


def formularios_la(kobo) -> list[dict]:
    """Formularios desplegados cuyo nombre corresponde a la serie F-LA."""
    return [f for f in kobo.listar_formularios() if "F-LA" in f.get("nombre", "").upper()] or kobo.listar_formularios()


def leer_exportacion_xlsx(archivo) -> list[dict]:
    """Exportación XLSX de Kobo ('XML values and headers', grupos con separador '/').
    Hoja 1 = envíos; hojas siguientes = repeats (unidas por _parent_index)."""
    hojas = pd.read_excel(archivo, sheet_name=None, dtype=str)
    nombres = list(hojas)
    principal = hojas[nombres[0]].where(pd.notna(hojas[nombres[0]]), None).to_dict("records")
    for r in principal:
        r["_index"] = int(float(r["_index"])) if r.get("_index") else None
    repeats = {}
    for n in nombres[1:]:
        filas = hojas[n].where(pd.notna(hojas[n]), None).to_dict("records")
        for f in filas:
            f["_parent_index"] = int(float(f["_parent_index"])) if f.get("_parent_index") else None
        repeats[n.split("/")[-1]] = [core.aplanar(f) for f in filas]
    return core.unir_repeats_xlsx(principal, repeats)


def _slug(t: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", t or "")


def descargar_adjuntos(kobo, registro: dict) -> list[dict]:
    """Descarga fotos y páginas de actas (versión mediana, como el Paso 6) con nombre
    {cod_predio}_{campo}_{n}.{ext}. Devuelve dicts listos para la_db.guardar_adjunto."""
    base = _slug(registro.get("cod_predio") or registro.get("cod_unidad") or registro.get("cod_vivero") or "SIN_COD")
    cont: dict[str, int] = {}
    out = []
    for a in registro.get("_attachments", []) or []:
        campo = (a.get("question_xpath") or a.get("filename", "adjunto")).split("/")[-1]
        cont[campo] = cont.get(campo, 0) + 1
        mime = a.get("mimetype", "image/jpeg")
        ext = (mime.split("/")[-1] or "jpg").replace("jpeg", "jpg")
        url = a.get("download_medium_url") or a.get("download_large_url") or a.get("download_url")
        contenido = kobo.descargar(url) if url else None
        out.append({"campo": campo, "nombre": f"{base}_{_slug(campo)}_{cont[campo]}.{ext}", "mimetype": mime,
                    "url": a.get("download_url") or url, "contenido": contenido})
    return out


# ------------------------------------------------------------------ sincronización de archivos multimedia
def _peticion(kobo, metodo: str, endpoint: str, cuerpo: bytes | None = None, tipo: str | None = None):
    """Petición autenticada a la API v2 (solo al dominio del servidor configurado, SSL verificado)."""
    import json
    import urllib.error
    import urllib.request
    url = endpoint if endpoint.startswith("http") else f"{kobo.url_servidor}/api/v2/{endpoint.lstrip('/')}"
    if not kobo._url_permitida(url):
        raise ConnectionError(f"URL fuera del servidor configurado: {url}")
    cab = {"Authorization": f"Token {kobo.token_api}", "Accept": "application/json"}
    if tipo:
        cab["Content-Type"] = tipo
    req = urllib.request.Request(url, data=cuerpo, headers=cab, method=metodo)
    try:
        with urllib.request.urlopen(req, context=kobo.ssl_context, timeout=kobo.timeout) as r:
            datos = r.read()
    except urllib.error.HTTPError as e:
        detalle = e.read().decode("utf-8", errors="replace")[:300]
        if e.code in (401, 403):
            raise ConnectionError("Token sin permiso para modificar el formulario (se requiere ser propietario o editor)")
        raise ConnectionError(f"Error HTTP {e.code}: {detalle}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"Error de conexión: {e.reason}")
    return json.loads(datos.decode("utf-8")) if datos else {}


def _multipart(campos: dict[str, str], archivo: tuple[str, str, bytes, str]) -> tuple[bytes, str]:
    import uuid
    limite = f"----ANIN{uuid.uuid4().hex}"
    partes = []
    for k, v in campos.items():
        partes.append(f'--{limite}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode("utf-8"))
    nombre_campo, nombre, contenido, mime = archivo
    partes.append(f'--{limite}\r\nContent-Disposition: form-data; name="{nombre_campo}"; filename="{nombre}"\r\n'
                  f"Content-Type: {mime}\r\n\r\n".encode("utf-8") + contenido + b"\r\n")
    partes.append(f"--{limite}--\r\n".encode("utf-8"))
    return b"".join(partes), f"multipart/form-data; boundary={limite}"


def archivos_media_formulario(kobo, uid: str) -> list[dict]:
    """Archivos multimedia (form_media) cargados en el formulario: [{uid, nombre}]."""
    import urllib.parse
    d = _peticion(kobo, "GET", f"assets/{urllib.parse.quote(uid, safe='')}/files/?file_type=form_media&format=json")
    out = []
    for f in d.get("results", []):
        meta = f.get("metadata") or {}
        out.append({"uid": f.get("uid"), "nombre": meta.get("filename") or f.get("description") or ""})
    return out


def subir_media(kobo, uid: str, archivos: dict[str, bytes]) -> list[str]:
    """Reemplaza (borra y vuelve a subir) los CSV multimedia del formulario. Devuelve los nombres subidos."""
    import json
    import urllib.parse
    q = urllib.parse.quote(uid, safe="")
    existentes = {f["nombre"]: f["uid"] for f in archivos_media_formulario(kobo, uid)}
    subidos = []
    for nombre, contenido in archivos.items():
        if nombre in existentes and existentes[nombre]:
            _peticion(kobo, "DELETE", f"assets/{q}/files/{existentes[nombre]}/")
        cuerpo, tipo = _multipart({"file_type": "form_media", "description": nombre,
                                   "metadata": json.dumps({"filename": nombre})},
                                  ("content", nombre, contenido, "text/csv"))
        _peticion(kobo, "POST", f"assets/{q}/files/", cuerpo, tipo)
        subidos.append(nombre)
    return subidos


def redesplegar(kobo, uid: str) -> bool:
    """Vuelve a desplegar la versión vigente del formulario para que KoboCollect/Enketo tomen los CSV nuevos.
    Los envíos ya recibidos no se modifican."""
    import json
    import urllib.parse
    q = urllib.parse.quote(uid, safe="")
    asset = _peticion(kobo, "GET", f"assets/{q}/?format=json")
    if not asset.get("has_deployment"):
        return False
    _peticion(kobo, "PATCH", f"assets/{q}/deployment/?format=json",
              json.dumps({"active": True, "version_id": asset.get("version_id")}).encode("utf-8"), "application/json")
    return True


def sincronizar_catalogos(kobo, uids: list[str], archivos: dict[str, bytes]) -> list[dict]:
    """Sube unidades.csv, centros_poblados.csv y predios.csv a cada formulario F-LA y lo vuelve a desplegar.
    Devuelve un resumen por formulario (ok / error) sin detenerse ante el primer fallo."""
    resumen = []
    for uid in uids:
        try:
            subidos = subir_media(kobo, uid, archivos)
            redesp = redesplegar(kobo, uid)
            resumen.append({"uid": uid, "estado": "OK", "archivos": ", ".join(subidos),
                            "redesplegado": "sí" if redesp else "no (formulario sin desplegar)"})
        except Exception as e:  # noqa: BLE001 – se informa por formulario
            resumen.append({"uid": uid, "estado": "ERROR", "archivos": "", "redesplegado": "", "detalle": str(e)})
    return resumen
