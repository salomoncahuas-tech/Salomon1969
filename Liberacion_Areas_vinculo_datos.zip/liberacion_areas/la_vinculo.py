# -*- coding: utf-8 -*-
"""
Vínculo automático de datos por unidad (bloque V6 / lote SUS) – Liberación de Áreas, IN Piura.

Al elegir una unidad, el aplicativo y los formularios Kobo recuperan sin digitar:
  · ubicación: provincia, distrito, microcuenca, zona de evaluación, área, centroide UTM WGS84 17S;
  · estado del ecosistema: MSAVI 2024 y superficie bajo el umbral 0.4976;
  · centros poblados INEI asociados (CPV 2017) con su población y coordenadas;
  · para un lote SUS, los datos de su bloque de referencia.

Fuentes: datos/atributos_bloques_v6.csv (generado por generar_atributos_bloques.py) y centros_poblados.py.
Funciones puras (sin Streamlit ni base de datos): las usan la página, la validación de envíos y la
generación de los archivos multimedia de Kobo (unidades.csv, centros_poblados.csv, predios.csv).
"""
from __future__ import annotations

import csv
import io
import math
import re
import sys
import unicodedata
from functools import lru_cache
from pathlib import Path

from . import la_core as core

RAIZ = Path(__file__).resolve().parent.parent
CSV_ATRIBUTOS = RAIZ / "datos" / "atributos_bloques_v6.csv"
SEP_CCPP = " · "
OTRO = "otro"

# Campos que se agregan al envío (prefijo u_ para no chocar con los campos del formulario).
CAMPOS_VINCULO = ("u_microcuenca", "u_zona", "u_area_ha", "u_utm_este", "u_utm_norte", "u_msavi", "u_ccpp")


# ------------------------------------------------------------------ fuentes
def _num(v):
    return core._num(v)


@lru_cache(maxsize=1)
def atributos() -> dict[str, dict]:
    """{codigo_bloque: atributos} desde datos/atributos_bloques_v6.csv."""
    if not CSV_ATRIBUTOS.exists():
        return {}
    with open(CSV_ATRIBUTOS, encoding="utf-8") as f:
        return {r["codigo"]: r for r in csv.DictReader(f)}


@lru_cache(maxsize=1)
def _catalogo_cp() -> dict:
    if str(RAIZ) not in sys.path:
        sys.path.insert(0, str(RAIZ))
    try:
        from centros_poblados import CENTROS_POBLADOS_BLOQUE
    except ImportError:  # pragma: no cover
        return {}
    return CENTROS_POBLADOS_BLOQUE


def slug(texto) -> str:
    """'Rincón de Geraldo' → 'rincon_de_geraldo' (nombre de opción válido en Kobo)."""
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "_", t).strip("_")


def ccpp_bloque(codigo: str) -> list[dict]:
    """Centros poblados INEI asociados al bloque: [{nombre, poblacion, viviendas, tipo, este, norte}]."""
    d = _catalogo_cp().get(str(codigo)) or {}
    demo = {x["centro_poblado"]: x for x in d.get("demografia", [])}
    out = []
    for n in d.get("centros_poblados", []):
        x = demo.get(n, {})
        out.append({"nombre": n, "poblacion": x.get("poblacion_total"), "viviendas": x.get("viviendas"),
                    "tipo": x.get("tipo"), "este": x.get("utm_este"), "norte": x.get("utm_norte")})
    return out


@lru_cache(maxsize=1)
def nombres_ccpp_por_slug() -> dict[str, str]:
    """{slug: nombre oficial} de todos los centros poblados del catálogo (para traducir los códigos de Kobo)."""
    out = {}
    for d in _catalogo_cp().values():
        for n in d.get("centros_poblados", []):
            out.setdefault(slug(n), n)
    return out


def bloque_base(codigo: str | None, catalogo: dict[str, dict]) -> str | None:
    """Bloque cuyos atributos se usan: el mismo bloque o, para un lote SUS, su bloque de referencia."""
    if not codigo:
        return None
    u = catalogo.get(codigo, {})
    if u.get("tipo_unidad") == "lote_sus" and u.get("bloque_ref"):
        return str(u["bloque_ref"])
    return str(codigo)


# ------------------------------------------------------------------ ficha de la unidad
def ficha_unidad(codigo: str | None, catalogo: dict[str, dict]) -> dict:
    """Todos los datos vinculados a una unidad. Vacío si la unidad no está en el catálogo."""
    if not codigo or codigo not in catalogo:
        return {}
    u = catalogo[codigo]
    base = bloque_base(codigo, catalogo)
    a = atributos().get(base, {})
    ccpp = ccpp_bloque(base)
    area = _num(u.get("area_ha")) or _num(a.get("area_ha"))
    return {
        "codigo": codigo, "label": u.get("label") or codigo, "tipo_unidad": u.get("tipo_unidad"),
        "provincia": str(u.get("provincia") or "").title(), "distrito": _titulo_distrito(u.get("distrito")),
        "provincia_cod": u.get("provincia"), "distrito_cod": u.get("distrito"),
        "bloque_ref": u.get("bloque_ref") if u.get("tipo_unidad") == "lote_sus" else None,
        "bloque_base": base, "microcuenca": a.get("microcuenca") or "", "zona": a.get("zona") or "",
        "area_ha": area, "area_bloque_ha": _num(a.get("area_ha")),
        "utm_este": _num(a.get("utm_este")), "utm_norte": _num(a.get("utm_norte")),
        "centroide_de": "bloque de referencia" if u.get("tipo_unidad") == "lote_sus" else "bloque",
        "msavi_2024": _num(a.get("msavi_2024")), "bajo_umbral_ha": _num(a.get("bajo_umbral_ha")),
        "bajo_umbral_pct": _num(a.get("bajo_umbral_pct")),
        "posicion_sus": u.get("posicion_sus"),
        "asistente": u.get("asistente"), "asistente_nombre": u.get("asistente_nombre"),
        "ccpp": ccpp, "poblacion_ccpp": sum(int(c["poblacion"] or 0) for c in ccpp) or None,
    }


_DISTRITOS = {"frias": "Frías", "chulucanas": "Chulucanas", "canchaque": "Canchaque", "huarmaca": "Huarmaca",
              "huancabamba": "Huancabamba", "lalaquiz": "Lalaquiz", "san_miguel_de_el_faique": "San Miguel de El Faique",
              "buenos_aires": "Buenos Aires", "chalaco": "Chalaco", "morropon": "Morropón", "salitral": "Salitral",
              "san_juan_de_bigote": "San Juan de Bigote", "santa_catalina_de_mossa": "Santa Catalina de Mossa",
              "santo_domingo": "Santo Domingo", "yamango": "Yamango"}
_PROVINCIAS = {"ayabaca": "Ayabaca", "huancabamba": "Huancabamba", "morropon": "Morropón"}


def _titulo_distrito(cod) -> str:
    c = slug(cod)
    return _DISTRITOS.get(c, str(cod or "").replace("_", " ").title())


def distritos_ambito(catalogo: dict[str, dict]) -> list[tuple[str, str, str]]:
    """[(codigo_distrito, etiqueta, codigo_provincia)] de las unidades del catálogo (para listas en cascada)."""
    vistos = {}
    for u in catalogo.values():
        d, p = u.get("distrito"), u.get("provincia")
        if d and d not in vistos:
            vistos[d] = (d, _titulo_distrito(d), p)
    return sorted(vistos.values(), key=lambda x: (str(x[2]), x[1]))


def provincias_ambito(catalogo: dict[str, dict]) -> list[tuple[str, str]]:
    ps = sorted({u.get("provincia") for u in catalogo.values() if u.get("provincia")})
    return [(p, _PROVINCIAS.get(p, str(p).title())) for p in ps]


def ccpp_de_unidades(codigos, catalogo: dict[str, dict]) -> list[dict]:
    """Centros poblados asociados a una o varias unidades (sin repetir), con las unidades a que pertenecen."""
    out: dict[str, dict] = {}
    for cod in codigos or []:
        for c in ccpp_bloque(bloque_base(cod, catalogo) or ""):
            x = out.setdefault(c["nombre"], {**c, "unidades": []})
            x["unidades"].append(cod)
    return list(out.values())


def resumen_texto(f: dict) -> str:
    """Una línea con los datos vinculados (la misma que muestra la nota del formulario Kobo)."""
    if not f:
        return ""
    partes = [f"{f['provincia']} / {f['distrito']}"]
    if f.get("microcuenca"):
        partes.append(f"microcuenca {f['microcuenca']}")
    if f.get("zona"):
        partes.append(f"zona {f['zona']}")
    if f.get("area_ha"):
        partes.append(f"{f['area_ha']:,.2f} ha")
    if f.get("utm_este") and f.get("utm_norte"):
        partes.append(f"centroide E {f['utm_este']:,.0f} · N {f['utm_norte']:,.0f}")
    partes.append("CCPP: " + (SEP_CCPP.join(c["nombre"] for c in f.get("ccpp", [])) or "sin CP INEI asociado"))
    return " | ".join(partes)


# ------------------------------------------------------------------ cálculos que ahorran digitación
def bloque_mas_cercano(este, norte, catalogo: dict[str, dict] | None = None) -> tuple[str | None, float | None]:
    """Bloque V6 cuyo centroide está más cerca del punto (UTM 17S) → (código, distancia en km)."""
    e, n = _num(este), _num(norte)
    if e is None or n is None:
        return None, None
    mejor, dmin = None, None
    for cod, a in atributos().items():
        if catalogo is not None and cod not in catalogo:
            continue
        be, bn = _num(a.get("utm_este")), _num(a.get("utm_norte"))
        if be is None or bn is None:
            continue
        d = math.hypot(be - e, bn - n)
        if dmin is None or d < dmin:
            mejor, dmin = cod, d
    return mejor, (round(dmin / 1000, 2) if dmin is not None else None)


def siguiente_n_predio(numeros) -> int:
    nums = [int(x) for x in (_num(v) for v in (list(numeros) if numeros is not None else [])) if x is not None and x > 0]
    return (max(nums) + 1) if nums else 1


def completar_envio(form_id: str, reg: dict, catalogo: dict[str, dict]) -> dict:
    """Agrega al envío los datos vinculados que no vinieron del formulario (las tres vías: Kobo, aplicativo y
    plantilla). Nunca sobrescribe un valor capturado en campo."""
    unidad = reg.get("cod_unidad") or reg.get("unidad")
    if form_id == "f_la_01_reunion" and reg.get("unidades"):
        unidad = str(reg["unidades"]).split()[0]
    f = ficha_unidad(unidad, catalogo) if form_id != "f_la_06_vivero" else {}
    if f:
        valores = {"u_microcuenca": f["microcuenca"], "u_zona": f["zona"], "u_area_ha": f["area_ha"],
                   "u_utm_este": f["utm_este"], "u_utm_norte": f["utm_norte"], "u_msavi": f["msavi_2024"],
                   "u_ccpp": SEP_CCPP.join(c["nombre"] for c in f["ccpp"])}
        for k, v in valores.items():
            if reg.get(k) in (None, "") and v not in (None, ""):
                reg[k] = v
        for k, src in (("provincia", "provincia_cod"), ("distrito", "distrito_cod")):
            if not reg.get(k) and f.get(src):
                reg[k] = f[src]
    # F-LA-01: en Kobo el centro poblado llega como código (slug) de centros_poblados.csv → nombre oficial;
    # «otro» se reemplaza por el texto escrito en centro_poblado_otro.
    cp = reg.get("centro_poblado")
    if cp == OTRO:
        if reg.get("centro_poblado_otro"):
            reg["centro_poblado"] = reg["centro_poblado_otro"]
    elif cp and cp in nombres_ccpp_por_slug():
        reg["centro_poblado"] = nombres_ccpp_por_slug()[cp]
    # F-LA-06: distancia al bloque más cercano calculada desde el punto central
    if form_id == "f_la_06_vivero" and reg.get("gps_centro"):
        pt = core.parse_geopoint(reg.get("gps_centro"))
        if pt:
            cod, km = bloque_mas_cercano(pt["este"], pt["norte"], catalogo or None)
            if cod:
                reg.setdefault("bloque_cercano", cod)
                if reg.get("dist_bloques_km") in (None, ""):
                    reg["dist_bloques_km"] = km
    return reg


# ------------------------------------------------------------------ archivos multimedia de Kobo
def _csv(filas: list[dict], cols: list[str]) -> bytes:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore", lineterminator="\n")
    w.writeheader()
    for r in filas:
        w.writerow({k: ("" if r.get(k) is None or (isinstance(r.get(k), float) and math.isnan(r.get(k))) else r.get(k))
                    for k in cols})
    return buf.getvalue().encode("utf-8")


COLS_UNIDADES = ["name", "label", "provincia", "distrito", "tipo_unidad", "bloque_ref", "area_ha", "area_bloque_ha",
                 "posicion_sus", "asistente", "asistente_nombre", "microcuenca", "zona", "utm_este", "utm_norte",
                 "msavi", "ccpp", "resumen"]


def filas_unidades(catalogo: dict[str, dict]) -> list[dict]:
    filas = []
    for cod, r in sorted(catalogo.items()):
        f = ficha_unidad(cod, catalogo)
        filas.append({"name": cod, "label": r.get("label") or cod, "provincia": r.get("provincia"),
                      "distrito": r.get("distrito"), "tipo_unidad": r.get("tipo_unidad"), "bloque_ref": r.get("bloque_ref"),
                      "area_ha": r.get("area_ha"), "area_bloque_ha": r.get("area_bloque_ha"),
                      "posicion_sus": r.get("posicion_sus"), "asistente": r.get("asistente"),
                      "asistente_nombre": r.get("asistente_nombre"), "microcuenca": f.get("microcuenca"),
                      "zona": f.get("zona"), "utm_este": f.get("utm_este"), "utm_norte": f.get("utm_norte"),
                      "msavi": f.get("msavi_2024"), "ccpp": SEP_CCPP.join(c["nombre"] for c in f.get("ccpp", [])),
                      "resumen": resumen_texto(f)})
    return filas


def unidades_csv(catalogo: dict[str, dict]) -> bytes:
    """unidades.csv ampliado: además del catálogo V6, microcuenca, zona, centroide, MSAVI y CCPP asociados."""
    return _csv(filas_unidades(catalogo), COLS_UNIDADES)


COLS_CCPP = ["name", "label", "nombre", "unidades", "distrito", "poblacion", "este", "norte"]


def centros_poblados_csv(catalogo: dict[str, dict]) -> bytes:
    """centros_poblados.csv para Kobo: un CP por fila; la columna `unidades` lista (entre espacios) las unidades
    a las que está asociado (|27|SUS-001|), para filtrar con contains(). Incluye la opción «otro»."""
    por_cp: dict[str, dict] = {}
    for cod in sorted(catalogo):
        for c in ccpp_bloque(bloque_base(cod, catalogo) or ""):
            s = slug(c["nombre"])
            x = por_cp.setdefault(s, {"name": s, "nombre": c["nombre"], "unidades": [], "poblacion": c["poblacion"],
                                      "este": c["este"], "norte": c["norte"],
                                      "distrito": catalogo[cod].get("distrito")})
            x["unidades"].append(cod)
    filas = []
    for s, x in sorted(por_cp.items(), key=lambda kv: kv[1]["nombre"]):
        pob = f" · {int(x['poblacion'])} hab." if x.get("poblacion") else ""
        filas.append({**x, "label": f"{x['nombre']} ({_titulo_distrito(x['distrito'])}){pob}",
                      "unidades": "|" + "|".join(x["unidades"]) + "|"})
    filas.append({"name": OTRO, "label": "Otro (no figura en la lista)", "nombre": "", "unidades": "|*|"})
    return _csv(filas, COLS_CCPP)


COLS_PREDIOS = ["name", "label", "unidad", "n", "titular", "area_unidad_ha", "estado_la"]


def predios_csv(predios) -> bytes:
    """predios.csv para Kobo (F-LA-02/03/04): predios ya registrados, para elegirlos en lugar de digitar el número.
    `predios`: DataFrame o lista de dicts con cod_predio, cod_unidad, n_predio, titular, area_unidad_ha, estado_la."""
    filas = predios.to_dict("records") if hasattr(predios, "to_dict") else list(predios or [])
    out = []
    for p in filas:
        n = int(_num(p.get("n_predio")) or 0)
        tit = p.get("titular") or ""
        area = _num(p.get("area_unidad_ha"))
        partes = [f"P{n:02d}"] + ([str(tit)] if tit else []) + ([f"{area:,.2f} ha"] if area else []) + \
            ([str(p.get("estado_la"))] if p.get("estado_la") else [])
        out.append({"name": p.get("cod_predio"), "label": " · ".join(partes), "unidad": p.get("cod_unidad"), "n": n,
                    "titular": tit, "area_unidad_ha": area, "estado_la": p.get("estado_la")})
    out.append({"name": "nuevo", "label": "➕ Predio nuevo (asignar número)", "unidad": "*", "n": 0})
    return _csv(out, COLS_PREDIOS)
