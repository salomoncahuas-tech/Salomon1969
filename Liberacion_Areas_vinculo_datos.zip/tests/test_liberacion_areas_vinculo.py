# -*- coding: utf-8 -*-
"""
Pruebas del vínculo automático de datos por unidad (Liberación de Áreas, versión 2026-10b):
ficha de la unidad, completado de envíos, archivos multimedia de Kobo, XLSForm y plantilla Excel. Datos SINTÉTICOS
en los predios y titulares; los atributos de bloques y centros poblados son los del repositorio.
- Lógica pura: `python -m pytest tests/test_liberacion_areas_vinculo.py -q`
- Integración PostgreSQL: LA_TEST_DB="postgresql://…" (base VACÍA de pruebas: se borra el esquema public).
"""
import csv
import io
import os
import sys
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "tests"))
from liberacion_areas import la_campos as lc  # noqa: E402
from liberacion_areas import la_core as core  # noqa: E402
from liberacion_areas import la_plantillas as lp  # noqa: E402
from liberacion_areas import la_vinculo as lv  # noqa: E402

CSV = RAIZ / "datos" / "unidades_liberacion_areas.csv"


def _cat():
    return {r["name"]: dict(r) for r in pd.read_csv(CSV, dtype=str).fillna("").to_dict("records")}


# ------------------------------------------------------------------ ficha de la unidad
def test_atributos_cubren_los_117_bloques():
    a = lv.atributos()
    bloques = [c for c, r in _cat().items() if r["tipo_unidad"] == "bloque"]
    assert len(bloques) == 117 and set(bloques) <= set(a)
    for c in bloques:
        e, n = float(a[c]["utm_este"]), float(a[c]["utm_norte"])
        assert 450_000 <= e <= 750_000 and 9_300_000 <= n <= 9_600_000, c
        assert a[c]["microcuenca"].startswith("C10") and a[c]["zona"].startswith("Z"), c


def test_ficha_bloque():
    f = lv.ficha_unidad("3", _cat())
    assert f["provincia"] == "Ayabaca" and f["distrito"] == "Frías"
    assert f["microcuenca"] == "C1096-Q9545" and f["zona"] == "Z02"
    assert f["utm_este"] == 606816 and f["utm_norte"] == 9458469
    assert [c["nombre"] for c in f["ccpp"]][:2] == ["Los Checches", "Huayabal"]
    assert f["poblacion_ccpp"] and f["poblacion_ccpp"] > 0
    assert "microcuenca C1096-Q9545" in lv.resumen_texto(f) and "Los Checches" in lv.resumen_texto(f)


def test_ficha_lote_sus_hereda_del_bloque():
    cat = _cat()
    sus = next(c for c, r in cat.items() if r["tipo_unidad"] == "lote_sus" and r["bloque_ref"] == "27")
    f = lv.ficha_unidad(sus, cat)
    fb = lv.ficha_unidad("27", cat)
    assert f["bloque_base"] == "27" and f["microcuenca"] == fb["microcuenca"] and f["utm_este"] == fb["utm_este"]
    assert f["area_ha"] == float(cat[sus]["area_ha"])          # el área es la del lote, no la del bloque
    assert f["centroide_de"] == "bloque de referencia"


def test_unidad_desconocida_no_inventa_datos():
    assert lv.ficha_unidad("NO-EXISTE", _cat()) == {}
    reg = {"cod_unidad": "NO-EXISTE"}
    lv.completar_envio("f_la_02_titular", reg, _cat())
    assert not any(k.startswith("u_") for k in reg)


# ------------------------------------------------------------------ completado del envío (tres vías)
def test_completar_envio_no_sobrescribe():
    cat = _cat()
    reg = {"cod_unidad": "27", "u_zona": "ZXX"}
    lv.completar_envio("f_la_03_inspeccion", reg, cat)
    assert reg["u_microcuenca"] == "C1096-Q9556" and reg["u_zona"] == "ZXX"
    assert reg["u_ccpp"].startswith("Nueva Esperanza de Misquis")


def test_centro_poblado_de_kobo_y_otro():
    cat = _cat()
    reg = {"unidades": "3 27", "centro_poblado": "rincon_de_geraldo"}
    lv.completar_envio("f_la_01_reunion", reg, cat)
    assert reg["centro_poblado"] == "Rincon de Geraldo" and reg["u_microcuenca"] == "C1096-Q9545"
    reg = {"unidades": "3", "centro_poblado": "otro", "centro_poblado_otro": "Caserío Nuevo"}
    lv.completar_envio("f_la_01_reunion", reg, cat)
    assert reg["centro_poblado"] == "Caserío Nuevo"
    reg = {"unidades": "3", "centro_poblado": "Texto libre de la plantilla"}
    lv.completar_envio("f_la_01_reunion", reg, cat)
    assert reg["centro_poblado"] == "Texto libre de la plantilla"


def test_vivero_distancia_al_bloque_mas_cercano():
    cat = _cat()
    a = lv.atributos()["3"]
    gp = lc.utm_a_geopoint(float(a["utm_este"]) + 3000, float(a["utm_norte"]))
    reg = {"cod_vivero": "VIV-01", "gps_centro": gp}
    lv.completar_envio("f_la_06_vivero", reg, cat)
    cod, km = lv.bloque_mas_cercano(float(a["utm_este"]) + 3000, float(a["utm_norte"]), cat)
    assert reg["bloque_cercano"] == cod and reg["dist_bloques_km"] == km and 0 < km <= 3.01
    reg2 = {"cod_vivero": "VIV-02", "gps_centro": gp, "dist_bloques_km": 7.5}
    lv.completar_envio("f_la_06_vivero", reg2, cat)
    assert reg2["dist_bloques_km"] == 7.5


def test_validar_envio_agrega_datos_vinculados():
    cat = _cat()
    reg, avisos = lc.construir_registro("f_la_02_titular", {"hoy": "2026-10-05", "asistente": "AP-1", "unidad": "27",
                                                            "n_predio": 2, "consentimiento": "si",
                                                            "tipo_titularidad": "privado", "aceptacion": "favorable"},
                                        cat, kobo_uuid=lc.nuevo_uuid())
    r = core.validar_envio("f_la_02_titular", reg, cat, {}, set())
    assert r.datos["u_microcuenca"] == "C1096-Q9556" and r.datos["u_utm_este"] == 613302
    assert r.cod_predio == "27-P02"


def test_vivero_provincia_distrito_compatibles():
    assert lc.codigo_opcion("distrito", "Morropón") == "morropon"
    assert lc.codigo_opcion("provincia", "Huancabamba") == "huancabamba"
    cat = _cat()
    assert {d for d, _, _ in lv.distritos_ambito(cat)} == set(lc.DISTRITO_PROVINCIA)
    for d, _, p in lv.distritos_ambito(cat):
        assert lc.DISTRITO_PROVINCIA[d] == p


def test_siguiente_n_predio():
    assert lv.siguiente_n_predio([]) == 1
    assert lv.siguiente_n_predio([1, 3, "2"]) == 4


# ------------------------------------------------------------------ archivos multimedia y XLSForm
def _leer_csv(b: bytes) -> list[dict]:
    return list(csv.DictReader(io.StringIO(b.decode("utf-8"))))


def test_archivos_media():
    cat = _cat()
    pred = [{"cod_predio": "27-P01", "cod_unidad": "27", "n_predio": 1, "titular": "TITULAR FICTICIO",
             "area_unidad_ha": 3.5, "estado_la": "LA-2"}]
    m = lp.archivos_media(cat, pred)
    assert set(m) == {"unidades.csv", "centros_poblados.csv", "predios.csv"}
    u = _leer_csv(m["unidades.csv"])
    assert len(u) == len(cat) and {"microcuenca", "zona", "utm_este", "ccpp", "resumen"} <= set(u[0])
    cp = _leer_csv(m["centros_poblados.csv"])
    nombres = [x["name"] for x in cp]
    assert len(nombres) == len(set(nombres)) and nombres[-1] == "otro"
    assert all(x["unidades"].startswith("|") and x["unidades"].endswith("|") for x in cp)
    checches = next(x for x in cp if x["name"] == "los_checches")
    assert "|3|" in checches["unidades"]
    p = _leer_csv(m["predios.csv"])
    assert p[0]["name"] == "27-P01" and p[0]["n"] == "1" and p[-1]["name"] == "nuevo"


def test_xlsform_con_datos_vinculados():
    from pyxform import xls2xform
    import tempfile
    for fid, f in lc.FORMULARIOS.items():
        if not f.kobo:
            continue
        h = lp.xlsform_hojas(fid)
        nombres = list(h["survey"]["name"])
        if any(c.tipo == "unidad" for c in f.campos):
            assert "nota_unidad" in nombres and "u_microcuenca" in nombres and "u_resumen" in nombres
        if f.con_predio:
            assert {"predio_sel", "n_predio_nuevo", "n_predio", "cod_predio"} <= set(nombres)
            assert h["survey"].loc[h["survey"].name == "n_predio", "type"].iloc[0] == "calculate"
        with tempfile.NamedTemporaryFile(suffix=".xlsx") as t:
            t.write(lp.generar_xlsform(fid))
            t.flush()
            xml = xls2xform.convert(xlsform=t.name, validate=False).xform
        assert "jr://file-csv/unidades.csv" in xml or fid == "f_la_06_vivero"
    s = lp.xlsform_hojas("f_la_01_reunion")["survey"]
    cp = s[s.name == "centro_poblado"].iloc[0]
    assert cp["type"] == "select_one_from_file centros_poblados.csv" and "selected-at(${unidades}, 0)" in cp["choice_filter"]
    s6 = lp.xlsform_hojas("f_la_06_vivero")
    assert s6["survey"].loc[s6["survey"].name == "distrito", "choice_filter"].iloc[0] == "provincia=${provincia}"
    assert "provincia" in s6["choices"].columns


def test_plantilla_excel_columnas_referencia_y_reimportacion():
    cat = _cat()
    wb = load_workbook(io.BytesIO(lp.generar_plantilla_excel(cat)))
    ws = wb["F-LA-02"]
    claves = [ws.cell(lp.FILA_CLAVE, j).value for j in range(1, ws.max_column + 1)]
    assert "_ref_microcuenca" in claves and "_ref_ccpp" in claves
    j = claves.index("_ref_microcuenca") + 1
    assert str(ws.cell(lp.FILA_DATOS, j).value).startswith("=IF(")
    cat_ws = wb["Catalogo_unidades"]
    enc = [cat_ws.cell(lp.FILA_ETIQUETA, j).value for j in range(1, cat_ws.max_column + 1)]
    assert enc[:6] == ["codigo", "tipo_unidad", "provincia", "distrito", "microcuenca", "zona"]
    # una fila llenada se importa sin que las columnas de referencia se vuelvan campos
    col = {k: i + 1 for i, k in enumerate(claves)}
    fila = lp.FILA_DATOS
    for k, v in {"id_registro": 1, "hoy": "05/10/2026", "asistente": "AP-1", "unidad": "27", "n_predio": 1,
                 "consentimiento": "Sí", "tipo_titularidad": "Privado (con título)", "aceptacion": "Favorable"}.items():
        ws.cell(fila, col[k], v)
    buf = io.BytesIO()
    wb.save(buf)
    leido = lp.leer_plantilla_excel(io.BytesIO(buf.getvalue()), cat)
    reg = leido["envios"]["f_la_02_titular"][0]["registro"]
    assert not any(k.startswith("_ref_") for k in reg) and reg["cod_predio"] == "27-P01"


# ------------------------------------------------------------------ integración PostgreSQL
def test_integracion_vinculo_postgres():
    url = os.environ.get("LA_TEST_DB")
    if not url:
        return
    import test_liberacion_areas as base
    from liberacion_areas import la_db as db
    base.test_integracion_postgres()          # deja la base con catálogo, bloques y un antecedente Paso 6
    conn = db.conectar(url)
    cat = db.catalogo(conn)
    assert lv.ficha_unidad("27", cat)["microcuenca"] == "C1096-Q9556"
    reg, _ = lc.construir_registro("f_la_02_titular", {
        "hoy": "2026-10-05", "asistente": "AP-1", "unidad": "27", "n_predio": 7, "consentimiento": "si",
        "tipo_titularidad": "privado", "tit_nombres": "ANA", "tit_apellidos": "FICTICIA", "tit_dni": "40000007",
        "tit_estado_civil": "casado", "cony_nombre": "LUIS FICTICIO", "cony_dni": "40000008",
        "predio_area_unidad_ha": 4.25, "aceptacion": "favorable"}, cat, kobo_uuid=lc.nuevo_uuid())
    r = core.validar_envio("f_la_02_titular", reg, cat, {}, db.uuids_existentes(conn))
    db.importar(conn, [r], "APP", "f_la_02_titular", "prueba")
    reg1, _ = lc.construir_registro("f_la_01_reunion", {
        "hoy": "2026-10-05", "asistente": "AP-1", "unidades": ["27"], "tipo_evento": "asamblea_comunal",
        "fecha_evento": "2026-10-05", "comunidad": "CC FICTICIA", "aceptacion": "favorable"}, cat, kobo_uuid=lc.nuevo_uuid())
    db.importar(conn, [core.validar_envio("f_la_01_reunion", reg1, cat, {}, set())], "APP", "f_la_01_reunion", "prueba")
    p = db.predios_unidad(conn, "27")
    fila = p[p.cod_predio == "27-P07"].iloc[0]
    assert fila.titular == "ANA FICTICIA" and float(fila.area_unidad_ha) == 4.25
    assert lv.siguiente_n_predio(p.n_predio) >= 8
    ficha = db.ultima_ficha_titular(conn, "27-P07")
    assert ficha["tit_dni"] == "40000007" and ficha["u_microcuenca"] == "C1096-Q9556"
    assert db.comunidades_unidades(conn, ["27"]) == ["CC FICTICIA"]
    assert db.antecedente_paso6(conn, "27")["titular"] == "JUAN (FICTICIO)"
    predios_csv = _leer_csv(lv.predios_csv(db.predios_unidad(conn)))
    assert any(x["name"] == "27-P07" and x["titular"] == "ANA FICTICIA" for x in predios_csv)
    conn.close()


def test_unidades_como_lista_del_aplicativo():
    """El multiselect del aplicativo entrega una lista: debe quedar «27 3», igual que en Kobo."""
    reg, avisos = lc.construir_registro("f_la_01_reunion", {"hoy": "2026-10-05", "asistente": "AP-1", "unidades": ["27", "3"],
                                                            "tipo_evento": "asamblea_comunal", "fecha_evento": "2026-10-05",
                                                            "aceptacion": "favorable"}, _cat(), kobo_uuid=lc.nuevo_uuid())
    assert reg["unidades"] == "27 3" and reg["cod_unidad"] == "27 3" and not avisos


def test_firmantes_desde_ficha():
    from liberacion_areas import pagina
    f = pagina._firmantes_desde_ficha({"tipo_titularidad": "privado", "tit_nombres": "ANA", "tit_apellidos": "FICTICIA",
                                       "tit_dni": "40000007", "cony_nombre": "LUIS", "cony_dni": "40000008"})
    assert [x["fir_rol"] for x in f] == ["titular", "conyuge"] and f[0]["fir_nombre"] == "ANA FICTICIA"
    f = pagina._firmantes_desde_ficha({"tipo_titularidad": "comunal", "cc_presidente": "PRESIDENTE FICTICIO"})
    assert f == [{"fir_nombre": "PRESIDENTE FICTICIO", "fir_dni": None, "fir_rol": "presidente_cc"}]


def test_sincronizar_catalogos_kobo(monkeypatch):
    """Sube los CSV (reemplaza el existente) y redespliega; las llamadas van solo al servidor configurado."""
    import json
    import types
    import urllib.request
    try:                                      # database.py exige st.secrets["DATABASE_URL"] al importarse
        import database  # noqa: F401
    except Exception:  # noqa: BLE001
        sys.modules["database"] = types.ModuleType("database")
    from odk_kobo import KoBoClient
    from liberacion_areas import la_kobo as kb
    llamadas = []

    class Resp:
        def __init__(self, d):
            self.d = json.dumps(d).encode()

        def read(self):
            return self.d

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def falso_urlopen(req, context=None, timeout=None):
        llamadas.append((req.get_method(), req.full_url, req.data[:200] if req.data else None))
        if req.get_method() == "GET" and "/files/" in req.full_url:
            return Resp({"results": [{"uid": "afOLD", "metadata": {"filename": "unidades.csv"}}]})
        if req.get_method() == "GET":
            return Resp({"has_deployment": True, "version_id": "vABC"})
        return Resp({})

    monkeypatch.setattr(urllib.request, "urlopen", falso_urlopen)
    kobo = KoBoClient("https://kf.kobotoolbox.org", "token-ficticio")
    res = kb.sincronizar_catalogos(kobo, ["aXYZ"], {"unidades.csv": b"name\n27\n", "predios.csv": b"name\nnuevo\n"})
    assert res[0]["estado"] == "OK" and res[0]["redesplegado"] == "sí"
    metodos = [(m, u.split("/api/v2/")[1]) for m, u, _ in llamadas]
    assert ("DELETE", "assets/aXYZ/files/afOLD/") in metodos
    assert sum(1 for m, u in metodos if m == "POST" and u == "assets/aXYZ/files/") == 2
    patch = [x for x in llamadas if x[0] == "PATCH"][0]
    assert "deployment" in patch[1] and b'"version_id": "vABC"' in patch[2]
    assert all(u.startswith("https://kf.kobotoolbox.org/") for _, u, _ in llamadas)
