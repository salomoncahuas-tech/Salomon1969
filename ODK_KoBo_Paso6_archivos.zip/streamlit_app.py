"""
IN Piura - Plan de Ingreso / Verificacion de Campo
Aplicacion web con Streamlit.
Restauracion de ecosistemas - Cuenca alta del rio Piura, Peru.
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date, time as dtime, timedelta
import os
import uuid
import io
import csv
import json
import re
import tempfile

import database as db
import export_diagnosticos as exp_diag
import resumenes_bloques as rbq
import fichas_dt as fdt
import analitica_social as ans
from bloque_lookup import buscar_label_bloque

# ── Constante de version de cache (incrementar tras escritura) ───────────
# Usada para invalidar @st.cache_data despues de inserciones/actualizaciones.
def _cache_version():
    """Retorna un contador que se incrementa con cada escritura a la BD."""
    if "db_cache_version" not in st.session_state:
        st.session_state["db_cache_version"] = 0
    return st.session_state["db_cache_version"]

def _invalidar_cache():
    """Incrementa el contador de cache para forzar recarga de datos."""
    st.session_state["db_cache_version"] = st.session_state.get("db_cache_version", 0) + 1

# ── Mensajes flash (sobreviven a st.rerun) ───────────────────────────────
def _flash(msg, tipo="success"):
    """Guarda un mensaje para mostrarlo tras el siguiente st.rerun()."""
    st.session_state["_flash_msg"] = (tipo, msg)

def _mostrar_flash():
    """Muestra (y descarta) el mensaje flash pendiente, si existe."""
    item = st.session_state.pop("_flash_msg", None)
    if not item:
        return
    tipo, msg = item
    {"success": st.success, "info": st.info,
     "warning": st.warning, "error": st.error}.get(tipo, st.success)(msg)

# ── Funciones cacheadas de lectura de BD ─────────────────────────────────
# max_entries=2: al invalidar por version quedarian copias viejas del
# dataset completo en memoria hasta expirar el TTL; con el limite solo se
# retiene la version actual y una anterior.
@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_bloques(_version):
    return db.obtener_bloques()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_todas_inspecciones(_version):
    return db.obtener_todas_inspecciones()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_estadisticas(_version):
    return db.obtener_estadisticas_generales()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_resumen_bloques(_version):
    return db.obtener_resumen_bloques()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_todos_diagnosticos(_version):
    return db.obtener_todos_diagnosticos()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_todos_diagnosticos_sociales(_version):
    return db.obtener_todos_diagnosticos_sociales()

@st.cache_data(ttl=300, show_spinner=False, max_entries=2)
def _cached_obtener_resumenes_bloques(_version):
    return db.obtener_resumenes_bloques()

# ── Constantes de fecha para validacion ──────────────────────────────────
FECHA_MIN_PROYECTO = date(2024, 1, 1)
FECHA_MAX_PROYECTO = date.today() + timedelta(days=365)

# ── Helper de paginacion ─────────────────────────────────────────────────
def _paginar(items, page_key, items_por_pagina=15):
    """Retorna (items_pagina, total_paginas, pagina_actual) para listas largas."""
    total = len(items)
    total_paginas = max(1, (total + items_por_pagina - 1) // items_por_pagina)
    if page_key not in st.session_state:
        st.session_state[page_key] = 1
    pagina = st.session_state[page_key]
    pagina = max(1, min(pagina, total_paginas))
    inicio = (pagina - 1) * items_por_pagina
    fin = inicio + items_por_pagina
    return items[inicio:fin], total_paginas, pagina

def _controles_paginacion(total_paginas, pagina_actual, page_key):
    """Muestra controles de paginacion si hay mas de 1 pagina."""
    if total_paginas <= 1:
        return
    cols = st.columns([1, 2, 1])
    with cols[0]:
        if st.button("Anterior", key=f"{page_key}_prev", disabled=pagina_actual <= 1):
            st.session_state[page_key] = pagina_actual - 1
            st.rerun()
    with cols[1]:
        st.markdown(f"<div style='text-align:center'>Pagina **{pagina_actual}** de **{total_paginas}**</div>",
                    unsafe_allow_html=True)
    with cols[2]:
        if st.button("Siguiente", key=f"{page_key}_next", disabled=pagina_actual >= total_paginas):
            st.session_state[page_key] = pagina_actual + 1
            st.rerun()
import reports
from georeferenciacion import utm_a_latlon, latlon_a_utm
from odk_kobo import (generar_xlsform, KoBoClient, FORM_ID as ODK_FORM_ID,
    preparar_envios as odk_preparar_envios, registrar_envios as odk_registrar_envios,
    resumen_preparacion as odk_resumen_preparacion, texto_resultado as odk_texto_resultado,
    leer_archivo_odk as odk_leer_archivo, encabezados_plantilla_csv as odk_encabezados_csv,
    DIST_ALERTA_CENTROIDE_M as ODK_DIST_ALERTA, MAX_PREDIOS_BLOQUE as ODK_MAX_PREDIOS)
from excel_diagnostico_social import generar_plantilla_ds, parsear_excel_ds, mapear_a_session_state
from excel_diagnostico_territorial import generar_plantilla_dt, parsear_excel_dt, mapear_dt_a_session_state
from excel_elementos_expuestos import (generar_plantilla_ee, parsear_excel_ee,
    mapear_a_session_state as mapear_ee_a_session_state,
    FEE01_TIPO_ELEMENTO, FEE01_UBICACION_PELIGRO, FEE_ESTADO, FEE_NIVEL_AMB,
    FEE_SI_NO, FEE02_MATERIAL_VIV, FEE03_SECTOR, FEE_TIPO_PELIGRO,
    FEE04_TIPO_ACTIVIDAD, FEE05_TIPO_DEGRADACION, FEE05_FUENTES_AGUA,
    FEE05_PROB_RECURRENCIA, FEE06_NIVEL_VULN, FEE06_ELEMENTOS, FEE06_FACTORES)

try:
    import pdf_converter as pdfconv
    PDF_CONV_OK = True
except ImportError:
    PDF_CONV_OK = False

# ── Configuracion ─────────────────────────────────────────────────────────
st.set_page_config(
    page_title="IN Piura - Plan de Ingreso",
    page_icon="\U0001F331",
    layout="wide",
    initial_sidebar_state="expanded",
)

@st.cache_resource
def _inicializar_bd_una_vez():
    db.inicializar_bd()

def _arrancar_con_reintento():
    """Intenta inicializar la BD; si falla muestra error y botón de reintento."""
    try:
        _inicializar_bd_una_vez()
    except Exception as e:
        st.error(
            "**No se pudo conectar a la base de datos.**\n\n"
            "La base de datos puede estar pausada (esto ocurre en el plan gratuito de Supabase "
            "cuando no hay actividad por varios días).\n\n"
            "**¿Qué hacer?**\n"
            "1. Entra a [supabase.com](https://supabase.com) y verifica que tu proyecto esté activo (no pausado).\n"
            "2. Si está pausado, haz clic en **Resume project** y espera 1-2 minutos.\n"
            "3. Luego presiona el botón de abajo para reintentar."
        )
        if st.button("🔄 Reintentar conexión"):
            st.cache_resource.clear()
            st.rerun()
        st.stop()

_arrancar_con_reintento()

# ── Constantes ────────────────────────────────────────────────────────────
TIPOS_INTERVENCION = [
    "Revegetacion", "Zanjas de infiltracion",
    "Terrazas de formacion lenta", "Diques de mamposteria", "Lotes SUS", "Otras",
]
ESTADOS_BLOQUE = ["Pendiente", "En progreso", "Verificado"]
CONDICIONES_CLIMATICAS = [
    "Despejado", "Parcialmente nublado", "Nublado",
    "Lluvia ligera", "Lluvia moderada", "Lluvia intensa", "Neblina",
]
MICROCUENCAS = [
    "C1075-Q9580","C1076-Q9581","C1076-Q9584","C1076-Q9585","C1076-Q9586",
    "C1076-Q9587","C1076-Q9588","C1076-Q9589","C1076-Q9592","C1077-Q9566",
    "C1077-Q9579","C1078-Q9562","C1080-Q9560","C1081-Q9582","C1081-Q9583",
    "C1081-Q9591","C1086-Q9569","C1086-Q9570","C1086-Q9575","C1086-Q9576",
    "C1096-Q9545","C1096-Q9547","C1096-Q9556","C1096-Q9557","C1096-Q9558",
    "C1096-Q9564","C1107-Q9539","C1107-Q9541","C1108-Q9552",
]

# ── Datos de Origen: 132 Bloques de Intervencion V5 ──────────────────
# Fuente: Plantilla_DT_Campo_Check_Validada_V5.xlsx (hoja 'Bloques V4')
# Ampliacion: 'Bloques Adicionalea.xlsx' aporta los bloques 83..87
# (microcuenca C1081-Q9583, San Juan de Bigote, Morropon, Zona Z08).
# Cada entrada: (N, Bloque, Microcuenca, Area_ha, Provincia, Distrito,
#                Accesibilidad, Dia, UTM_Este, UTM_Norte, MSAVI_2024, Zona)
BLOQUES_V5 = [
    # (n, codigo, microcuenca, area_ha, provincia, distrito, accesibilidad, dia_eval, utm_este, utm_norte, msavi_2024, zona)
    (1, "M9B1", "C1096-Q9545", 355.36, "Morropon", "Chulucanas", 0, 0, 595552, 9451222, 0.314312, "Z01"),
    (2, "M10B4", "C1096-Q9547", 68.89, "Morropon", "Chulucanas", 0, 0, 596773, 9448273, 0.313301, "Z01"),
    (3, "25", "C1096-Q9547", 53.48, "Morropon", "Chulucanas", 0, 0, 596578, 9442453, 0.256543, "Z01"),
    (4, "32", "C1096-Q9556", 35.83, "Morropon", "Chulucanas", 0, 0, 599927, 9442604, 0.371619, "Z01"),
    (5, "22", "C1096-Q9556", 79.33, "Morropon", "Chulucanas", 0, 0, 601122, 9443651, 0.42317, "Z01"),
    (6, "M17B1", "C1096-Q9556", 42.45, "Morropon", "Chulucanas", 0, 0, 600644, 9440436, 0.332263, "Z01"),
    (7, "2", "C1096-Q9558", 330.6, "Morropon", "Chulucanas", 0, 0, 603653, 9439351, 0.358601, "Z01"),
    (8, "M17B4", "C1096-Q9556", 124.71, "Morropon", "Chulucanas", 0, 0, 604926, 9444327, 0.423543, "Z01"),
    (9, "M27B1", "C1096-Q9557", 448.8, "Morropon", "Chulucanas", 0, 0, 593246, 9430139, 0.363228, "Z01"),
    (10, "3", "C1096-Q9545", 459.29, "Ayabaca", "Frias", 0, 0, 606816, 9458469, 0.567707, "Z02"),
    (11, "6", "C1096-Q9547", 168.41, "Ayabaca", "Frias", 0, 0, 605636, 9455269, 0.538144, "Z02"),
    (12, "36", "C1096-Q9547", 24.84, "Ayabaca", "Frias", 0, 0, 606468, 9454689, 0.539458, "Z02"),
    (13, "M17B7", "C1096-Q9556", 258.84, "Ayabaca", "Frias", 0, 0, 608472, 9448056, 0.508715, "Z02"),
    (14, "M17B6", "C1096-Q9556", 106.54, "Ayabaca", "Frias", 0, 0, 607036, 9446211, 0.446441, "Z02"),
    (15, "M17B10", "C1096-Q9556", 75.36, "Ayabaca", "Frias", 0, 0, 606173, 9447361, 0.472466, "Z02"),
    (16, "M17B5", "C1096-Q9556", 74.03, "Ayabaca", "Frias", 0, 0, 608800, 9445585, 0.54817, "Z02"),
    (17, "27", "C1096-Q9556", 78.15, "Ayabaca", "Frias", 0, 0, 613302, 9450231, 0.53228, "Z02"),
    (18, "39", "C1096-Q9564", 68.57, "Ayabaca", "Frias", 0, 0, 618523, 9448918, 0.701601, "Z02"),
    (19, "56", "C1096-Q9564", 77.67, "Ayabaca", "Frias", 0, 0, 631723, 9439702, 0.677658, "Z02"),
    (20, "12", "C1086-Q9570", 119.54, "Morropon", "Santo Domingo", 0, 0, 625419, 9444932, 0.706689, "Z03"),
    (21, "82", "C1086-Q9570", 35.66, "Morropon", "Santo Domingo", 0, 0, 621452, 9443855, 0.62835, "Z03"),
    (22, "13", "C1096-Q9564", 100.51, "Morropon", "Santo Domingo", 0, 0, 620263, 9442343, 0.671094, "Z03"),
    (23, "78", "C1086-Q9570", 35.1, "Morropon", "Santo Domingo", 0, 0, 619630, 9440043, 0.707402, "Z03"),
    (24, "11", "C1086-Q9570", 103.95, "Morropon", "Santo Domingo", 0, 0, 620759, 9439988, 0.604743, "Z03"),
    (25, "23", "C1086-Q9570", 81.78, "Morropon", "Santo Domingo", 0, 0, 619939, 9438544, 0.573141, "Z03"),
    (26, "15", "C1086-Q9570", 86.15, "Morropon", "Santo Domingo", 0, 0, 620200, 9437862, 0.560518, "Z03"),
    (27, "M19B7", "C1086-Q9570", 34.17, "Morropon", "Santo Domingo", 0, 0, 620770, 9436562, 0.591921, "Z03"),
    (28, "17", "C1086-Q9570", 96.08, "Morropon", "Santo Domingo", 0, 0, 618661, 9438267, 0.647895, "Z03"),
    (29, "M8B2", "C1096-Q9558", 35.35, "Morropon", "Santo Domingo", 0, 0, 617596, 9436227, 0.530453, "Z03"),
    (30, "57", "C1086-Q9576", 25.67, "Morropon", "Chalaco", 0, 0, 631195, 9441777, 0.603055, "Z04"),
    (31, "59", "C1086-Q9570", 13.55, "Morropon", "Chalaco", 0, 0, 631195, 9441777, 0.614739, "Z04"),
    (32, "M36B2", "C1086-Q9576", 28.19, "Morropon", "Santa Catalina de Mossa", 0, 0, 626438, 9435060, 0.597433, "Z04"),
    (33, "42", "C1086-Q9570", 80.62, "Morropon", "Santa Catalina de Mossa", 0, 0, 625152, 9435011, 0.634841, "Z04"),
    (34, "14", "C1086-Q9570", 92.9, "Morropon", "Santa Catalina de Mossa", 0, 0, 624397, 9437085, 0.51974, "Z04"),
    (35, "58", "C1086-Q9569", 11.47, "Morropon", "Santa Catalina de Mossa", 0, 0, 619094, 9426406, 0.420325, "Z04"),
    (36, "M19B2", "C1086-Q9570", 74.37, "Morropon", "Morropon", 0, 0, 617715, 9427284, 0.401185, "Z05"),
    (37, "M32B3", "C1086-Q9569", 50.97, "Morropon", "Morropon", 0, 0, 618248, 9426493, 0.385213, "Z05"),
    (38, "M6B10", "C1077-Q9566", 249.89, "Morropon", "Buenos Aires", 0, 0, 618299, 9423119, 0.30989, "Z06"),
    (39, "M6B2-3", "C1077-Q9566", 160.98, "Morropon", "Buenos Aires", 0, 0, 611305, 9419274, 0.406259, "Z06"),
    (40, "M6B2-2", "C1077-Q9566", 333.01, "Morropon", "Buenos Aires", 0, 0, 611196, 9416725, 0.302636, "Z06"),
    (41, "M6B2-1", "C1077-Q9566", 514.36, "Morropon", "Buenos Aires", 0, 0, 612864, 9413345, 0.3381, "Z06"),
    (42, "5", "C1077-Q9566", 295.73, "Morropon", "Buenos Aires", 0, 0, 617860, 9413182, 0.3394, "Z06"),
    (43, "M1B1", "C1077-Q9580", 188.8, "Morropon", "Buenos Aires", 0, 0, 617695, 9409136, 0.319305, "Z06"),
    (44, "M18B1", "C1077-Q9579", 160.36, "Morropon", "Buenos Aires", 0, 0, 621058, 9410427, 0.334299, "Z06"),
    (45, "M3B9", "C1081-Q9582", 294.2, "Morropon", "Salitral", 0, 0, 629338, 9413305, 0.321386, "Z07"),
    (46, "M3B1", "C1081-Q9582", 80.98, "Morropon", "Salitral", 0, 0, 630685, 9410800, 0.323882, "Z07"),
    (47, "M7B1", "C1076-Q9581", 130.43, "Morropon", "Salitral", 0, 0, 629006, 9407536, 0.313647, "Z07"),
    (48, "M7B2", "C1076-Q9581", 115.38, "Morropon", "Salitral", 0, 0, 631438, 9403547, 0.287689, "Z07"),
    (49, "M7B3", "C1076-Q9581", 65.74, "Morropon", "Salitral", 0, 0, 633232, 9401227, 0.298017, "Z07"),
    (50, "M7B6", "C1076-Q9581", 91.29, "Morropon", "Salitral", 0, 0, 635110, 9399092, 0.287833, "Z07"),
    (51, "M2B1", "C1076-Q9584", 81.79, "Morropon", "Salitral", 0, 0, 635876, 9397941, 0.29836, "Z07"),
    (52, "7", "C1076-Q9584", 173.43, "Morropon", "Salitral", 0, 0, 639728, 9396836, 0.375288, "Z07"),
    (53, "M2B5", "C1076-Q9584", 30.91, "Morropon", "Salitral", 0, 0, 639987, 9394392, 0.304733, "Z07"),
    (54, "1", "C1076-Q9584", 1370.96, "Morropon", "Salitral", 0, 0, 645575, 9393500, 0.454493, "Z07"),
    (55, "M18B3", "C1077-Q9579", 373.81, "Morropon", "Salitral", 0, 0, 625311, 9412195, 0.369424, "Z07"),
    (56, "M18B5", "C1077-Q9579", 197.35, "Morropon", "Salitral", 0, 0, 621551, 9412989, 0.356522, "Z07"),
    (57, "M3B7", "C1081-Q9582", 122.95, "Morropon", "San Juan de Bigote", 0, 0, 638309, 9415217, 0.370678, "Z08"),
    (58, "M3B6", "C1081-Q9582", 60.35, "Morropon", "San Juan de Bigote", 0, 0, 637918, 9412134, 0.342535, "Z08"),
    (59, "77", "C1081-Q9583", 17.82, "Morropon", "San Juan de Bigote", 0, 0, 638648, 9411370, 0.272488, "Z08"),
    (60, "M3B5", "C1081-Q9582", 52.74, "Morropon", "San Juan de Bigote", 0, 0, 635887, 9411738, 0.283016, "Z08"),
    (61, "M3B3", "C1081-Q9582", 84.82, "Morropon", "San Juan de Bigote", 0, 0, 633015, 9411483, 0.298483, "Z08"),
    (62, "M3B8", "C1081-Q9582", 565.58, "Morropon", "San Juan de Bigote", 0, 0, 632119, 9415141, 0.293351, "Z08"),
    (63, "M11B3", "C1081-Q9583", 106.03, "Morropon", "San Juan de Bigote", 0, 0, 642079, 9413823, 0.395609, "Z08"),
    (64, "55", "C1086-Q9575", 0.86, "Morropon", "Yamango", 0, 0, 642690, 9438409, 0.630032, "Z09"),
    (65, "49", "C1086-Q9575", 15.84, "Morropon", "Yamango", 0, 0, 642334, 9438263, 0.686036, "Z09"),
    (66, "52", "C1086-Q9575", 11.06, "Morropon", "Yamango", 0, 0, 641522, 9438064, 0.66855, "Z09"),
    (67, "48", "C1086-Q9575", 5.75, "Morropon", "Yamango", 0, 0, 639496, 9433679, 0.697809, "Z09"),
    (68, "46", "C1086-Q9575", 18.87, "Morropon", "Yamango", 0, 0, 638751, 9433236, 0.724382, "Z09"),
    (69, "M28B2", "C1086-Q9575", 90.2, "Morropon", "Yamango", 0, 0, 636249, 9425665, 0.475342, "Z09"),
    (70, "M28B3", "C1086-Q9575", 58.29, "Morropon", "Yamango", 0, 0, 634061, 9426778, 0.507529, "Z09"),
    (71, "M28B4", "C1086-Q9575", 283.43, "Morropon", "Yamango", 0, 0, 626078, 9427110, 0.42751, "Z09"),
    (72, "33", "C1081-Q9590", 29.68, "Huancabamba", "Lalaquiz", 0, 0, 646466, 9431126, 0.71923, "Z10"),
    (73, "38", "C1081-Q9590", 44.2, "Huancabamba", "Lalaquiz", 0, 0, 647123, 9427602, 0.672487, "Z10"),
    (74, "50", "C1081-Q9590", 19.27, "Huancabamba", "Lalaquiz", 0, 0, 647350, 9427252, 0.68307, "Z10"),
    (75, "34", "C1081-Q9590", 28.45, "Huancabamba", "Lalaquiz", 0, 0, 646483, 9426305, 0.648975, "Z10"),
    (76, "61", "C1081-Q9590", 26.83, "Huancabamba", "Lalaquiz", 0, 0, 646236, 9425052, 0.611186, "Z10"),
    (77, "37", "C1081-Q9591", 35.49, "Huancabamba", "Lalaquiz", 0, 0, 649081, 9424506, 0.658846, "Z10"),
    (78, "26", "C1081-Q9591", 46.96, "Huancabamba", "Lalaquiz", 0, 0, 649472, 9425705, 0.673303, "Z10"),
    (79, "64", "C1081-Q9591", 35.77, "Huancabamba", "Huancabamba", 0, 0, 657819, 9428541, 0.525448, "Z11"),
    # n=80 (bloque "54") retirado: version desactualizada. Ver BLOQUES_RETIRADOS.
    (81, "M30B5", "C1081-Q9591", 90.9, "Huancabamba", "Huancabamba", 0, 0, 655263, 9427340, 0.5564, "Z11"),
    (82, "60", "C1081-Q9591", 40.13, "Huancabamba", "Canchaque", 0, 0, 653850, 9426236, 0.67447, "Z11"),
    (83, "40", "C1081-Q9591", 28.52, "Huancabamba", "Canchaque", 0, 0, 654137, 9424425, 0.640099, "Z11"),
    (84, "30", "C1081-Q9591", 34.87, "Huancabamba", "Canchaque", 0, 0, 652758, 9424380, 0.663804, "Z11"),
    (85, "28", "C1081-Q9591", 52.97, "Huancabamba", "Canchaque", 0, 0, 654188, 9422849, 0.639425, "Z11"),
    # n=86 (bloque "62") y n=87 (bloque "65") retirados: version desactualizada.
    (88, "21", "C1081-Q9591", 84.23, "Huancabamba", "Canchaque", 0, 0, 654604, 9417736, 0.620078, "Z11"),
    (89, "66", "C1081-Q9591", 102.34, "Huancabamba", "Canchaque", 0, 0, 652566, 9417311, 0.640254, "Z11"),
    (90, "24", "C1081-Q9583", 90.16, "Huancabamba", "Canchaque", 0, 0, 652191, 9414358, 0.674839, "Z11"),
    (91, "63", "C1081-Q9583", 50.46, "Huancabamba", "Canchaque", 0, 0, 655059, 9413845, 0.603582, "Z11"),
    (92, "79", "C1076-Q9587", 94.81, "Huancabamba", "Canchaque", 0, 0, 650305, 9402785, 0.547879, "Z11"),
    (93, "81", "C1076-Q9585", 8.93, "Huancabamba", "Canchaque", 0, 0, 641538, 9401360, 0.274714, "Z11"),
    (94, "M22B1", "C1076-Q9586", 55.17, "Huancabamba", "San Miguel de El Faique", 0, 0, 664082, 9404172, 0.594025, "Z12"),
    (95, "44", "C1076-Q9586", 28.23, "Huancabamba", "San Miguel de El Faique", 0, 0, 663637, 9400618, 0.511324, "Z12"),
    (96, "47", "C1076-Q9586", 13.55, "Huancabamba", "San Miguel de El Faique", 0, 0, 659649, 9401436, 0.593628, "Z12"),
    (97, "75", "C1076-Q9587", 15.18, "Huancabamba", "San Miguel de El Faique", 0, 0, 657722, 9401669, 0.630888, "Z12"),
    (98, "9", "C1076-Q9586", 109.86, "Huancabamba", "San Miguel de El Faique", 0, 0, 656578, 9397762, 0.574527, "Z12"),
    (99, "43", "C1076-Q9586", 23.17, "Huancabamba", "San Miguel de El Faique", 0, 0, 656489, 9395403, 0.551525, "Z12"),
    (100, "35", "C1076-Q9586", 30.8, "Huancabamba", "San Miguel de El Faique", 0, 0, 654607, 9395038, 0.624477, "Z12"),
    (101, "67", "C1076-Q9586", 13.18, "Huancabamba", "San Miguel de El Faique", 0, 0, 654207, 9394210, 0.605293, "Z12"),
    (102, "M20B1", "C1076-Q9585", 279.68, "Huancabamba", "San Miguel de El Faique", 0, 0, 641196, 9398710, 0.355329, "Z12"),
    (103, "M2B8", "C1076-Q9584", 116.1, "Huancabamba", "San Miguel de El Faique", 0, 0, 639059, 9398295, 0.375171, "Z12"),
    (104, "29", "C1076-Q9592", 40.1, "Huancabamba", "Huarmaca", 0, 0, 662123, 9397575, 0.548192, "Z13"),
    (105, "68", "C1076-Q9592", 21.29, "Huancabamba", "Huarmaca", 0, 0, 664225, 9396339, 0.482981, "Z13"),
    (106, "53", "C1076-Q9592", 13.06, "Huancabamba", "Huarmaca", 0, 0, 666537, 9395918, 0.596277, "Z13"),
    (107, "70", "C1076-Q9592", 22.39, "Huancabamba", "Huarmaca", 0, 0, 666781, 9395573, 0.622295, "Z13"),
    (108, "31", "C1076-Q9592", 47.58, "Huancabamba", "Huarmaca", 0, 0, 663334, 9392820, 0.435805, "Z13"),
    (109, "69", "C1076-Q9592", 19.43, "Huancabamba", "Huarmaca", 0, 0, 663291, 9392332, 0.448926, "Z13"),
    (110, "72", "C1076-Q9592", 12.4, "Huancabamba", "Huarmaca", 0, 0, 662236, 9391211, 0.518477, "Z13"),
    (111, "41", "C1076-Q9592", 64.92, "Huancabamba", "Huarmaca", 0, 0, 660525, 9394327, 0.592669, "Z13"),
    (112, "73", "C1076-Q9592", 54.29, "Huancabamba", "Huarmaca", 0, 0, 658547, 9395594, 0.554974, "Z13"),
    (113, "18", "C1076-Q9592", 103.62, "Huancabamba", "Huarmaca", 0, 0, 656445, 9393180, 0.640219, "Z13"),
    (114, "74", "C1076-Q9588", 29.23, "Huancabamba", "Huarmaca", 0, 0, 652449, 9389179, 0.356463, "Z13"),
    (115, "M12B1", "C1076-Q9588", 268.39, "Huancabamba", "Huarmaca", 0, 0, 644546, 9389106, 0.34753, "Z13"),
    (116, "19", "C1076-Q9592", 82.09, "Huancabamba", "Huarmaca", 0, 0, 665942, 9391144, 0.537184, "Z13"),
    (117, "M4B4", "C1076-Q9589", 289.91, "Huancabamba", "Huarmaca", 0, 0, 642775, 9388574, 0.319788, "Z14"),
    (118, "M4B3", "C1076-Q9589", 234.07, "Huancabamba", "Huarmaca", 0, 0, 643474, 9385620, 0.322153, "Z14"),
    (119, "10", "C1076-Q9593", 150.21, "Huancabamba", "Huarmaca", 0, 0, 650830, 9382303, 0.546492, "Z14"),
    (120, "16", "C1076-Q9593", 83.33, "Huancabamba", "Huarmaca", 0, 0, 652939, 9382105, 0.628423, "Z14"),
    (121, "4", "C1076-Q9588", 230.1, "Huancabamba", "Huarmaca", 0, 0, 656549, 9382009, 0.660111, "Z14"),
    (122, "51", "C1076-Q9593", 22.93, "Huancabamba", "Huarmaca", 0, 0, 656291, 9379096, 0.523788, "Z14"),
    (123, "76", "C1076-Q9593", 19.62, "Huancabamba", "Huarmaca", 0, 0, 657922, 9377477, 0.492462, "Z14"),
    (124, "80", "C1076-Q9593", 28.83, "Huancabamba", "Huarmaca", 0, 0, 657160, 9373050, 0.593069, "Z14"),
    (125, "71", "C1076-Q9593", 10.67, "Huancabamba", "Huarmaca", 0, 0, 652104, 9373045, 0.557066, "Z14"),
    (126, "8", "C1076-Q9593", 126.95, "Huancabamba", "Huarmaca", 0, 0, 651673, 9373383, 0.554802, "Z14"),
    (127, "20", "C1076-Q9593", 81.33, "Huancabamba", "Huarmaca", 0, 0, 649847, 9376260, 0.48513, "Z14"),
    # ── Bloques adicionales (ampliacion): microcuenca C1081-Q9583 ──────────
    # Fuente: "Bloques Adicionalea.xlsx" (area y MSAVI) y
    # "CENTROIDES BLOQUES ADICIONALEES.xlsx" (coordenadas UTM del centroide).
    (128, "83", "C1081-Q9583", 24.344, "Morropon", "San Juan de Bigote", 0, 0, 639720, 9410622, 0.30545594, "Z08"),
    (129, "84", "C1081-Q9583", 5.097, "Morropon", "San Juan de Bigote", 0, 0, 640237, 9410714, 0.251595558, "Z08"),
    (130, "85", "C1081-Q9583", 11.906, "Morropon", "San Juan de Bigote", 0, 0, 642200, 9411072, 0.228928157, "Z08"),
    (131, "86", "C1081-Q9583", 30.001, "Morropon", "San Juan de Bigote", 0, 0, 642415, 9410216, 0.273471802, "Z08"),
    (132, "87", "C1081-Q9583", 62.219, "Morropon", "San Juan de Bigote", 0, 0, 642882, 9411123, 0.248717766, "Z08"),
]

# Alias para compatibilidad con codigo previo
BLOQUES_128 = BLOQUES_V5

BLOQUES_128_MAP = {b[1]: {"n": b[0], "codigo": b[1], "microcuenca": b[2],
    "area_ha": b[3], "provincia": b[4], "distrito": b[5],
    "accesibilidad": b[6], "dia_evaluacion": b[7],
    "utm_este": b[8], "utm_norte": b[9], "msavi_2024": b[10],
    "zona": b[11] if len(b) > 11 else ""} for b in BLOQUES_128}

# Aliases V5
BLOQUES_V5_MAP = BLOQUES_128_MAP

# Lista de codigos para el dropdown (solo codigo de bloque)
BLOQUES_128_OPCIONES = [b[1] for b in BLOQUES_128]
BLOQUES_V5_OPCIONES = BLOQUES_128_OPCIONES

# Lista de Zonas V5 (Z01..Z14)
ZONAS_V5 = sorted({b[11] for b in BLOQUES_V5 if len(b) > 11 and b[11]})

# ── Centros Poblados por Bloque de Intervencion ──────────────────────
# El catalogo vive en `centros_poblados.py`: ademas de la relacion de centros
# poblados y comunidades campesinas por bloque, trae la demografia INEI de
# cada centro poblado (poblacion total y por sexo, poblacion vulnerable,
# viviendas particulares y coordenadas).
from centros_poblados import CENTROS_POBLADOS_BLOQUE, datos_bloque as _cp_bloque


PROVINCIAS_DISTRITOS = {
    "Ayabaca": ["Frias"],
    "Huancabamba": ["Canchaque","Huancabamba","Huarmaca","Lalaquiz","San Miguel de El Faique"],
    "Morropon": ["Buenos Aires","Chalaco","Chulucanas","La Matanza","Morropon",
                 "Salitral","San Juan de Bigote","Santa Catalina de Mossa",
                 "Santo Domingo","Yamango"],
    "Piura": ["Las Lomas","Tambo Grande"],
    "Sullana": ["Sullana"],
}
PROVINCIAS = list(PROVINCIAS_DISTRITOS.keys())
DISTRITOS_PIURA = [d for ds in PROVINCIAS_DISTRITOS.values() for d in ds]
TIPOS_COBERTURA = ["Arborea","Arbustiva","Herbacea","Mixta"]
VIGOR_COBERTURA = ["Excelente","Bueno","Regular","Deficiente","Muy deficiente"]
CATEGORIAS_PRESUPUESTO = [
    "Mano de obra","Materiales e insumos","Equipos y herramientas",
    "Transporte y logistica","Plantones y semillas","Asistencia tecnica",
    "Supervision y monitoreo","Capacitacion","Gastos administrativos","Otros",
]
FUENTES_FINANCIAMIENTO = [
    "Presupuesto publico","Cooperacion internacional","Canon y sobrecanon",
    "Recursos propios","Donaciones","Otro",
]
ESTADOS_ACTIVIDAD = ["Programado","En ejecucion","Completado","Retrasado","Suspendido"]
ACTIVIDADES_TIPO = [
    "Preparacion de terreno","Produccion de plantones","Plantacion / Revegetacion",
    "Excavacion de zanjas de infiltracion","Construccion de terrazas",
    "Construccion de diques","Mantenimiento y riego","Monitoreo y evaluacion",
    "Capacitacion a comunidades","Supervision tecnica","Elaboracion de informes",
    "Otra actividad",
]
COLORES_ESTADO = {"Pendiente":[231,76,60],"En progreso":[243,156,18],"Verificado":[39,174,96]}

# ── Fichas de Diagnostico Territorial V5 (F-DT-01 a F-DT-05) ────────────
# Fuente: Plantilla_DT_Campo_Check_Validada_V5.xlsx
FICHAS_DT = ["F-DT-01","F-DT-02","F-DT-03","F-DT-04","F-DT-05"]

# Listas de opciones (dropdowns) — extraidas de la hoja '_Listas' del V5
FDT_FORMA_TERRENO = ["Plano", "Ondulado", "Colinoso", "Montañoso", "Muy escarpado"]
FDT_RANGO_PENDIENTE = [
    "0-8% (Plano-lig. inclinado)", "8-15% (Mod. inclinado)",
    "15-25% (Fuert. inclinado)", "25-50% (Mod. escarpado)",
    "50-75% (Escarpado)", ">75% (Muy escarpado)",
]
FDT_POSICION_FISIO = [
    "Cresta / Divortium", "Ladera alta", "Ladera media", "Ladera baja",
    "Pie de ladera", "Terraza aluvial", "Cauce / Ribera",
    "Llanura / Pampa", "Cima (sin exp.)",
]
FDT_EXPOSICION = [
    "Norte", "Sur", "Este", "Oeste", "Noreste",
    "Noroeste", "Sureste", "Suroeste", "Cima (sin dom.)",
]
FDT_RANGO_ALTITUD = [
    "<1000 m (Yunga)", "1000-1500 m (Quechua baja)",
    "1500-2000 m (Quechua media)", "2000-2500 m (Quechua alta)",
    "2500-3000 m (Suni)", "3000-3500 m (Puna baja)",
    ">3500 m (Puna/Jalca)",
]
FDT_NIVEL_EROSION = [
    "Nula", "Ligera (laminar)", "Moderada (surcos)",
    "Fuerte (cárcavas incipientes)", "Severa (cárcavas activas)", "Extrema",
]
FDT_TIPO_CARCAVA = [
    "Surco (<30 cm)", "Cárcava incipiente (30-50 cm)",
    "Cárcava somera (0.5-2 m)", "Cárcava profunda (2-5 m)",
    "Cárcava muy profunda (>5 m)",
]
FDT_ESTADO_CARCAVA = [
    "Activa", "Semi-activa", "Estabilizada con vegetación",
    "Estabilizada con obras", "Inactiva",
]
FDT_CAUSA_CARCAVA = [
    "Sobrepastoreo", "Tala / pérdida de cobertura", "Quema",
    "Surcos de labranza en pendiente", "Caminos / huellas de ganado",
    "Concentración natural de escorrentía", "Socavamiento de cauce",
    "Cambio de uso del suelo", "Otro",
]
FDT_PATRON_CARCAVAS = ["Dendrítico", "Paralelo", "Lineal", "Aislado", "Mixto"]
FDT_URGENCIA = ["Crítica", "Alta", "Media", "Baja"]
FDT_TIPO_ECOSISTEMA = [
    "Páramo", "Bosque Relicto Montano V. Occidental (BMVO)",
    "Bosque Estacionalmente Seco Colina/Montaña (Bes-cm)",
    "Bosque Estacionalmente Seco Llanura (Bes-ll)",
    "Bosque Estacionalmente Seco Ribereño (Bes-rb)",
    "Matorral Andino árido", "Matorral Andino semiárido",
    "Matorral Andino subhúmedo", "Matorral Andino húmedo",
    "Pastizal andino / Jalca", "Agroecosistema / Mosaico",
    "Área urbana / rural", "Otro",
]
FDT_ESTADO_CONSERVACION = [
    "Conservado (sin intervención evidente)", "Levemente alterado",
    "Medianamente alterado", "Alterado (intervención marcada)",
    "Muy alterado / Degradado", "En restauración / Recuperación",
]
FDT_USO_SUELO_DOM = [
    "Forestal protección", "Forestal producción", "Pastoreo extensivo",
    "Pastoreo intensivo", "Agricultura secano", "Agricultura bajo riego",
    "Sin uso aparente / Abandonado", "Uso mixto", "Otro",
]
FDT_REGENERACION = [
    "Abundante (>50 pl./100m²)", "Regular (10-50 pl./100m²)",
    "Escasa (<10 pl./100m²)", "Ausente",
]
FDT_ESTADO_SANITARIO = [
    "Sano", "Enfermo (plaga)", "Enfermo (hongo)", "Daño mecánico",
    "Muerto en pie", "Rebrote vigoroso",
]
FDT_FENOLOGIA = [
    "Vegetativo", "Floración", "Fructificación",
    "Caducifolio (hojas caídas)", "Latencia / Estrés hídrico",
]
FDT_TIPO_COBERTURA = [
    "Bosque denso (>70%)", "Bosque ralo (30-70%)", "Matorral denso",
    "Matorral ralo", "Pastizal natural", "Pastizal cultivado",
    "Cultivo anual", "Cultivo permanente", "Suelo desnudo",
    "Afloramiento rocoso", "Mixto / Mosaico",
]
FDT_ESTRATO = [
    "Arbóreo superior (>15 m)", "Arbóreo medio (8-15 m)",
    "Arbóreo bajo (4-8 m)", "Arbustivo alto (1.5-4 m)",
    "Arbustivo bajo (0.5-1.5 m)", "Herbáceo (<0.5 m)",
    "Epífito", "Trepador",
]
FDT_ORIGEN = ["Nativa", "Endémica", "Introducida", "Invasora"]
FDT_ABUNDANCIA = [
    "Dominante (>40%)", "Abundante (20-40%)", "Frecuente (5-20%)",
    "Ocasional (1-5%)", "Rara (<1%)",
]
FDT_CATEGORIA_INDICADORA = [
    "Indicadora de buen estado", "Indicadora de perturbación",
    "Endémica del Perú", "Endémica norte / Piura",
    "Amenazada (D.S. 043-2006-AG)", "Clave cultural",
]
FDT_ESTADO_UICN = [
    "EX — Extinto", "EW — Extinto en Estado Silvestre",
    "CR — En Peligro Crítico", "EN — En Peligro", "VU — Vulnerable",
    "NT — Casi Amenazado", "LC — Preocupación Menor",
    "DD — Datos Insuficientes", "NE — No Evaluado", "No aplica",
]
FDT_INTENSIDAD = ["Nula", "Ligera", "Moderada", "Fuerte", "Muy fuerte"]
FDT_NIVEL_IND = ["Alto", "Medio", "Bajo"]
FDT_VELOCIDAD = ["Muy rápida", "Rápida", "Moderada", "Lenta", "Estable"]
FDT_REVERSIBILIDAD = [
    "Totalmente reversible", "Parcialmente reversible",
    "Difícilmente reversible", "En recuperación",
]
FDT_TIPO_FUENTE = [
    "Manantial / Puquio", "Quebrada permanente", "Quebrada estacional",
    "Río", "Canal de riego", "Reservorio / Represa", "Laguna / Humedal",
    "Pozo / Galería filtrante", "Bofedal", "Otro",
]
FDT_REGIMEN_HIDRICO = [
    "Permanente", "Estacional (lluvias)", "Intermitente",
    "Efímero", "Ausente",
]
FDT_CALIDAD_AGUA = [
    "Buena (clara, sin olor, sin sedimentos)",
    "Regular (ligeramente turbia o con sedimentos)",
    "Mala (turbia, con olor o color)",
    "Muy mala (contaminación evidente)", "No evaluable",
]
FDT_MODALIDAD_ACCESO = [
    "Vehicular 4x4 hasta el bloque", "Vehicular + caminata <30 min",
    "Vehicular + caminata 30-90 min", "Vehicular + caminata >90 min",
    "Requiere acémila (páramo/jalca)", "Inaccesible en lluvias",
]
FDT_TIPO_VIA = [
    "Nacional asfaltada", "Nacional afirmada", "Departamental asfaltada",
    "Departamental afirmada", "Vecinal afirmada",
    "Trocha carrozable", "Camino de herradura",
]
FDT_NIVEL_TRANSITAB = ["Alto", "Medio", "Bajo"]
FDT_SENAL_CELULAR = ["Completa", "Parcial", "Intermitente", "Sin señal"]
FDT_OPERADOR = ["Movistar", "Claro", "Entel", "Bitel", "Otro", "Sin señal"]
FDT_SI_NO = ["Sí", "No"]
FDT_SI_NO_NA = ["Sí", "No", "No aplica"]

# Causas predefinidas para la matriz de F-DT-04 (16 filas fijas)
FDT04_CAUSAS_LABELS = [
    "Sobrepastoreo (caprino/vacuno)", "Tala para leña", "Tala para carbón",
    "Tala para madera", "Quema (renovación de pastos)",
    "Quema accidental / Incendio", "Cambio de uso a agricultura",
    "Cambio de uso a pastoreo", "Expansión urbana / vial",
    "Minería informal", "Extracción de áridos (cauces)",
    "Especies invasoras", "Erosión natural severa",
    "Sequía prolongada / CC", "Plagas o enfermedades forestales", "Otro",
]
# Indicadores cuantitativos predefinidos para la matriz de F-DT-04 (8 filas)
FDT04_INDICADORES_LABELS = [
    ("Cobertura vegetal total", "%", ">60% bueno; 30-60% medio; <30% malo"),
    ("Porcentaje de suelo desnudo", "%", "<10% bueno; 10-30% medio; >30% malo"),
    ("Densidad de cárcavas", "N°/ha", "0 nulo; 1-3 medio; >3 alto"),
    ("Presencia de especies invasoras", "% área", "<5% bueno; 5-20% medio; >20% alto"),
    ("Carga ganadera estimada", "UA/ha", "Según tipo de ecosistema"),
    ("Frecuencia de quemas últimos 5 años", "N°", "0 nulo; 1-2 medio; >2 alto"),
    ("% área con pendiente >50%", "%", "Factor de susceptibilidad"),
    ("Distancia a vía vecinal más cercana", "m", "A menor distancia → mayor presión"),
]

# ── Fichas de Diagnostico Social V3 (F-DS-01 a F-DS-07) ──────────────────
# Fuente unica de verdad: fds_listas.py (generado desde la hoja `_Listas` de
# la Plantilla de Diagnostico Social validada V3). Las 7 fichas reemplazan a
# los 5 formatos anteriores y usan celdas de validacion (desplegables) que
# replican las listas oficiales del Excel.
import fds_listas as FL

FICHAS_DS = ["F-DS-01", "F-DS-02", "F-DS-03", "F-DS-04",
             "F-DS-05", "F-DS-06", "F-DS-07"]

FICHAS_DS_TITULOS = {
    "F-DS-01": "Diagnostico Socioeconomico del CP / Comunidad",
    "F-DS-02": "Mapeo y Analisis de Actores Clave",
    "F-DS-03": "Entrevista Semiestructurada a Autoridades / Lideres",
    "F-DS-04": "Acta de Taller Participativo",
    "F-DS-05": "Conflictos Socioambientales y Oportunidades",
    "F-DS-06": "Percepcion Local de Peligros y Cambio Climatico",
    "F-DS-07": "Disposicion a Participar y Consentimiento Previo Informado",
}

# Listas Si/No reutilizadas en multiples fichas
DS_SINO = FL.L_SINO                       # ["Si", "No"]
DS_SINONA = FL.L_SINONA                   # ["Si", "No", "No aplica"]

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""<style>
.main-header{background:#2C3E50;padding:1rem 2rem;border-radius:.5rem;margin-bottom:1rem}
.main-header h1{color:#fff!important;margin:0!important;font-size:1.8rem!important}
.main-header p{color:#BDC3C7!important;margin:0!important}
.edit-mode-banner{background:linear-gradient(90deg,#f39c12,#e67e22);color:#fff;padding:.6rem 1.2rem;
    border-radius:.4rem;margin-bottom:.8rem;font-weight:600;display:flex;align-items:center;gap:.5rem}
.edit-mode-banner .icon{font-size:1.2rem}
.dup-warning{background:#fff3cd;border-left:4px solid #ffc107;padding:.8rem 1rem;border-radius:0 .4rem .4rem 0;margin:.5rem 0}
</style>""", unsafe_allow_html=True)

st.markdown("""<div class="main-header">
<h1>\U0001F331 IN Piura</h1>
<p>Plan de Ingreso | Verificacion de Campo | Cuenca Alta del Rio Piura</p>
</div>""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────
pagina = st.sidebar.selectbox("Navegacion", [
    "Panel de Control","Bloques de Intervencion","Inspeccion de Campo",
    "Indicadores de Calidad","Diagnostico Territorial","Diagnostico Social",
    "Elementos Expuestos (AdR)",
    "Presupuesto","Cronograma",
    "Georreferenciacion","ODK / KoBoToolbox","Reportes",
    "Conversor PDF -> Excel",
])
st.sidebar.markdown("---")
st.sidebar.markdown("**IN Piura** v2.1 Web\n\nRestauracion de Ecosistemas\nCuenca Alta del Rio Piura")

# ── Helpers ───────────────────────────────────────────────────────────────
def _bloques_map():
    return {b["codigo"]: b["id"]
            for b in _cached_obtener_bloques(_cache_version())}

def _distritos(prov):
    return PROVINCIAS_DISTRITOS.get(prov, DISTRITOS_PIURA) if prov else DISTRITOS_PIURA

def _resolver_microcuenca(bloque_label):
    """Resuelve la microcuenca para un bloque dado su label 'CODIGO - TIPO'.
    Busca primero en la BD (cacheada) y luego en BLOQUES_128_MAP como fallback."""
    codigo = bloque_label.split(" - ")[0].strip() if " - " in bloque_label else bloque_label.strip()
    # Buscar en BD (cacheada)
    for b in _cached_obtener_bloques(_cache_version()):
        if b["codigo"] == codigo:
            mc = b.get("microcuenca", "") or ""
            if mc and mc in MICROCUENCAS:
                return mc
            break
    # Fallback: buscar en el catalogo de bloques predefinidos
    datos = BLOQUES_128_MAP.get(codigo, {})
    mc = datos.get("microcuenca", "")
    if mc and mc in MICROCUENCAS:
        return mc
    return ""


def _resolver_datos_bloque(bloque_label):
    """Resuelve metadatos completos del bloque (microcuenca, provincia, distrito,
    superficie ha y coordenadas UTM del centroide).

    Combina datos de la BD (si existen) con BLOQUES_128_MAP como respaldo.
    Retorna dict con claves: microcuenca, provincia, distrito, area_ha,
    utm_este, utm_norte (cualquier valor faltante queda como cadena vacía o 0).
    """
    codigo = bloque_label.split(" - ")[0].strip() if " - " in bloque_label else bloque_label.strip()
    info = {"microcuenca": "", "provincia": "", "distrito": "",
            "area_ha": 0.0, "utm_este": 0.0, "utm_norte": 0.0}
    # 1) Buscar en BD
    for b in _cached_obtener_bloques(_cache_version()):
        if b["codigo"] == codigo:
            info["microcuenca"] = (b.get("microcuenca") or "")
            info["provincia"] = (b.get("provincia") or "")
            info["distrito"] = (b.get("distrito") or "")
            try: info["area_ha"] = float(b.get("area_ha") or 0)
            except (TypeError, ValueError): info["area_ha"] = 0.0
            try: info["utm_este"] = float(b.get("utm_este") or 0)
            except (TypeError, ValueError): info["utm_este"] = 0.0
            try: info["utm_norte"] = float(b.get("utm_norte") or 0)
            except (TypeError, ValueError): info["utm_norte"] = 0.0
            break
    # 2) Completar campos faltantes con catalogo predefinido
    fallback = BLOQUES_128_MAP.get(codigo, {})
    if fallback:
        if not info["microcuenca"]:
            info["microcuenca"] = fallback.get("microcuenca", "")
        if not info["provincia"]:
            info["provincia"] = fallback.get("provincia", "")
        if not info["distrito"]:
            info["distrito"] = fallback.get("distrito", "")
        if not info["area_ha"]:
            try: info["area_ha"] = float(fallback.get("area_ha") or 0)
            except (TypeError, ValueError): pass
        if not info["utm_este"]:
            try: info["utm_este"] = float(fallback.get("utm_este") or 0)
            except (TypeError, ValueError): pass
        if not info["utm_norte"]:
            try: info["utm_norte"] = float(fallback.get("utm_norte") or 0)
            except (TypeError, ValueError): pass
    return info

# ══════════════════════════════════════════════════════════════════════════
# PANEL DE CONTROL
# ══════════════════════════════════════════════════════════════════════════
def pagina_dashboard():
    st.subheader("Panel de Control - Resumen Ejecutivo")
    stats = _cached_obtener_estadisticas(_cache_version())
    c1,c2,c3,c4,c5,c6 = st.columns(6)
    c1.metric("Total Bloques", stats["total_bloques"])
    c2.metric("Area Total", f"{stats['area_total_ha']:.2f} ha")
    c3.metric("Inspecciones", stats["total_inspecciones"])
    c4.metric("Avance Promedio", f"{stats['avance_promedio']:.1f}%")
    c5.metric("Diag. Territorial", stats.get("total_diagnosticos", 0))
    c6.metric("Diag. Social", stats.get("total_diagnosticos_sociales", 0))
    st.markdown("---")
    ci,cd = st.columns(2)
    with ci:
        st.markdown("**Distribucion por Estado**")
        tb = max(stats["total_bloques"],1)
        for e in ["Pendiente","En progreso","Verificado"]:
            n = stats["bloques_por_estado"].get(e,0)
            st.progress(n/tb, text=f"{e}: {n} ({n/tb*100:.1f}%)")
    with cd:
        st.markdown("**Distribucion por Tipo**")
        if stats["bloques_por_tipo"]:
            df = pd.DataFrame(list(stats["bloques_por_tipo"].items()), columns=["Tipo","Cantidad"])
            st.bar_chart(df.set_index("Tipo"))
        else:
            st.info("Sin bloques.")
    st.markdown("---")
    cp,cc = st.columns(2)
    with cp:
        st.markdown("**Resumen Presupuestal**")
        pl,ej = stats["presupuesto_planificado"],stats["presupuesto_ejecutado"]
        pe = (ej/pl*100) if pl>0 else 0
        st.metric("Planificado",f"S/ {pl:,.2f}"); st.metric("Ejecutado",f"S/ {ej:,.2f}")
        st.progress(min(pe/100,1.0), text=f"Ejecucion: {pe:.1f}%")
        st.caption(f"Saldo: S/ {pl-ej:,.2f}")
    with cc:
        st.markdown("**Cronograma**")
        ae = stats["actividades_por_estado"]; ta = sum(ae.values()) if ae else 0
        st.caption(f"Total actividades: {ta}")
        for en in ["Programado","En ejecucion","Completado","Retrasado"]:
            cn = ae.get(en,0); st.progress((cn/ta) if ta>0 else 0, text=f"{en}: {cn}")
    st.markdown("---")
    st.markdown("**Resumen de Bloques**")
    res = _cached_obtener_resumen_bloques(_cache_version())
    if res:
        def _fmt_area(v):
            try:
                return f"{float(v):.4f}" if v not in (None, "", 0, 0.0) else ""
            except (TypeError, ValueError):
                return ""
        def _fmt_avance(b):
            v = b.get("ultimo_avance")
            if v in (None, "", 0, 0.0) and not b.get("total_inspecciones"):
                return ""
            try:
                return f"{float(v or 0):.1f}"
            except (TypeError, ValueError):
                return ""
        def _fmt_int(v):
            try:
                iv = int(v)
                return iv if iv else ""
            except (TypeError, ValueError):
                return ""
        st.dataframe(pd.DataFrame([{
            "Codigo": b["codigo"],
            "Tipo": b.get("tipo_intervencion", "") or "",
            "Distrito": b.get("distrito", "") or "",
            "Area (ha)": _fmt_area(b.get("area_hectareas")),
            "Estado": b.get("estado", "") or "",
            "Avance %": _fmt_avance(b),
            "Inspecciones": _fmt_int(b.get("total_inspecciones")),
        } for b in res]),
            use_container_width=True, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════
# BLOQUES DE INTERVENCION
# ══════════════════════════════════════════════════════════════════════════
def _extraer_codigo_bloque_128(opcion):
    """Retorna el codigo de bloque directamente (el dropdown solo muestra codigos)."""
    if not opcion:
        return None
    return opcion.strip()

def _bl_load_edit(bloque):
    """Carga un registro de bloque en session_state para edicion."""
    st.session_state["bl_edit_id"] = bloque["id"]
    st.session_state["bl_codigo"] = bloque["codigo"]
    st.session_state["bl_cuenca"] = bloque.get("cuenca", "Cuenca Alta del Rio Piura") or "Cuenca Alta del Rio Piura"
    st.session_state["bl_microcuenca"] = bloque.get("microcuenca", "") or ""
    st.session_state["bl_provincia"] = bloque.get("provincia", "") or ""
    st.session_state["bl_distrito"] = bloque.get("distrito", "") or ""
    st.session_state["bl_tipo"] = bloque.get("tipo_intervencion", "") or ""
    st.session_state["bl_utm_este"] = str(bloque.get("utm_este", 0) or 0)
    st.session_state["bl_utm_norte"] = str(bloque.get("utm_norte", 0) or 0)
    st.session_state["bl_utm_zona"] = bloque.get("utm_zona", "17S") or "17S"
    st.session_state["bl_altitud"] = str(bloque.get("altitud", 0) or 0)
    st.session_state["bl_area"] = str(bloque.get("area_hectareas", 0) or 0)
    st.session_state["bl_responsable"] = bloque.get("responsable", "") or ""
    st.session_state["bl_estado"] = bloque.get("estado", "Pendiente") or "Pendiente"

def pagina_bloques():
    st.subheader("Bloques de Intervencion")

    # Inicializar estado de edicion
    if "bl_edit_id" not in st.session_state:
        st.session_state["bl_edit_id"] = None

    edit_id = st.session_state.get("bl_edit_id")

    cf,ct = st.columns([1,2])
    with cf:
        if edit_id:
            st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                        f'Modo Edicion - Bloque ID {edit_id}</div>', unsafe_allow_html=True)
            if st.button("Cancelar edicion", key="bl_cancel_edit"):
                st.session_state["bl_edit_id"] = None
                for k in list(st.session_state.keys()):
                    if k.startswith("bl_") and k != "bl_edit_id":
                        del st.session_state[k]
                st.rerun()
        else:
            st.markdown("**Registro de Bloque**")

        # Selector rapido de los bloques V5 (solo en modo nuevo)
        if not edit_id:
            st.markdown(f"##### Seleccion rapida - {len(BLOQUES_V5)} Bloques de Intervencion V5")
            sel_79 = st.selectbox(
                "Seleccionar bloque predefinido",
                ["(Seleccionar bloque predefinido)"] + BLOQUES_V5_OPCIONES,
                key="sel_bloque_128",
                help=f"Seleccione un bloque de la lista de {len(BLOQUES_V5)} bloques V5 para autocompletar los campos"
            )

            # Determinar valores por defecto segun seleccion
            cod_sel = _extraer_codigo_bloque_128(sel_79 if sel_79 != "(Seleccionar bloque predefinido)" else "")
            datos_79 = BLOQUES_128_MAP.get(cod_sel, {}) if cod_sel else {}

            def_codigo = datos_79.get("codigo", "")
            def_microcuenca = datos_79.get("microcuenca", "")
            def_area = str(datos_79.get("area_ha", "0"))
            def_provincia = datos_79.get("provincia", "")
            def_distrito = datos_79.get("distrito", "")
            def_accesibilidad = datos_79.get("accesibilidad", 0)
            def_dia = datos_79.get("dia_evaluacion", 0)

            if datos_79:
                acc_txt = "Acceso limitado" if def_accesibilidad == 1 else "Acceso normal"
                cp_data = _cp_bloque(def_codigo)
                cp_txt = ", ".join(cp_data.get("centros_poblados", [])) or "—"
                cc_txt = ", ".join(cp_data.get("comunidades_campesinas", [])) or "—"
                pob_txt = ""
                if cp_data.get("poblacion_total"):
                    pob_txt = (f" | Poblacion: {cp_data['poblacion_total']:,} hab. "
                               f"({cp_data.get('viviendas', 0):,} viviendas)")
                st.info(f"Bloque **{def_codigo}** | Microcuenca: {def_microcuenca} | "
                        f"{def_distrito} ({def_provincia}) | {def_area} ha | "
                        f"{acc_txt} | Dia eval.: {def_dia}\n\n"
                        f"CC.PP.: {cp_txt} | Com. Campesinas: {cc_txt}{pob_txt} | "
                        f"UTM: {datos_79.get('utm_este', 0)} E, {datos_79.get('utm_norte', 0)} N")
        else:
            datos_79 = {}
            def_codigo = st.session_state.get("bl_codigo", "")
            def_microcuenca = st.session_state.get("bl_microcuenca", "")
            def_area = st.session_state.get("bl_area", "0")
            def_provincia = st.session_state.get("bl_provincia", "")
            def_distrito = st.session_state.get("bl_distrito", "")

        st.markdown("---")
        with st.form("form_bloque", clear_on_submit=False):
            codigo = st.text_input("Codigo de bloque",
                value=st.session_state.get("bl_codigo", def_codigo) if edit_id else def_codigo)
            cuenca = st.text_input("Cuenca",
                value=st.session_state.get("bl_cuenca", "Cuenca Alta del Rio Piura") if edit_id else "Cuenca Alta del Rio Piura")
            # Microcuenca: preseleccionar
            mc_idx = 0
            mc_val = st.session_state.get("bl_microcuenca", def_microcuenca) if edit_id else def_microcuenca
            if mc_val and mc_val in MICROCUENCAS:
                mc_idx = MICROCUENCAS.index(mc_val) + 1
            microcuenca = st.selectbox("Microcuenca", [""]+MICROCUENCAS, index=mc_idx)
            # Provincia: preseleccionar
            prov_idx = 0
            prov_val = st.session_state.get("bl_provincia", def_provincia) if edit_id else def_provincia
            if prov_val and prov_val in PROVINCIAS:
                prov_idx = PROVINCIAS.index(prov_val) + 1
            provincia = st.selectbox("Provincia", [""]+PROVINCIAS, index=prov_idx)
            # Distrito: preseleccionar
            dist_list = _distritos(provincia)
            dist_idx = 0
            dist_val = st.session_state.get("bl_distrito", def_distrito) if edit_id else def_distrito
            if dist_val and dist_val in dist_list:
                dist_idx = dist_list.index(dist_val) + 1
            distrito = st.selectbox("Distrito", [""]+dist_list, index=dist_idx)
            # Tipo intervencion
            tipo_idx = 0
            if edit_id:
                tipo_val = st.session_state.get("bl_tipo", "")
                if tipo_val and tipo_val in TIPOS_INTERVENCION:
                    tipo_idx = TIPOS_INTERVENCION.index(tipo_val)
            tipo = st.selectbox("Tipo intervencion", TIPOS_INTERVENCION, index=tipo_idx)
            a1,a2 = st.columns(2)
            def_ue = str(datos_79.get("utm_este", 0)) if datos_79 else "0"
            def_un = str(datos_79.get("utm_norte", 0)) if datos_79 else "0"
            ue = a1.text_input("UTM Este", st.session_state.get("bl_utm_este", def_ue) if edit_id else def_ue)
            un = a2.text_input("UTM Norte", st.session_state.get("bl_utm_norte", def_un) if edit_id else def_un)
            b1,b2 = st.columns(2)
            uz = b1.text_input("Zona UTM", st.session_state.get("bl_utm_zona", "17S") if edit_id else "17S")
            alt = b2.text_input("Altitud", st.session_state.get("bl_altitud", "0") if edit_id else "0")
            area = st.text_input("Area (ha)",
                value=st.session_state.get("bl_area", def_area) if edit_id else (def_area if datos_79 else "0"))
            resp = st.text_input("Responsable",
                value=st.session_state.get("bl_responsable", "") if edit_id else "")
            # Estado: preseleccionar
            est_idx = 0
            if edit_id:
                est_val = st.session_state.get("bl_estado", "Pendiente")
                if est_val and est_val in ESTADOS_BLOQUE:
                    est_idx = ESTADOS_BLOQUE.index(est_val)
            estado = st.selectbox("Estado", ESTADOS_BLOQUE, index=est_idx)
            btn_label = "Actualizar Bloque" if edit_id else "Guardar"
            guardar = st.form_submit_button(btn_label, type="primary")
        if guardar:
            if not codigo: st.warning("Codigo obligatorio.")
            elif not distrito: st.warning("Seleccione distrito.")
            else:
                try:
                    if edit_id:
                        db.actualizar_bloque(bloque_id=edit_id,codigo=codigo,
                            tipo_intervencion=tipo,cuenca=cuenca,
                            distrito=distrito,utm_este=float(ue),utm_norte=float(un),
                            utm_zona=uz,area_hectareas=float(area),estado=estado,
                            altitud=float(alt or 0),responsable=resp,
                            microcuenca=microcuenca,provincia=provincia)
                        _invalidar_cache()
                        st.session_state["bl_edit_id"] = None
                        for k in list(st.session_state.keys()):
                            if k.startswith("bl_") and k != "bl_edit_id":
                                del st.session_state[k]
                        st.success(f"Bloque {codigo} actualizado correctamente.")
                    else:
                        db.insertar_bloque(codigo=codigo,tipo_intervencion=tipo,cuenca=cuenca,
                            distrito=distrito,utm_este=float(ue),utm_norte=float(un),
                            utm_zona=uz,area_hectareas=float(area),estado=estado,
                            altitud=float(alt or 0),responsable=resp,
                            microcuenca=microcuenca,provincia=provincia)
                        _invalidar_cache()
                        st.success(f"Bloque {codigo} registrado.")
                    st.rerun()
                except Exception as e: st.error(f"Error: {e}")
    with ct:
        st.markdown("**Bloques Registrados**")
        st.caption("Haga clic en **Editar** para modificar un bloque existente y evitar duplicidades.")
        busq = st.text_input("Buscar","",key="busq_bl")
        bloques = db.buscar_bloques(busq) if busq else _cached_obtener_bloques(_cache_version())
        if bloques:
            # Paginacion
            bloques_pag, total_pags, pag_actual = _paginar(bloques, "pag_bloques")
            _controles_paginacion(total_pags, pag_actual, "pag_bloques")
            # Tabla con botones de edicion por fila
            header_cols = st.columns([0.5, 1.2, 1.2, 1.2, 1, 1, 0.8, 0.8, 0.7])
            headers = ["ID", "Codigo", "Microcuenca", "Tipo", "Provincia", "Distrito", "Area", "Estado", ""]
            for col, h in zip(header_cols, headers):
                col.markdown(f"**{h}**")
            st.markdown("---")
            for b in bloques_pag:
                row_cols = st.columns([0.5, 1.2, 1.2, 1.2, 1, 1, 0.8, 0.8, 0.7])
                row_cols[0].write(b["id"])
                row_cols[1].write(b.get("codigo", "") or "")
                row_cols[2].write(b.get("microcuenca", "") or "")
                row_cols[3].write(b.get("tipo_intervencion", "") or "")
                row_cols[4].write(b.get("provincia", "") or "")
                row_cols[5].write(b.get("distrito", "") or "")
                area_val = b.get("area_hectareas")
                try:
                    area_txt = f"{float(area_val):.4f}" if area_val not in (None, "", 0, 0.0) else ""
                except (TypeError, ValueError):
                    area_txt = ""
                row_cols[6].write(area_txt)
                row_cols[7].write(b.get("estado", "Pendiente") or "Pendiente")
                if row_cols[8].button("Editar", key=f"edit_bl_{b['id']}", type="primary"):
                    _bl_load_edit(b)
                    st.rerun()
            st.markdown("---")
            bm = {b["codigo"]: b["id"] for b in bloques}
            st.markdown("**Eliminar bloque**")
            sel = st.selectbox("Seleccionar bloque para eliminar",[""]+list(bm.keys()),key="del_bl")
            if sel and sel in bm:
                # Borrar un bloque arrastra en cascada todo lo registrado sobre
                # el, asi que primero se muestra que se perderia y se ofrece el
                # respaldo completo antes de habilitar el borrado.
                try:
                    vinculados = db.contar_registros_vinculados(bm[sel])
                except Exception as e:
                    vinculados = {}
                    st.error(f"No se pudo verificar los registros vinculados: {e}")
                etiquetas_vinc = {
                    "inspecciones": "inspecciones de campo",
                    "indicadores_calidad": "indicadores de calidad",
                    "diagnostico_territorial": "diagnosticos territoriales",
                    "diagnostico_social": "fichas de diagnostico social",
                    "elementos_expuestos": "fichas de elementos expuestos",
                    "presupuesto": "partidas de presupuesto",
                    "cronograma": "actividades de cronograma",
                }
                total_vinc = sum(vinculados.values())
                if total_vinc:
                    detalle = ", ".join(f"{n} {etiquetas_vinc.get(t, t)}"
                                        for t, n in vinculados.items())
                    st.error(
                        f"Eliminar el bloque **{sel}** borrara tambien, en cascada, "
                        f"**{total_vinc} registro(s)**: {detalle}. Esta accion no se "
                        "puede deshacer.", icon="🛑")
                else:
                    st.info(f"El bloque **{sel}** no tiene registros vinculados.",
                            icon="ℹ️")
                if st.button("💾 Descargar respaldo completo antes de borrar",
                             key="bl_del_respaldo"):
                    try:
                        st.session_state["respaldo_bytes"] = \
                            exp_diag.exportar_respaldo_completo(db.respaldo_completo())
                        st.session_state["respaldo_nombre"] = (
                            f"Respaldo_IN_Piura_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
                    except Exception as e:
                        st.error(f"No se pudo generar el respaldo: {e}")
                if st.session_state.get("respaldo_bytes"):
                    st.download_button(
                        "⬇️ Descargar respaldo (Excel)",
                        data=st.session_state["respaldo_bytes"],
                        file_name=st.session_state["respaldo_nombre"],
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        key="bl_del_respaldo_dl")
                confirmar_del = st.checkbox(
                    f"Confirmo que quiero eliminar el bloque {sel}"
                    + (f" y sus {total_vinc} registro(s) vinculado(s)" if total_vinc else ""),
                    key="bl_del_confirm")
                if st.button("Eliminar bloque", key="btn_del_bl", disabled=not confirmar_del):
                    try:
                        db.eliminar_bloque(bm[sel])
                        _invalidar_cache()
                        st.session_state.pop("bl_del_confirm", None)
                        _flash(f"Bloque {sel} eliminado correctamente.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error al eliminar bloque: {e}")

        # ── Sincronizacion ADITIVA del catalogo (no destructiva) ───────────
        st.markdown("---")
        st.markdown("### Sincronizar catalogo de bloques (sin borrar datos)")
        st.caption("Unica via para dar de alta bloques: **aditiva**. Inserta los "
                   "bloques del catalogo que faltan y rellena centroides vacios. "
                   "No borra ni modifica ningun bloque, inspeccion, diagnostico ni "
                   "registro ya existente.")
        # Se compara siempre contra el total de la BD, no contra el resultado
        # filtrado por el buscador de arriba.
        catalogo_dicts = [{
            "codigo": b[1], "microcuenca": b[2], "area_ha": b[3],
            "provincia": b[4], "distrito": b[5],
            "utm_este": b[8], "utm_norte": b[9],
        } for b in BLOQUES_V5]
        codigos_bd = {b["codigo"] for b in _cached_obtener_bloques(_cache_version())}
        faltantes_cat = [b for b in BLOQUES_V5 if b[1] not in codigos_bd]
        try:
            coords_pend = db.bloques_con_coordenadas_faltantes(catalogo_dicts)
        except Exception:
            coords_pend = []

        if not faltantes_cat and not coords_pend:
            st.success(f"La base de datos ya contiene los {len(BLOQUES_V5)} bloques "
                       "del catalogo V5, con sus centroides. No hay nada que sincronizar.")
        else:
            if faltantes_cat:
                st.warning(
                    f"Hay **{len(faltantes_cat)}** bloque(s) del catalogo V5 que aun no "
                    f"existen en la base de datos: **{', '.join(b[1] for b in faltantes_cat)}**.",
                    icon="ℹ️")
                st.dataframe(pd.DataFrame([{
                    "Bloque": b[1], "Microcuenca": b[2], "Area (ha)": b[3],
                    "Provincia": b[4], "Distrito": b[5],
                    "Zona": b[11] if len(b) > 11 else "",
                    "UTM Este": b[8], "UTM Norte": b[9],
                } for b in faltantes_cat]), use_container_width=True, hide_index=True)
            if coords_pend:
                st.info(
                    f"Ademas, **{len(coords_pend)}** bloque(s) ya registrados tienen el "
                    f"centroide en 0 y el catalogo si lo trae: "
                    f"**{', '.join(c[0] for c in coords_pend)}**. Se rellenara la "
                    "coordenada vacia; una coordenada ya cargada nunca se sobrescribe.",
                    icon="📍")
            etiqueta_btn = ("➕ Agregar bloques faltantes" if faltantes_cat
                            else "📍 Completar centroides faltantes")
            if st.button(etiqueta_btn, key="bl_sync_cat", type="primary"):
                try:
                    res = db.sincronizar_bloques_catalogo(catalogo_dicts)
                    _invalidar_cache()
                    partes = []
                    if res["insertados"]:
                        partes.append(f"{len(res['insertados'])} bloque(s) agregado(s): "
                                      f"{', '.join(res['insertados'])}")
                    if res["coords_actualizadas"]:
                        partes.append(f"{len(res['coords_actualizadas'])} centroide(s) "
                                      f"completado(s): {', '.join(res['coords_actualizadas'])}")
                    _flash(". ".join(partes) + "." if partes else "No hubo cambios que aplicar.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error al sincronizar bloques: {e}")

        st.markdown("---")
        with st.expander(f"Tabla de Referencia - {len(BLOQUES_V5)} Bloques de Intervencion V5", expanded=False):
            st.caption("Fuente: Plantilla_DT_Campo_Check_Validada_V5.xlsx - Base de datos completa del proyecto IN Piura")
            df_v5 = pd.DataFrame([{
                "N":b[0], "Bloque":b[1], "Microcuenca":b[2],
                "Area (ha)":b[3], "Provincia":b[4], "Distrito":b[5],
                "Zona": b[11] if len(b) > 11 else "",
                "UTM Este": b[8], "UTM Norte": b[9],
                "MSAVI 2024":b[10],
            } for b in BLOQUES_V5])
            st.dataframe(df_v5, use_container_width=True, hide_index=True, height=400)

# ══════════════════════════════════════════════════════════════════════════
# INSPECCION DE CAMPO
# ══════════════════════════════════════════════════════════════════════════
def pagina_inspeccion():
    st.subheader("Inspeccion de Campo")
    bm = _bloques_map()
    if not bm: st.warning("Registre un bloque primero."); return

    # Inicializar estado de edicion
    if "insp_edit_id" not in st.session_state:
        st.session_state["insp_edit_id"] = None

    edit_id = st.session_state.get("insp_edit_id")

    if edit_id:
        st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                    f'Modo Edicion - Inspeccion ID {edit_id}</div>', unsafe_allow_html=True)
        if st.button("Cancelar edicion", key="insp_cancel_edit"):
            st.session_state["insp_edit_id"] = None
            for k in list(st.session_state.keys()):
                if k.startswith("insp_e_"):
                    del st.session_state[k]
            st.rerun()

    # Selector de bloque FUERA del form para auto-enlazar microcuenca
    opciones_bloque = list(bm.keys())
    # En modo edicion, preseleccionar el bloque
    bl_idx = 0
    if edit_id:
        bl_code = st.session_state.get("insp_e_bloque", "")
        for i, op in enumerate(opciones_bloque):
            if bl_code and bl_code in op:
                bl_idx = i
                break
    bl = st.selectbox("Bloque", opciones_bloque, index=bl_idx, key="insp_bloque")

    # Auto-resolver microcuenca del bloque seleccionado
    mc_auto = _resolver_microcuenca(bl)
    if mc_auto:
        mc_idx = MICROCUENCAS.index(mc_auto) + 1
        st.info(f"Microcuenca vinculada automaticamente: **{mc_auto}**")
    else:
        mc_idx = 0
    if edit_id:
        mc_val = st.session_state.get("insp_e_mc", "")
        if mc_val and mc_val in MICROCUENCAS:
            mc_idx = MICROCUENCAS.index(mc_val) + 1

    # Carga de archivos PDF (fuera del form por limitaciones de Streamlit)
    if not edit_id:
        pdf_files = st.file_uploader(
            "Adjuntar archivos PDF (max. 25 MB por archivo)",
            type=["pdf"], accept_multiple_files=True, key="insp_pdf_upload")
        if pdf_files:
            for f in pdf_files:
                if f.size > 25 * 1024 * 1024:
                    st.warning(f"El archivo '{f.name}' excede 25 MB y no sera adjuntado.")
            st.info(f"{len(pdf_files)} archivo(s) PDF seleccionado(s)")
    else:
        pdf_files = None

    # Valores de edicion
    _now = datetime.now()
    def_fecha = _now
    def_hora = _now.time().replace(second=0, microsecond=0)
    def_inspector = ""
    def_clima_idx = 0
    def_avance = 0.0
    def_obs = ""
    def_desv = ""
    def_ver = f"VER-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"
    if edit_id:
        def_inspector = st.session_state.get("insp_e_inspector", "")
        def_clima = st.session_state.get("insp_e_clima", "")
        if def_clima and def_clima in CONDICIONES_CLIMATICAS:
            def_clima_idx = CONDICIONES_CLIMATICAS.index(def_clima) + 1
        def_avance = float(st.session_state.get("insp_e_avance", 0))
        def_obs = st.session_state.get("insp_e_obs", "")
        def_desv = st.session_state.get("insp_e_desv", "")
        def_ver = st.session_state.get("insp_e_ver", def_ver)
        _fecha_e = (st.session_state.get("insp_e_fecha", "") or "").strip()
        for _fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                _parsed = datetime.strptime(_fecha_e, _fmt)
                def_fecha = _parsed
                if _fmt != "%Y-%m-%d":
                    def_hora = _parsed.time().replace(second=0, microsecond=0)
                break
            except (ValueError, TypeError):
                continue

    with st.form("form_insp", clear_on_submit=not edit_id):
        mc = st.selectbox("Microcuenca", [""] + MICROCUENCAS, index=mc_idx)
        c_fh1, c_fh2 = st.columns(2)
        fecha = c_fh1.date_input("Fecha de visita", value=def_fecha,
                              min_value=FECHA_MIN_PROYECTO, max_value=date.today(),
                              help="Seleccione la fecha de la visita de campo")
        hora = c_fh2.time_input("Hora de visita", value=def_hora,
                              help="Seleccione la hora de la visita de campo")
        inspector = st.text_input("Inspector", value=def_inspector)
        clima = st.selectbox("Condiciones climaticas", [""] + CONDICIONES_CLIMATICAS, index=def_clima_idx)
        avance = st.number_input("Avance fisico (%)", 0.0, 100.0, def_avance)
        obs = st.text_area("Observaciones tecnicas", value=def_obs)
        desv = st.text_area("Desviaciones observadas al Plan de Trabajo", value=def_desv)
        ver = st.text_input("Codigo de verificacion", value=def_ver)
        btn_label = "Actualizar Inspeccion" if edit_id else "Guardar Inspeccion"
        guardar = st.form_submit_button(btn_label, type="primary")
    if guardar:
        if not inspector: st.warning("Inspector obligatorio.")
        else:
            try:
                fecha_hora_str = datetime.combine(fecha, hora).strftime("%Y-%m-%d %H:%M:%S")
                fecha_str = fecha.strftime("%Y-%m-%d")
                if edit_id:
                    db.actualizar_inspeccion(inspeccion_id=edit_id,
                        fecha_visita=fecha_hora_str,
                        inspector=inspector, condiciones_climaticas=clima,
                        avance_fisico=avance, observaciones=obs, desviaciones=desv,
                        codigo_verificacion=ver, microcuenca=mc)
                    _invalidar_cache()
                    st.session_state["insp_edit_id"] = None
                    for k in list(st.session_state.keys()):
                        if k.startswith("insp_e_"):
                            del st.session_state[k]
                    st.success("Inspeccion actualizada."); st.rerun()
                else:
                    # Verificar duplicados antes de insertar (compara solo la fecha)
                    existentes = db.obtener_inspecciones_por_bloque(bm[bl])
                    dup = [e for e in existentes
                           if (e["fecha_visita"] or "")[:10] == fecha_str
                           and e["inspector"] == inspector]
                    if dup:
                        st.warning(f"Ya existe una inspeccion para este bloque en {fecha_str} "
                                   f"por {inspector}. Use 'Editar' en el historial para modificarla.")
                    else:
                        # Guardar archivos PDF adjuntos
                        rutas_pdf = []
                        if pdf_files:
                            pdf_dir = os.path.join(os.path.dirname(__file__), "adjuntos_pdf")
                            os.makedirs(pdf_dir, exist_ok=True)
                            for f in pdf_files:
                                if f.size <= 25 * 1024 * 1024:
                                    nombre_pdf = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{f.name}"
                                    ruta_pdf = os.path.join(pdf_dir, nombre_pdf)
                                    with open(ruta_pdf, "wb") as fp:
                                        fp.write(f.getbuffer())
                                    rutas_pdf.append(ruta_pdf)
                        archivos_pdf_str = ";".join(rutas_pdf) if rutas_pdf else ""

                        db.insertar_inspeccion(bloque_id=bm[bl],fecha_visita=fecha_hora_str,
                            inspector=inspector,condiciones_climaticas=clima,avance_fisico=avance,
                            observaciones=obs,desviaciones=desv,registro_fotografico="",
                            codigo_verificacion=ver,microcuenca=mc,archivos_pdf=archivos_pdf_str)
                        _invalidar_cache()
                        msg = "Inspeccion registrada."
                        if rutas_pdf:
                            msg += f" {len(rutas_pdf)} PDF(s) adjuntado(s)."
                        st.success(msg); st.rerun()
            except Exception as e: st.error(f"Error: {e}")
    st.markdown("---")
    st.markdown("**Historial de Inspecciones**")
    st.caption("Haga clic en **Editar** para modificar una inspeccion existente o en **Eliminar** para descartar una version.")
    insp = _cached_obtener_todas_inspecciones(_cache_version())
    if insp:
        # Paginacion
        insp_pag, total_pags_i, pag_actual_i = _paginar(insp, "pag_insp")
        _controles_paginacion(total_pags_i, pag_actual_i, "pag_insp")
        # Tabla con botones de edicion / eliminacion
        col_widths = [0.4, 0.9, 0.9, 0.9, 0.6, 0.85, 0.55, 0.9, 0.45, 0.6, 0.7]
        header_cols = st.columns(col_widths)
        for col, h in zip(header_cols, ["ID", "Bloque", "Microcuenca", "Fecha", "Hora", "Inspector", "Avance%", "Verificacion", "PDFs", "", ""]):
            col.markdown(f"**{h}**")
        st.markdown("---")
        confirm_del_id = st.session_state.get("insp_confirm_del_id")
        for i in insp_pag:
            row = st.columns(col_widths)
            row[0].write(i["id"])
            row[1].write(i["bloque_codigo"])
            row[2].write(i.get("microcuenca", "") or "")
            fv = (i.get("fecha_visita") or "").strip()
            fecha_part = fv[:10] if len(fv) >= 10 else fv
            hora_part = fv[11:16] if len(fv) >= 16 else "—"
            row[3].write(fecha_part)
            row[4].write(hora_part)
            row[5].write(i["inspector"])
            row[6].write(f"{i['avance_fisico']:.1f}")
            row[7].write(i["codigo_verificacion"])
            row[8].write(len([p for p in (i.get("archivos_pdf", "") or "").split(";") if p.strip()]))
            if row[9].button("Editar", key=f"edit_insp_{i['id']}", type="primary"):
                st.session_state["insp_edit_id"] = i["id"]
                st.session_state["insp_e_bloque"] = i["bloque_codigo"]
                st.session_state["insp_e_mc"] = i.get("microcuenca", "") or ""
                st.session_state["insp_e_fecha"] = i["fecha_visita"]
                st.session_state["insp_e_inspector"] = i["inspector"]
                st.session_state["insp_e_clima"] = i["condiciones_climaticas"]
                st.session_state["insp_e_avance"] = i["avance_fisico"]
                st.session_state["insp_e_obs"] = i.get("observaciones", "") or ""
                st.session_state["insp_e_desv"] = i.get("desviaciones", "") or ""
                st.session_state["insp_e_ver"] = i["codigo_verificacion"]
                st.session_state.pop("insp_confirm_del_id", None)
                st.rerun()
            if confirm_del_id == i["id"]:
                if row[10].button("Confirmar", key=f"del_confirm_insp_{i['id']}", type="primary"):
                    db.eliminar_inspeccion(i["id"])
                    _invalidar_cache()
                    st.session_state.pop("insp_confirm_del_id", None)
                    st.success(f"Inspeccion ID {i['id']} eliminada.")
                    st.rerun()
            else:
                if row[10].button("Eliminar", key=f"del_insp_{i['id']}", type="secondary"):
                    st.session_state["insp_confirm_del_id"] = i["id"]
                    st.rerun()
        if confirm_del_id is not None:
            st.warning(f"Confirme la eliminacion de la inspeccion ID {confirm_del_id} pulsando 'Confirmar' en su fila. "
                       "Esta accion no puede deshacerse.")
            if st.button("Cancelar eliminacion", key="insp_cancel_del"):
                st.session_state.pop("insp_confirm_del_id", None)
                st.rerun()
        st.markdown("---")

        # Eliminar inspeccion
        insp_del_map = {f"ID {i['id']} - {i['fecha_visita']} - {i['inspector']}": i["id"] for i in insp}
        sel_del = st.selectbox("Seleccionar inspeccion a eliminar", [""] + list(insp_del_map.keys()), key="del_insp")
        if sel_del and sel_del in insp_del_map and st.button("Eliminar inspeccion", key="btn_del_insp"):
            db.eliminar_inspeccion(insp_del_map[sel_del]); _invalidar_cache(); st.success("Inspeccion eliminada."); st.rerun()

        # Seccion para descargar PDFs adjuntos de una inspeccion
        st.markdown("**Descargar PDFs adjuntos**")
        insp_map = {f"ID {i['id']} - {i['fecha_visita']} - {i['inspector']}": i for i in insp}
        sel_insp = st.selectbox("Seleccionar inspeccion", list(insp_map.keys()), key="pdf_download_sel")
        if sel_insp:
            insp_sel = insp_map[sel_insp]
            pdfs_str = insp_sel.get("archivos_pdf", "") or ""
            pdfs = [p.strip() for p in pdfs_str.split(";") if p.strip()]
            if pdfs:
                for ruta in pdfs:
                    nombre = os.path.basename(ruta)
                    if os.path.exists(ruta):
                        with open(ruta, "rb") as fp:
                            st.download_button(
                                label=f"Descargar: {nombre}",
                                data=fp.read(),
                                file_name=nombre,
                                mime="application/pdf",
                                key=f"dl_{nombre}")
                    else:
                        st.caption(f"Archivo no disponible: {nombre}")
            else:
                st.caption("Esta inspeccion no tiene archivos PDF adjuntos.")

        # Adjuntar PDFs a inspeccion existente
        st.markdown("**Adjuntar PDF a inspeccion existente**")
        pdf_adicional = st.file_uploader(
            "Seleccionar PDF (max. 25 MB)",
            type=["pdf"], accept_multiple_files=True, key="pdf_hist_upload")
        if pdf_adicional and st.button("Adjuntar a inspeccion seleccionada", key="btn_adjuntar_pdf"):
            insp_sel = insp_map[sel_insp]
            pdf_dir = os.path.join(os.path.dirname(__file__), "adjuntos_pdf")
            os.makedirs(pdf_dir, exist_ok=True)
            nuevas_rutas = []
            for f in pdf_adicional:
                if f.size <= 25 * 1024 * 1024:
                    nombre_pdf = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{f.name}"
                    ruta_pdf = os.path.join(pdf_dir, nombre_pdf)
                    with open(ruta_pdf, "wb") as fp:
                        fp.write(f.getbuffer())
                    nuevas_rutas.append(ruta_pdf)
                else:
                    st.warning(f"'{f.name}' excede 25 MB.")
            if nuevas_rutas:
                existentes = insp_sel.get("archivos_pdf", "") or ""
                todas = [p.strip() for p in existentes.split(";") if p.strip()] + nuevas_rutas
                db.actualizar_archivos_pdf_inspeccion(insp_sel["id"], ";".join(todas))
                _invalidar_cache()
                st.success(f"{len(nuevas_rutas)} PDF(s) adjuntado(s)."); st.rerun()

# ══════════════════════════════════════════════════════════════════════════
# INDICADORES DE CALIDAD
# ══════════════════════════════════════════════════════════════════════════
def pagina_indicadores():
    st.subheader("Indicadores de Calidad")
    bm = _bloques_map()
    if not bm: st.warning("Registre un bloque primero."); return

    # Inicializar estado de edicion
    if "ind_edit_id" not in st.session_state:
        st.session_state["ind_edit_id"] = None

    edit_id = st.session_state.get("ind_edit_id")

    if edit_id:
        st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                    f'Modo Edicion - Indicador ID {edit_id}</div>', unsafe_allow_html=True)
        if st.button("Cancelar edicion", key="ind_cancel_edit"):
            st.session_state["ind_edit_id"] = None
            for k in list(st.session_state.keys()):
                if k.startswith("ind_e_"):
                    del st.session_state[k]
            st.rerun()

    bl = st.selectbox("Bloque", list(bm.keys()), key="ind_bl")
    bid = bm[bl]

    # Auto-resolver microcuenca del bloque seleccionado
    mc_auto = _resolver_microcuenca(bl)
    if mc_auto:
        mc_idx = MICROCUENCAS.index(mc_auto) + 1
        st.info(f"Microcuenca vinculada automaticamente: **{mc_auto}**")
    else:
        mc_idx = 0
    if edit_id:
        mc_val = st.session_state.get("ind_e_mc", "")
        if mc_val and mc_val in MICROCUENCAS:
            mc_idx = MICROCUENCAS.index(mc_val) + 1

    ins = db.obtener_inspecciones_por_bloque(bid)
    if not ins: st.warning("Sin inspecciones para este bloque."); return
    im = {f"{i['fecha_visita']} - {i['inspector']}":i["id"] for i in ins}
    isel = st.selectbox("Inspeccion", list(im.keys()))

    def_pc = float(st.session_state.get("ind_e_pc", 0)) if edit_id else 0.0
    def_tc = st.session_state.get("ind_e_tc", "") if edit_id else ""
    def_vi = st.session_state.get("ind_e_vi", "") if edit_id else ""
    tc_idx = ([""]+TIPOS_COBERTURA).index(def_tc) if def_tc in ([""]+TIPOS_COBERTURA) else 0
    vi_idx = ([""]+VIGOR_COBERTURA).index(def_vi) if def_vi in ([""]+VIGOR_COBERTURA) else 0

    with st.form("form_ind", clear_on_submit=not edit_id):
        mc = st.selectbox("Microcuenca", [""] + MICROCUENCAS, index=mc_idx, key="ind_mc")
        pc = st.number_input("Cobertura vegetal (%)", 0.0, 100.0, def_pc)
        tc = st.selectbox("Tipo cobertura", [""]+TIPOS_COBERTURA, index=tc_idx)
        vi = st.selectbox("Vigor cobertura", [""]+VIGOR_COBERTURA, index=vi_idx)
        btn_label = "Actualizar Indicadores" if edit_id else "Guardar Indicadores"
        guardar = st.form_submit_button(btn_label, type="primary")
    if guardar:
        try:
            if edit_id:
                db.actualizar_indicadores(indicador_id=edit_id,
                    porcentaje_cobertura_vegetal=pc,
                    tipo_cobertura_vegetal=tc, vigor_cobertura_vegetal=vi,
                    microcuenca=mc)
                _invalidar_cache()
                st.session_state["ind_edit_id"] = None
                for k in list(st.session_state.keys()):
                    if k.startswith("ind_e_"):
                        del st.session_state[k]
                st.success("Indicadores actualizados."); st.rerun()
            else:
                # Verificar duplicado: un indicador por inspeccion
                existente = db.obtener_indicadores_por_inspeccion(im[isel])
                if existente:
                    st.warning("Ya existen indicadores para esta inspeccion. Use 'Editar' en la tabla para modificarlos.")
                else:
                    db.insertar_indicadores(bloque_id=bid,inspeccion_id=im[isel],
                        cobertura_vegetal_planificada=0,cobertura_vegetal_lograda=0,
                        sobrevivencia_especies=0,longitud_zanjas_ejecutada=0,
                        volumen_retencion_sedimentos=0,porcentaje_cobertura_vegetal=pc,
                        tipo_cobertura_vegetal=tc,vigor_cobertura_vegetal=vi,microcuenca=mc)
                    _invalidar_cache()
                    st.success("Indicadores guardados."); st.rerun()
        except Exception as e: st.error(f"Error: {e}")
    st.markdown("---")
    st.markdown("**Indicadores Registrados**")
    st.caption("Haga clic en **Editar** para modificar indicadores existentes.")
    ind = db.obtener_indicadores_por_bloque(bid)
    if ind:
        header_cols = st.columns([1, 1, 1, 1, 1, 0.6])
        for col, h in zip(header_cols, ["Fecha", "Microcuenca", "Cobert.%", "Tipo", "Vigor", ""]):
            col.markdown(f"**{h}**")
        st.markdown("---")
        for x in ind:
            row = st.columns([1, 1, 1, 1, 1, 0.6])
            row[0].write(x.get("fecha_visita", ""))
            row[1].write(x.get("microcuenca", "") or "")
            row[2].write(f"{x.get('porcentaje_cobertura_vegetal', 0):.1f}")
            row[3].write(x.get("tipo_cobertura_vegetal", "") or "")
            row[4].write(x.get("vigor_cobertura_vegetal", "") or "")
            if row[5].button("Editar", key=f"edit_ind_{x['id']}", type="primary"):
                st.session_state["ind_edit_id"] = x["id"]
                st.session_state["ind_e_mc"] = x.get("microcuenca", "") or ""
                st.session_state["ind_e_pc"] = x.get("porcentaje_cobertura_vegetal", 0)
                st.session_state["ind_e_tc"] = x.get("tipo_cobertura_vegetal", "") or ""
                st.session_state["ind_e_vi"] = x.get("vigor_cobertura_vegetal", "") or ""
                st.rerun()
        st.markdown("---")
        # Eliminar indicador
        ind_del = {f"ID {x['id']} - {x.get('fecha_visita', '')}": x["id"] for x in ind}
        sel_del = st.selectbox("Seleccionar indicador a eliminar", [""] + list(ind_del.keys()), key="del_ind")
        if sel_del and sel_del in ind_del and st.button("Eliminar indicador", key="btn_del_ind"):
            db.eliminar_indicadores(ind_del[sel_del]); _invalidar_cache(); st.success("Indicador eliminado."); st.rerun()

# ══════════════════════════════════════════════════════════════════════════
# DIAGNOSTICO TERRITORIAL V5 (F-DT-01 a F-DT-05)
# ══════════════════════════════════════════════════════════════════════════
def _dt_load_json(raw, default):
    """Decodifica un JSON guardado o devuelve `default` si esta vacio o malformado."""
    import json as _json
    if not raw:
        return default
    try:
        v = _json.loads(raw)
        return v if isinstance(v, list) else default
    except Exception:
        return default


def _dt_dump_json(rows):
    """Serializa una lista de dicts (filas) a JSON, descartando filas totalmente vacias."""
    import json as _json
    limpios = []
    for r in rows:
        if any((str(v).strip() if v is not None else "") for v in r.values()):
            limpios.append({k: ("" if v is None else str(v)) for k, v in r.items()})
    return _json.dumps(limpios, ensure_ascii=False)


# Claves de los widgets escalares de la cabecera del formulario F-DT.
_DT_HEADER_INPUT_KEYS = (
    "dt_fecha", "dt_hora", "dt_corr", "dt_eval", "dt_brigada", "dt_mc",
    "dt_utm_e", "dt_utm_n", "dt_altitud", "dt_cp", "dt_cc", "dt_obs",
)


def _dt_limpiar_widgets_edicion():
    """Elimina del session_state los valores de los widgets del formulario
    F-DT para que, al entrar en modo edicion, los parametros value=/index=
    (que leen de dt_edit_data) vuelvan a tomar efecto.

    Streamlit ignora value=/index= cuando la key del widget ya existe en
    session_state; sin esta limpieza la precarga del registro a editar no se
    refleja en los campos.
    """
    for k in list(st.session_state.keys()):
        if k.startswith(("f01_", "f02_", "f03_", "f04_", "f05_")) or \
           k in _DT_HEADER_INPUT_KEYS:
            del st.session_state[k]


def _dt_dataeditor(label, columns, num_rows, key, options=None, edit_data=None):
    """Renderiza un st.data_editor con `num_rows` filas y columnas dadas."""
    import pandas as _pd
    options = options or {}
    if edit_data:
        df = _pd.DataFrame(edit_data)
        for k, _ in columns:
            if k not in df.columns:
                df[k] = ""
        while len(df) < num_rows:
            df = _pd.concat([df, _pd.DataFrame([{k: "" for k, _ in columns}])],
                            ignore_index=True)
        df = df[[k for k, _ in columns]].head(num_rows).fillna("")
    else:
        df = _pd.DataFrame([{k: "" for k, _ in columns} for _ in range(num_rows)])

    col_config = {}
    for k, lbl in columns:
        if k in options:
            col_config[k] = st.column_config.SelectboxColumn(
                lbl, options=[""] + list(options[k]))
        else:
            col_config[k] = st.column_config.TextColumn(lbl)
    st.markdown(f"**{label}**")
    edited = st.data_editor(
        df, key=key, hide_index=True, num_rows="fixed",
        use_container_width=True, column_config=col_config,
    )
    return edited.to_dict(orient="records")


# ══════════════════════════════════════════════════════════════════════════
# RESUMENES EXCEL POR BLOQUE (117 libros de Diagnostico Territorial)
# ══════════════════════════════════════════════════════════════════════════

def _mime_xlsx():
    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _tabla_resumenes(filas):
    """DataFrame del catalogo de resumenes cargados."""
    return pd.DataFrame([{
        "Bloque": r.get("codigo_bloque", ""),
        "Microcuenca": r.get("microcuenca", ""),
        "Provincia": r.get("provincia", ""),
        "Distrito": r.get("distrito", ""),
        "Area (ha)": r.get("area_ha"),
        "UTM ESTE": r.get("utm_este"),
        "UTM NORTE": r.get("utm_norte"),
        "Pendiente (%)": r.get("pendiente_pct"),
        "MSAVI 2024": r.get("msavi_2024"),
        "Sustantivas": r.get("n_sustantivas"),
        "Verificacion": r.get("estado_verificacion", ""),
        "UTM 17S": r.get("validacion_utm", ""),
        "Archivo": r.get("nombre_archivo", ""),
        "Cargado": r.get("fecha_carga", ""),
    } for r in filas])


def _carga_masiva_resumenes(bm):
    """Carga de los libros de resumen: multiples .xlsx o un .zip de la carpeta."""
    st.markdown("**1. Cargar los libros de resumen por bloque**")
    st.caption(
        "Suba los archivos `Plantilla_Excel_Bloque_<codigo>_IN_Piura.xlsx` "
        "de la carpeta **plantillas_117_msavi_v6** de Google Drive. Puede "
        "seleccionar los 117 a la vez o subir la carpeta comprimida en un "
        "solo .zip. Los libros ya cargados se actualizan; ningun otro "
        "registro del aplicativo se toca. Solo hace falta si va a cargar una "
        "revision posterior a la que el aplicativo ya trae consigo.")

    manifiesto = rbq.cargar_manifiesto()
    if manifiesto.get("carpeta_drive_url"):
        st.caption(f"Carpeta de origen: {manifiesto['carpeta_drive_url']}")

    _actualizar_desde_repositorio(bm)

    subidos = st.file_uploader(
        "Archivos .xlsx de resumen o .zip con la carpeta",
        type=["xlsx", "zip"], accept_multiple_files=True,
        key="rbq_uploader")

    if not subidos:
        return

    # Expandir los .zip antes de contar, para que el usuario vea cuantos
    # libros se van a procesar realmente.
    archivos, errores_zip = [], []
    for f in subidos:
        contenido = f.getvalue()
        if f.name.lower().endswith(".zip"):
            try:
                archivos.extend(rbq.expandir_zip(contenido))
            except Exception as exc:
                errores_zip.append((f.name, f"ZIP ilegible: {exc}"))
        else:
            archivos.append((f.name, contenido))

    for nombre, motivo in errores_zip:
        st.error(f"{nombre}: {motivo}")
    if not archivos:
        st.warning("No se encontraron libros .xlsx en lo subido.")
        return

    st.info(f"Se procesaran **{len(archivos)}** libro(s) "
            f"({sum(len(c) for _, c in archivos) / 1024 / 1024:.1f} MB).")

    if not st.button(f"Cargar {len(archivos)} resumen(es) al aplicativo",
                     type="primary", key="rbq_cargar"):
        return

    _procesar_libros(bm, archivos, errores_zip)


def _procesar_libros(bm, archivos, errores_previos=()):
    """Parsea y guarda cada libro (upsert por codigo de bloque).

    Un bloque tiene un solo resumen vigente: volver a cargar su libro
    reemplaza el anterior y no toca ningun otro registro del aplicativo.
    """
    barra = st.progress(0.0, text="Leyendo libros...")
    insertados = actualizados = 0
    fallidos = list(errores_previos)
    for i, (nombre, contenido) in enumerate(archivos, start=1):
        try:
            datos = rbq.parsear_resumen_bloque(contenido, nombre)
            codigo = datos.get("codigo_bloque", "")
            if not codigo:
                raise ValueError("El libro no declara codigo de bloque.")
            bloque_id = _id_bloque_por_codigo(bm, codigo)
            if db.guardar_resumen_bloque(datos, contenido, bloque_id) == "insertado":
                insertados += 1
            else:
                actualizados += 1
        except Exception as exc:
            fallidos.append((nombre, f"{type(exc).__name__}: {exc}"))
        barra.progress(i / len(archivos), text=f"{i}/{len(archivos)} - {nombre}")
    barra.empty()

    try:
        db.vincular_resumenes_a_bloques()
    except Exception:
        # La vinculacion es una comodidad; su fallo no invalida la carga.
        pass
    _invalidar_cache()

    if insertados or actualizados:
        _flash(f"Carga completada: {insertados} nuevo(s), "
               f"{actualizados} actualizado(s).")
    if fallidos:
        st.error(f"{len(fallidos)} archivo(s) no pudieron cargarse:")
        st.dataframe(pd.DataFrame(fallidos, columns=["Archivo", "Motivo"]),
                     use_container_width=True, hide_index=True)
    if insertados or actualizados:
        st.rerun()


def _actualizar_desde_repositorio(bm):
    """Reemplaza los resumenes cargados por los libros vigentes del repo.

    Evita tener que volver a subir los 117 archivos a mano: el aplicativo
    los trae consigo en `plantillas_117_msavi_v6.zip` (o en la carpeta
    `plantillas_117_msavi_v6`, si viaja extraida).
    """
    libros = rbq.libros_del_repositorio()
    if not libros:
        return
    st.info(
        f"El aplicativo incluye **{len(libros)} libros vigentes (V6 - revision "
        f"1, 19-09-2026)** con la distribucion areal del MSAVI 2024 por clase "
        f"DN (superficie y porcentaje por clase, totales y superficie bajo el "
        f"umbral {rbq.UMBRAL_MSAVI}) y, en los bloques con vuelo, la "
        f"verificacion aerea con dron. Reemplazan a los ya cargados por "
        f"codigo de bloque; ningun otro registro del aplicativo se toca.")
    if st.button(f"Reemplazar los {len(libros)} resumenes por la version vigente "
                 f"(V6 - revision 1)", key="rbq_repo"):
        _procesar_libros(bm, libros)


def _id_bloque_por_codigo(bm, codigo):
    """Id del bloque del catalogo cuyo codigo coincide, ignorando mayusculas.

    Devuelve None si el bloque del resumen no esta dado de alta: el resumen
    se guarda igual y queda sin vincular.
    """
    objetivo = (codigo or "").strip().upper()
    for actual, bloque_id in bm.items():
        if str(actual).strip().upper() == objetivo:
            return bloque_id
    return None


def _detalle_resumen_bloque(codigo):
    """Vista de un bloque: sintesis, tablas de las 5 hojas y descargas."""
    registro = db.obtener_resumen_bloque(codigo)
    if not registro:
        st.warning(f"El bloque {codigo} no tiene resumen cargado.")
        return
    # Los resumenes guardados antes de que los libros trajeran el resultado
    # de sus formulas no incluyen el reparto porcentual: se deriva aqui, sin
    # necesidad de volver a cargarlos.
    datos = rbq.completar_sintesis_msavi(registro.get("datos") or {})

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Area de catalogo (ha)",
              f"{datos.get('area_ha_num'):,.2f}" if datos.get("area_ha_num")
              is not None else "s/d")
    c2.metric("Pendiente promedio (%)",
              f"{datos.get('pendiente_pct_num'):,.2f}"
              if datos.get("pendiente_pct_num") is not None else "s/d")
    msavi = datos.get("msavi_2024_num")
    c3.metric("MSAVI 2024", f"{msavi:.4f}" if msavi is not None else "s/d",
              delta=("BAJO umbral" if msavi is not None and msavi < rbq.UMBRAL_MSAVI
                     else "Sobre umbral" if msavi is not None else None),
              delta_color="inverse")
    c4.metric("Discrepancias sustantivas",
              (datos.get("consistencia_resumen") or {}).get("SUSTANTIVA", 0))

    validacion = datos.get("validacion_utm", "")
    if validacion and validacion != "Conforme":
        st.warning(f"Validacion UTM 17S: {validacion}")
    if datos.get("advertencias"):
        st.warning("Hojas no leidas: " + " | ".join(datos["advertencias"]))

    st.markdown("**Hoja 1 - Resumen**")
    generales = [
        ("Codigo del bloque", "codigo_bloque"),
        ("Microcuenca (catalogo)", "microcuenca"),
        ("Microcuenca declarada en ficha", "microcuenca_ficha"),
        ("Departamento", "departamento"), ("Provincia", "provincia"),
        ("Distrito", "distrito"), ("Centro poblado asociado", "centro_poblado"),
        ("Comunidad campesina", "comunidad_campesina"),
        ("Tipo de intervencion", "tipo_intervencion"),
        ("Centroide UTM ESTE (m)", "utm_este"),
        ("Centroide UTM NORTE (m)", "utm_norte"),
        ("Altitud minima (msnm)", "altitud_min"),
        ("Altitud maxima (msnm)", "altitud_max"),
        ("Piso altitudinal dominante", "piso_altitudinal"),
        ("Clase de pendiente", "clase_pendiente"),
        ("Forma del terreno", "forma_terreno"),
        ("Tipo de ecosistema (UP)", "tipo_ecosistema"),
        ("Estado de conservacion", "estado_conservacion"),
        ("Uso actual dominante", "uso_dominante"),
        ("Nivel general de erosion", "nivel_erosion"),
        ("Velocidad de degradacion", "velocidad_degradacion"),
        ("Urgencia de intervencion", "urgencia_intervencion"),
        ("Peligro integrado (MCA-AHP)", "peligro_integrado"),
        ("Estado de verificacion de campo", "estado_verificacion"),
        ("Responsable de la evaluacion", "evaluador"),
        ("Fecha de evaluacion", "fecha_evaluacion"),
    ]
    st.dataframe(pd.DataFrame(
        [{"Campo": etiqueta, "Valor": datos.get(clave, "")}
         for etiqueta, clave in generales if datos.get(clave, "")]),
        use_container_width=True, hide_index=True)

    ndvi = datos.get("ndvi_tabla") or []
    if ndvi:
        st.markdown("**Hoja 2 - NDVI mediana 2025 (distribucion areal)**")
        df_ndvi = pd.DataFrame([{
            "Clase NDVI": r.get("clase", ""),
            "Superficie (ha)": r.get("superficie_ha"),
            "% del area": r.get("pct"),
            "Interpretacion": r.get("interpretacion", ""),
        } for r in ndvi])
        col_t, col_g = st.columns([1.3, 1])
        col_t.dataframe(df_ndvi, use_container_width=True, hide_index=True)
        graficables = df_ndvi.dropna(subset=["Superficie (ha)"])
        if not graficables.empty:
            col_g.bar_chart(graficables.set_index("Clase NDVI")["Superficie (ha)"],
                            color="#1B4D2E")

    msavi_tabla = datos.get("msavi_tabla") or []
    if msavi_tabla:
        st.markdown(f"**Hoja 2 - MSAVI 2024 (umbral {rbq.UMBRAL_MSAVI})**")
        df_msavi = pd.DataFrame([{
            "Clase MSAVI": r.get("clase", ""),
            "Superficie (ha)": r.get("superficie_ha_txt", ""),
            "Superficie (m2)": (f"{r['superficie_ha'] * 10000:,.0f}".replace(",", " ")
                                if r.get("superficie_ha") is not None else ""),
            "% del area": r.get("pct_txt", ""),
            "Interpretacion": r.get("interpretacion", ""),
            "Condicion": r.get("condicion", ""),
        } for r in msavi_tabla])
        col_t, col_g = st.columns([1.3, 1])
        col_t.dataframe(df_msavi, use_container_width=True, hide_index=True)
        graficables = pd.DataFrame([{
            "Clase MSAVI": r.get("clase", ""),
            "Superficie (ha)": r.get("superficie_ha"),
        } for r in msavi_tabla if r.get("superficie_ha") is not None])
        if not graficables.empty:
            col_g.bar_chart(graficables.set_index("Clase MSAVI")["Superficie (ha)"],
                            color="#1B4D2E")
        if all(r.get("superficie_ha") is None for r in msavi_tabla):
            st.caption("La distribucion areal por clase de MSAVI no figura en "
                       "los insumos de este entregable. Se consigna «Por "
                       "determinar» y no se estima, conforme a la declaracion "
                       "de integridad de datos del proyecto.")
        elif datos.get("msavi_total_ha") is not None:
            m1, m2, m3 = st.columns(3)
            m1.metric("Total clasificado MSAVI (ha)",
                      f"{datos['msavi_total_ha']:,.2f}")
            if datos.get("msavi_sobre_umbral_ha") is not None:
                m2.metric(f"Sobre umbral {rbq.UMBRAL_MSAVI} (ha)",
                          f"{datos['msavi_sobre_umbral_ha']:,.2f}",
                          f"{datos.get('msavi_sobre_umbral_pct') or 0:.2f} %")
            if datos.get("msavi_bajo_umbral_ha") is not None:
                m3.metric(f"Bajo umbral {rbq.UMBRAL_MSAVI} (ha) - brecha",
                          f"{datos['msavi_bajo_umbral_ha']:,.2f}",
                          f"{datos.get('msavi_bajo_umbral_pct') or 0:.2f} %")
            detalle = []
            if datos.get("msavi_clase_dominante"):
                detalle.append(f"clase DN dominante: {datos['msavi_clase_dominante']}")
            if datos.get("msavi_poligonos_num"):
                detalle.append(f"{int(datos['msavi_poligonos_num']):,} poligonos"
                               .replace(",", " "))
            if datos.get("msavi_sintesis_calculada"):
                detalle.append("porcentajes y totales calculados por el "
                               "aplicativo sobre las superficies del libro")
            st.caption(
                "Distribucion areal obtenida de la estadistica zonal del raster "
                "MSAVI 2024 clasificado (AREAS_MSAVI_BLOQUES_V6_REV_HSCM)"
                + (" - " + " - ".join(detalle) if detalle else "")
                + ". La superficie bajo el umbral es la base del indicador de "
                  "brecha (R.M. N.° 00213-2024-MINAM).")

    estaciones = datos.get("estaciones") or []
    if estaciones:
        st.markdown("**Hoja 3 - Puntos georreferenciados de la ficha DT**")
        st.dataframe(pd.DataFrame([{
            "Codigo": r.get("codigo", ""),
            "Naturaleza del punto": r.get("naturaleza", ""),
            "UTM ESTE (m)": r.get("utm_este"),
            "UTM NORTE (m)": r.get("utm_norte"),
            "Dist. al centroide (m)": r.get("dist_centroide"),
            "Contenido registrado": r.get("contenido", ""),
        } for r in estaciones]), use_container_width=True, hide_index=True)

    micro = datos.get("microcuenca_tabla") or []
    if micro:
        st.markdown(f"**Hoja 4 - Contexto intramicrocuenca "
                    f"{datos.get('microcuenca', '')}**")
        df_micro = pd.DataFrame([{
            "Bloque": ("> " + r.get("bloque", "")) if r.get("es_actual")
                      else r.get("bloque", ""),
            "Area (ha)": r.get("area_ha"),
            "% microcuenca": r.get("pct_microcuenca"),
            "Rango altitudinal": r.get("rango_altitudinal", ""),
            "Pendiente (%)": r.get("pendiente_pct"),
            "MSAVI 2024": r.get("msavi"),
        } for r in micro])
        col_t, col_g = st.columns([1.4, 1])
        col_t.dataframe(df_micro, use_container_width=True, hide_index=True)
        graficables = df_micro.dropna(subset=["Area (ha)"])
        if len(graficables) > 1:
            col_g.bar_chart(graficables.set_index("Bloque")["Area (ha)"],
                            color="#1B4D2E")

    consistencia = datos.get("consistencia") or []
    if consistencia:
        resumen_cons = datos.get("consistencia_resumen") or {}
        st.markdown(f"**Hoja 5 - Control de consistencia "
                    f"({resumen_cons.get('total', 0)} verificaciones)**")
        cols = st.columns(len(rbq.CALIFICACIONES))
        for col, calificacion in zip(cols, rbq.CALIFICACIONES):
            col.metric(calificacion.capitalize(), resumen_cons.get(calificacion, 0))
        st.dataframe(pd.DataFrame([{
            "Cod.": r.get("codigo", ""),
            "Campo afectado": r.get("campo", ""),
            "Discrepancia observada": r.get("discrepancia", ""),
            "Calificacion": r.get("calificacion", ""),
            "Tratamiento adoptado": r.get("tratamiento", ""),
        } for r in consistencia]), use_container_width=True, hide_index=True)

    # ── Descargas del bloque ──
    st.markdown("**Descargas del bloque**")
    original = db.obtener_archivo_resumen_bloque(codigo)
    d1, d2, d3 = st.columns(3)
    if original:
        d1.download_button(
            "Excel original (.xlsx)", original,
            file_name=registro.get("nombre_archivo") or f"Bloque_{codigo}.xlsx",
            mime=_mime_xlsx(), use_container_width=True,
            key=f"rbq_dl_orig_{codigo}")
        try:
            d2.download_button(
                "Excel con graficos (.xlsx)",
                rbq.generar_excel_con_graficos(original, datos),
                file_name=f"Resumen_Graficos_Bloque_{codigo}_IN_Piura.xlsx",
                mime=_mime_xlsx(), use_container_width=True,
                key=f"rbq_dl_graf_{codigo}")
        except Exception as exc:
            d2.error(f"No se pudieron generar los graficos: {exc}")
    try:
        d3.download_button(
            "Ficha PDF con graficos", rbq.generar_pdf_bloque(datos),
            file_name=f"Ficha_Resumen_DT_Bloque_{codigo}_IN_Piura.pdf",
            mime="application/pdf", use_container_width=True,
            key=f"rbq_dl_pdf_{codigo}")
    except Exception as exc:
        d3.error(f"No se pudo generar el PDF: {exc}")


# ══════════════════════════════════════════════════════════════════════════
# FICHAS F-DT ACTUALIZADAS (117 libros de campo)
# ══════════════════════════════════════════════════════════════════════════

@st.cache_data(ttl=3600, show_spinner=False, max_entries=2)
def _cached_fichas_dt(catalogo_items):
    """Lee los 117 libros F-DT del repositorio y los deja en cache.

    La lectura completa toma del orden de diez segundos: se memoriza por el
    catalogo de bloques con el que se resuelve la localizacion, de modo que
    solo se repite si el catalogo cambia.
    """
    catalogo = {codigo: dict(campos) for codigo, campos in catalogo_items}
    return fdt.cargar_fichas(catalogo=catalogo)


def _catalogo_para_fichas(cargados):
    """{codigo: {provincia, distrito, microcuenca, area_ha}} del aplicativo.

    Manda el catalogo de bloques; lo que falte se completa con el resumen
    cargado del mismo bloque. Once libros F-DT dejaron la localizacion en
    blanco y uno trae un valor que no es una provincia: el aplicativo si
    sabe donde esta cada bloque y esa es la fuente que gobierna.
    """
    catalogo = {}
    for bloque in _cached_obtener_bloques(_cache_version()):
        codigo = str(bloque.get("codigo") or "").strip().upper()
        if not codigo:
            continue
        catalogo[codigo] = {
            "provincia": bloque.get("provincia") or "",
            "distrito": bloque.get("distrito") or "",
            "microcuenca": bloque.get("microcuenca") or "",
            "area_ha": bloque.get("area_hectareas") or "",
        }
    for resumen in cargados:
        codigo = str(resumen.get("codigo_bloque") or "").strip().upper()
        if not codigo:
            continue
        registro = catalogo.setdefault(
            codigo, {"provincia": "", "distrito": "", "microcuenca": "",
                     "area_ha": ""})
        for campo, origen in (("provincia", "provincia"),
                              ("distrito", "distrito"),
                              ("microcuenca", "microcuenca"),
                              ("area_ha", "area_ha")):
            if not registro.get(campo):
                registro[campo] = resumen.get(origen) or ""
    return catalogo


def _items_catalogo(catalogo):
    """Catalogo en forma inmutable, para poder usarlo como clave de cache."""
    return tuple(sorted(
        (codigo, tuple(sorted((k, str(v)) for k, v in campos.items())))
        for codigo, campos in catalogo.items()))


def _df_tabla_compacta(fichas, nivel):
    cabeceras, filas = fdt.tabla_compacta(fichas, nivel, breve=True)
    return pd.DataFrame(filas, columns=cabeceras)


def _grafico_fdt(df, columna, titulo, nivel):
    """Barras de una columna de la tabla compacta, por grupo."""
    if columna not in df.columns:
        return
    datos = df[[df.columns[0], columna]].dropna()
    datos = datos[datos[columna] != 0] if columna.startswith("Carcavas") else datos
    if datos.empty:
        st.caption(f"{titulo}: ningun grupo declara el dato.")
        return
    if nivel == "bloque" and len(datos) > 30:
        datos = datos.sort_values(columna, ascending=False).head(30)
        titulo += " - 30 primeros"
    st.caption(titulo)
    st.bar_chart(datos.set_index(df.columns[0])[columna], color="#1B4D2E",
                 use_container_width=True)


def _detalle_ficha_dt(ficha):
    """Reporte de un bloque: campos declarados de las cinco fichas."""
    etiquetas = fdt.etiquetas_indicador()
    generales = [
        ("Codigo de bloque", ficha.get("codigo_bloque")),
        ("Microcuenca", ficha.get("microcuenca")),
        ("Provincia", ficha.get("provincia")),
        ("Distrito", ficha.get("distrito")),
        ("Centro poblado mas cercano", ficha.get("centro_poblado_cercano")),
        ("Comunidad campesina", ficha.get("comunidad_campesina_dt")),
        ("UTM ESTE / NORTE del punto de muestreo",
         f"{ficha.get('utm_este_dt', '')} / {ficha.get('utm_norte_dt', '')}"),
        ("Altitud del punto (msnm)", ficha.get("altitud_gps")),
        ("Brigada / responsable", ficha.get("evaluador")),
        ("Fecha de evaluacion", ficha.get("fecha_evaluacion")),
        ("Ficha (correlativo)", ficha.get("ficha_correlativo")),
        ("Archivo de origen", ficha.get("nombre_archivo")),
    ]
    st.dataframe(pd.DataFrame(
        [{"Campo": e, "Valor": v} for e, v in generales if fdt.declarado(v)]),
        use_container_width=True, hide_index=True)

    c1, c2 = st.columns(2)
    numericos = [{"Indicador": etiquetas[c][0], "Unidad": etiquetas[c][1],
                  "Valor": ficha.get(c + "_num")}
                 for c, _e, _u, _a in fdt.INDICADORES_NUM
                 if ficha.get(c + "_num") is not None]
    c1.markdown("**Indicadores declarados**")
    c1.dataframe(pd.DataFrame(numericos), use_container_width=True,
                 hide_index=True)

    sino = [{"Observacion": etq,
             "Respuesta": "Si" if ficha.get(c + "_si") else "No"}
            for c, etq in fdt.INDICADORES_SINO
            if ficha.get(c + "_si") is not None]
    c2.markdown("**Observaciones de campo**")
    c2.dataframe(pd.DataFrame(sino), use_container_width=True, hide_index=True)

    categoricas = [{"Variable": etq, "Valor": fdt.categoria(ficha, campo)}
                   for campo, etq in fdt.CATEGORICOS]
    st.markdown("**Caracterizacion**")
    st.dataframe(pd.DataFrame(categoricas), use_container_width=True,
                 hide_index=True)

    for tipo, etiqueta, _clave, _acr, _cols in fdt.INVENTARIOS:
        filas = fdt.inventario([ficha], tipo)
        with st.expander(f"{etiqueta} - {len(filas)} registro(s)",
                         expanded=False):
            if filas:
                st.dataframe(pd.DataFrame(filas).drop(
                    columns=["Bloque", "Distrito", "Provincia"]),
                    use_container_width=True, hide_index=True)
            else:
                st.caption("La ficha no registra filas en este inventario.")

    observaciones = [
        ("F-DT-01 - Datos generales y fisiografia", ficha.get("dt01_observaciones")),
        ("F-DT-02 - Suelo y procesos erosivos", ficha.get("dt02_observaciones")),
        ("F-DT-03 - Vegetacion y ecosistema", ficha.get("dt03_observaciones")),
        ("F-DT-04 - Causas de degradacion", ficha.get("dt04_observaciones")),
        ("F-DT-05 - Hidrologia y accesibilidad", ficha.get("dt05_observaciones")),
    ]
    with st.expander("Observaciones de las cinco fichas", expanded=False):
        for titulo, texto in observaciones:
            if fdt.declarado(texto):
                st.markdown(f"**{titulo}**")
                st.write(texto)


def _seccion_carcavas(seleccion, nivel):
    """Cruce del inventario de campo (F-DT-02) con la caracterizacion SIG."""
    st.markdown("**Carcavas: campo (F-DT-02) y caracterizacion geoespacial**")
    st.caption(
        "El inventario de la F-DT-02 registra lo que la brigada recorrio; la "
        "caracterizacion geoespacial mide sobre el MDE y los compuestos "
        "Sentinel-2 la longitud, el rango altitudinal, la pendiente media, el "
        "indice de irregularidad y el NDVI de cada carcava digitalizada. Las "
        "dos fuentes se integran por bloque y no se fusionan: de cada carcava "
        "caracterizada se declara la distancia al registro de campo mas "
        "cercano de su bloque.")

    if not fdt.carcavas_caracterizadas():
        st.info("El archivo `Caracterización de cárcavas.xlsx` no viaja en "
                "este despliegue. Subalo al repositorio para integrarlo al "
                "inventario de la F-DT-02.")
        return

    radio = st.slider(
        "Radio para declarar correspondencia con un registro de campo (m)",
        min_value=50, max_value=1000,
        value=int(fdt.RADIO_CORRESPONDENCIA_M), step=50, key="fdt_radio")
    fdt.integrar_carcavas(seleccion, radio_m=float(radio))

    cruce = fdt.resumen_carcavas(seleccion)
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Carcavas en campo", cruce["carcavas_campo"],
              f"{cruce['bloques_campo']} bloques")
    c2.metric("Carcavas caracterizadas", cruce["carcavas_gabinete"],
              f"{cruce['bloques_gabinete']} bloques")
    c3.metric("Bloques con ambas fuentes", cruce["bloques_ambas"])
    c4.metric("Longitud caracterizada (m)",
              f"{cruce['longitud_total_m']:,.0f}".replace(",", " ")
              if cruce["longitud_total_m"] is not None else "s/d")
    c5.metric("Pendiente media de carcava (%)",
              f"{cruce['pendiente_media_pct']:.2f}"
              if cruce["pendiente_media_pct"] is not None else "s/d",
              f"{cruce['con_correspondencia']} con par a <= {radio} m")

    resumen = fdt.tabla_resumen(seleccion, nivel)
    comparacion = pd.DataFrame([{
        fdt.ETIQUETA_NIVEL[nivel]: fila["grupo"],
        "Campo (F-DT-02)": fila.get("n_carcavas_inventario", 0),
        "Caracterizadas": fila.get("n_carcavas_gabinete", 0),
    } for fila in resumen])
    con_datos = comparacion[(comparacion["Campo (F-DT-02)"] > 0) |
                            (comparacion["Caracterizadas"] > 0)]
    if not con_datos.empty:
        if nivel == "bloque" and len(con_datos) > 30:
            con_datos = con_datos.assign(
                _t=con_datos["Campo (F-DT-02)"] + con_datos["Caracterizadas"]
            ).sort_values("_t", ascending=False).head(30).drop(columns="_t")
            st.caption("Carcavas por fuente - 30 bloques con mas registros")
        else:
            st.caption("Carcavas por fuente")
        st.bar_chart(con_datos.set_index(fdt.ETIQUETA_NIVEL[nivel]),
                     color=["#1B4D2E", "#B8860B"], use_container_width=True)

    st.caption("Contraste por bloque: lo declarado en la sintesis de la "
               "F-DT-02, lo inventariado en campo y lo caracterizado.")
    st.dataframe(pd.DataFrame(fdt.contraste_carcavas(seleccion)),
                 use_container_width=True, hide_index=True)

    filas_gab = fdt.inventario(seleccion, "carcavas_gabinete")
    with st.expander(f"Carcavas caracterizadas - {len(filas_gab)} registro(s)",
                     expanded=False):
        st.dataframe(pd.DataFrame(filas_gab), use_container_width=True,
                     hide_index=True)
        r1, r2 = st.columns(2)
        r1.markdown("**Clase morfologica**")
        r1.dataframe(pd.DataFrame(fdt.ranking(
            seleccion, "carcavas_gabinete", "clase_morfologica")),
            use_container_width=True, hide_index=True)
        r2.markdown("**Clase NDVI**")
        r2.dataframe(pd.DataFrame(fdt.ranking(
            seleccion, "carcavas_gabinete", "clase_ndvi")),
            use_container_width=True, hide_index=True)


def _seccion_fichas_dt(cargados):
    """Graficos y tablas construidos sobre los 117 libros de campo F-DT."""
    st.markdown("**5. Fichas F-DT actualizadas: graficos y tablas**")
    st.caption(
        "Analitica de los 117 libros de campo `Plantillas Excel FDT "
        "actualizadas` que viajan con el aplicativo: las cinco fichas "
        "F-DT-01 a F-DT-05 de cada bloque, con sus inventarios de carcavas, "
        "elenco floristico, especies clave, matriz de causas, indicadores "
        "cuantitativos y fuentes de agua. Se despliega por bloque, distrito, "
        "provincia y consolidado total. Ningun valor ausente se estima: cada "
        "promedio informa cuantos bloques lo sustentan.")

    libros = fdt.fichas_del_repositorio()
    if not libros:
        st.info("El paquete de fichas F-DT no viaja en este despliegue. "
                "Suba `Plantillas Excel FDT actualizadas.zip` al repositorio "
                "para habilitar esta seccion.")
        return

    if not st.session_state.get("fdt_cargadas"):
        st.info(f"El aplicativo incluye **{len(libros)} libros de campo "
                f"F-DT**. La lectura completa toma unos segundos y queda en "
                f"memoria para el resto de la sesion.")
        if st.button(f"Leer las {len(libros)} fichas F-DT y generar la "
                     f"analitica", key="fdt_cargar", type="primary"):
            st.session_state["fdt_cargadas"] = True
            st.rerun()
        return

    catalogo = _catalogo_para_fichas(cargados)
    with st.spinner("Leyendo las fichas F-DT del repositorio..."):
        fichas, errores = _cached_fichas_dt(_items_catalogo(catalogo))
    if errores:
        st.error(f"{len(errores)} libro(s) no pudieron leerse:")
        st.dataframe(pd.DataFrame(errores, columns=["Archivo", "Motivo"]),
                     use_container_width=True, hide_index=True)
    if not fichas:
        return

    # ── Filtros territoriales de la seccion ──
    provincias = sorted({f["provincia"] for f in fichas if f.get("provincia")})
    distritos = sorted({f["distrito"] for f in fichas if f.get("distrito")})
    c1, c2 = st.columns(2)
    fil_prov = c1.multiselect("Provincia", provincias, key="fdt_f_prov")
    fil_dist = c2.multiselect("Distrito", distritos, key="fdt_f_dist")
    seleccion = [f for f in fichas
                 if (not fil_prov or f.get("provincia") in fil_prov)
                 and (not fil_dist or f.get("distrito") in fil_dist)]
    if not seleccion:
        st.warning("Ningun bloque cumple los filtros.")
        return

    general = fdt.resumen_general(seleccion)
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Bloques con ficha", general["bloques"])
    m2.metric("Cobertura vegetal media (%)",
              f"{general['cobertura_media']:.1f}"
              if general["cobertura_media"] is not None else "s/d",
              f"{general['cobertura_media_n']} bloques con dato")
    m3.metric("Suelo desnudo medio (%)",
              f"{general['suelo_desnudo_medio']:.1f}"
              if general["suelo_desnudo_medio"] is not None else "s/d",
              f"{general['suelo_desnudo_medio_n']} bloques con dato")
    m4.metric("Carcavas inventariadas", general["carcavas"])
    m5.metric("Fuentes de agua", general["fuentes_agua"])

    # Por omision, distrito: el nivel al que se leen los reportes del
    # estudio. Bloque son 117 filas y total una sola.
    nivel = st.radio(
        "Nivel de desagregacion", list(fdt.NIVELES), index=1, horizontal=True,
        format_func=lambda n: fdt.ETIQUETA_NIVEL[n], key="fdt_nivel")

    df = _df_tabla_compacta(seleccion, nivel)
    st.markdown(f"**Indicadores de cabecera por {fdt.ETIQUETA_NIVEL[nivel].lower()}**")
    st.dataframe(df, use_container_width=True, hide_index=True)

    g1, g2 = st.columns(2)
    with g1:
        _grafico_fdt(df, "Cobertura (%)", "Cobertura vegetal total (%)", nivel)
        _grafico_fdt(df, "Carcavas (n)", "Carcavas inventariadas", nivel)
    with g2:
        _grafico_fdt(df, "Suelo desn. (%)", "Suelo desnudo (%)", nivel)
        _grafico_fdt(df, "Taxones", "Taxones del elenco floristico", nivel)

    # ── Indicadores detallados del grupo ──
    resumen = fdt.tabla_resumen(seleccion, nivel)
    grupos = [fila["grupo"] for fila in resumen]
    with st.expander("Indicadores detallados de un grupo", expanded=False):
        grupo = st.selectbox(fdt.ETIQUETA_NIVEL[nivel], grupos,
                             key="fdt_grupo_detalle")
        fila = next((f for f in resumen if f["grupo"] == grupo), None)
        if fila:
            st.dataframe(pd.DataFrame(fdt.indicadores_largos(fila)),
                         use_container_width=True, hide_index=True)

    # ── Distribuciones categoricas ──
    st.markdown("**Distribucion de una variable categorica**")
    etiquetas_cat = dict(fdt.CATEGORICOS)
    campo = st.selectbox(
        "Variable", [c for c, _e in fdt.CATEGORICOS],
        format_func=lambda c: etiquetas_cat[c], key="fdt_categorico")
    filas_dist = fdt.distribucion(seleccion, campo, nivel)
    df_dist = pd.DataFrame(filas_dist)
    d1, d2 = st.columns([1.3, 1])
    d1.dataframe(df_dist, use_container_width=True, hide_index=True)
    total_dist = fdt.distribucion(seleccion, campo, "total")
    if total_dist:
        d2.caption(f"{etiquetas_cat[campo]} - todos los bloques filtrados")
        d2.bar_chart(pd.DataFrame(total_dist).set_index("Categoria")["Bloques"],
                     color="#1B4D2E", use_container_width=True)

    # ── Inventarios y rankings ──
    st.markdown("**Inventarios de las fichas**")
    etiquetas_inv = {t: e for t, e, _c, _a, _co in fdt.INVENTARIOS}
    tipo = st.selectbox("Inventario", list(etiquetas_inv),
                        format_func=lambda t: etiquetas_inv[t],
                        key="fdt_inventario")
    filas_inv = fdt.inventario(seleccion, tipo)
    st.caption(f"{len(filas_inv)} registro(s) en {len(seleccion)} bloque(s).")
    st.dataframe(pd.DataFrame(filas_inv), use_container_width=True,
                 hide_index=True)

    r1, r2 = st.columns(2)
    r1.markdown("**Causas de degradacion presentes**")
    r1.dataframe(pd.DataFrame(fdt.causas_presentes(seleccion, limite=15)),
                 use_container_width=True, hide_index=True)
    r2.markdown("**Especies mas frecuentes del elenco floristico**")
    r2.dataframe(pd.DataFrame(
        fdt.ranking(seleccion, "floristica", "nombre_comun", limite=15)),
        use_container_width=True, hide_index=True)

    _seccion_carcavas(seleccion, nivel)

    with st.expander("Cobertura declarada de cada indicador", expanded=False):
        st.caption("Cuantos bloques declaran cada dato. Un promedio sobre "
                   "pocos bloques no es el promedio del conjunto.")
        st.dataframe(pd.DataFrame(fdt.cobertura_declarada(seleccion)),
                     use_container_width=True, hide_index=True)

    # ── Reporte por bloque ──
    st.markdown("**Reporte de un bloque**")
    codigos = [f["codigo_bloque"] for f in seleccion]
    codigo = st.selectbox("Bloque", codigos, key="fdt_bloque")
    ficha = next((f for f in seleccion if f["codigo_bloque"] == codigo), None)
    if ficha:
        _detalle_ficha_dt(ficha)

    # ── Descargas ──
    st.markdown("**Descargas del reporte F-DT**")
    if st.button(f"Generar reporte {fdt.ETIQUETA_NIVEL[nivel].lower()} "
                 f"({len(seleccion)} bloques)", key="fdt_generar"):
        with st.spinner("Generando Excel y PDF..."):
            st.session_state["fdt_reporte"] = {
                "nivel": nivel,
                "n": len(seleccion),
                "xlsx": fdt.generar_excel_fdt(seleccion, nivel),
                "pdf": fdt.generar_pdf_fdt(seleccion, nivel),
            }
    reporte = st.session_state.get("fdt_reporte")
    if reporte:
        sufijo = fdt.ETIQUETA_NIVEL[reporte["nivel"]].replace(" ", "_")
        b1, b2 = st.columns(2)
        b1.download_button(
            f"Excel F-DT por {fdt.ETIQUETA_NIVEL[reporte['nivel']].lower()} "
            f"({reporte['n']} bloques)",
            reporte["xlsx"], file_name=f"Fichas_FDT_{sufijo}_IN_Piura.xlsx",
            mime=_mime_xlsx(), use_container_width=True, key="fdt_dl_xlsx")
        b2.download_button(
            f"PDF F-DT por {fdt.ETIQUETA_NIVEL[reporte['nivel']].lower()} "
            f"({reporte['n']} bloques)",
            reporte["pdf"], file_name=f"Fichas_FDT_{sufijo}_IN_Piura.pdf",
            mime="application/pdf", use_container_width=True,
            key="fdt_dl_pdf")


def _tab_resumenes_bloques(bm):
    """Pestana de resumenes Excel de Diagnostico Territorial por bloque."""
    st.markdown("### Resumenes Excel de Diagnostico Territorial por bloque")
    st.caption(
        "Un libro por bloque con cinco hojas: Resumen, Cobertura MSAVI-NDVI, "
        "Estaciones fotograficas, Microcuenca y Control de consistencia. "
        "Los libros revisados incorporan ademas las hojas de verificacion "
        "aerea con dron. "
        "Fuente: fichas F-DT-01 a F-DT-05, catalogo maestro Bloques V5/V6, "
        "estadistica zonal sobre el MDE y compuestos Sentinel-2. "
        "Sistema de referencia UTM WGS 84 Zona 17S (EPSG:32717).")

    _carga_masiva_resumenes(bm)
    st.markdown("---")

    cargados = _cached_obtener_resumenes_bloques(_cache_version())
    _catalogo_resumenes(bm, cargados)

    # La analitica de las fichas F-DT no depende de que haya resumenes
    # cargados: se construye sobre los libros de campo del repositorio.
    st.markdown("---")
    _seccion_fichas_dt(cargados)


def _catalogo_resumenes(bm, cargados):
    """Catalogo, consolidados y detalle de los resumenes ya cargados."""
    esperados = rbq.codigos_esperados()
    codigos_cargados = {r["codigo_bloque"] for r in cargados}

    st.markdown("**2. Catalogo de resumenes cargados**")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Bloques cargados", f"{len(cargados)} / {len(esperados) or '?'}")
    area = sum(r.get("area_ha") or 0 for r in cargados)
    m2.metric("Superficie acumulada (ha)", f"{area:,.2f}")
    bajo = sum(1 for r in cargados if (r.get("msavi_2024") is not None
                                       and r["msavi_2024"] < rbq.UMBRAL_MSAVI))
    m3.metric(f"Bajo umbral MSAVI {rbq.UMBRAL_MSAVI}", bajo)
    m4.metric("Discrepancias sustantivas",
              sum(r.get("n_sustantivas") or 0 for r in cargados))

    if not cargados:
        st.info("Aun no hay resumenes cargados. Use el cargador de arriba para "
                "subir los libros de la carpeta de Google Drive.")
        return

    pendientes = [c for c in esperados if c not in codigos_cargados]
    if pendientes:
        with st.expander(f"Faltan {len(pendientes)} de los {len(esperados)} "
                         "bloques con ficha DT", expanded=False):
            st.write(", ".join(pendientes))
    else:
        st.success(f"Los {len(esperados)} bloques con ficha DT estan cargados.")

    # ── Filtros ──
    f1, f2, f3 = st.columns(3)
    provincias = sorted({r.get("provincia", "") for r in cargados if r.get("provincia")})
    distritos = sorted({r.get("distrito", "") for r in cargados if r.get("distrito")})
    microcuencas = sorted({r.get("microcuenca", "") for r in cargados if r.get("microcuenca")})
    fil_prov = f1.multiselect("Provincia", provincias, key="rbq_f_prov")
    fil_dist = f2.multiselect("Distrito", distritos, key="rbq_f_dist")
    fil_micro = f3.multiselect("Microcuenca", microcuencas, key="rbq_f_micro")

    filtrados = [
        r for r in cargados
        if (not fil_prov or r.get("provincia") in fil_prov)
        and (not fil_dist or r.get("distrito") in fil_dist)
        and (not fil_micro or r.get("microcuenca") in fil_micro)
    ]
    st.caption(f"{len(filtrados)} bloque(s) tras aplicar los filtros.")
    st.dataframe(_tabla_resumenes(filtrados), use_container_width=True,
                 hide_index=True)

    # ── Consolidados ──
    st.markdown("**3. Descargas consolidadas (con graficos)**")
    codigos_filtrados = [r["codigo_bloque"] for r in filtrados]
    if codigos_filtrados:
        if st.button(f"Generar consolidado de {len(codigos_filtrados)} bloque(s)",
                     key="rbq_gen_consolidado"):
            with st.spinner("Generando Excel y PDF consolidados..."):
                datos = [rbq.completar_sintesis_msavi(d)
                         for d in db.obtener_datos_resumenes(codigos_filtrados)]
                st.session_state["rbq_consolidado"] = {
                    "n": len(datos),
                    "xlsx": rbq.generar_excel_consolidado(datos),
                    "pdf": rbq.generar_pdf_consolidado(datos),
                }
        consolidado = st.session_state.get("rbq_consolidado")
        if consolidado:
            c1, c2 = st.columns(2)
            c1.download_button(
                f"Excel consolidado ({consolidado['n']} bloques)",
                consolidado["xlsx"],
                file_name="Consolidado_Resumenes_DT_IN_Piura.xlsx",
                mime=_mime_xlsx(), use_container_width=True,
                key="rbq_dl_cons_xlsx")
            c2.download_button(
                f"PDF consolidado ({consolidado['n']} bloques)",
                consolidado["pdf"],
                file_name="Consolidado_Resumenes_DT_IN_Piura.pdf",
                mime="application/pdf", use_container_width=True,
                key="rbq_dl_cons_pdf")

    # ── Detalle por bloque ──
    st.markdown("---")
    st.markdown("**4. Detalle del bloque**")
    opciones = [r["codigo_bloque"] for r in filtrados]
    if not opciones:
        return
    codigo = st.selectbox("Bloque", opciones, key="rbq_sel_bloque")
    _detalle_resumen_bloque(codigo)

    with st.expander("Eliminar el resumen de este bloque", expanded=False):
        st.caption("Solo se elimina el libro de resumen cargado. Las fichas "
                   "F-DT registradas en el aplicativo no se tocan.")
        if st.checkbox(f"Confirmo eliminar el resumen del bloque {codigo}",
                       key=f"rbq_conf_del_{codigo}"):
            if st.button("Eliminar resumen", key=f"rbq_del_{codigo}"):
                db.eliminar_resumen_bloque(codigo)
                _invalidar_cache()
                _flash(f"Resumen del bloque {codigo} eliminado.", "info")
                st.rerun()


def pagina_diagnostico_territorial():
    import json as _json
    st.subheader("Diagnostico Territorial - Fichas de Evaluacion")
    st.caption("Fichas F-DT-01 a F-DT-05 (Plantilla V5): Parametros de evaluacion en campo "
               "para el diagnostico del territorio del Proyecto IN Piura.")
    _mostrar_flash()
    bm = _bloques_map()
    if not bm:
        st.warning("Registre un bloque primero.")
        return

    if "dt_edit_id" not in st.session_state:
        st.session_state["dt_edit_id"] = None
    if "dt_edit_data" not in st.session_state:
        st.session_state["dt_edit_data"] = None

    _dt_pending = st.session_state.pop("_dt_autocompletar_pending", None)
    if _dt_pending:
        for _k, _v in _dt_pending.items():
            st.session_state[_k] = _v
        st.session_state["dt_edit_id"] = None
        st.session_state["dt_edit_data"] = None

    dt_edit_id = st.session_state.get("dt_edit_id")
    dt_edit = st.session_state.get("dt_edit_data") or {}

    tab_reg, tab_hist, tab_excel, tab_resumen = st.tabs([
        "Registro de Diagnostico", "Historial / Consulta", "Importar desde Excel",
        "Resumenes por Bloque (117)",
    ])

    with tab_reg:
        if dt_edit_id:
            st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                        f'Modo Edicion - Diagnostico Territorial ID {dt_edit_id}</div>',
                        unsafe_allow_html=True)
            if st.button("Cancelar edicion", key="dt_cancel_edit"):
                st.session_state["dt_edit_id"] = None
                st.session_state["dt_edit_data"] = None
                st.rerun()

        bl = st.selectbox("Bloque de Intervencion", list(bm.keys()), key="dt_bl")
        bid = bm[bl]

        # ── Auto-vinculacion: microcuenca, provincia, distrito, superficie, UTM ──
        info_bl = _resolver_datos_bloque(bl)
        mc_auto_dt = info_bl.get("microcuenca") or ""
        prov_auto_dt = info_bl.get("provincia") or ""
        dist_auto_dt = info_bl.get("distrito") or ""
        area_auto_dt = info_bl.get("area_ha") or 0.0
        utm_e_auto = info_bl.get("utm_este") or 0.0
        utm_n_auto = info_bl.get("utm_norte") or 0.0
        zona_auto_dt = info_bl.get("zona") or ""

        if mc_auto_dt and mc_auto_dt in MICROCUENCAS:
            mc_idx_dt = MICROCUENCAS.index(mc_auto_dt) + 1
        else:
            mc_idx_dt = 0
        if dt_edit_id:
            mc_val = dt_edit.get("microcuenca", "")
            if mc_val and mc_val in MICROCUENCAS:
                mc_idx_dt = MICROCUENCAS.index(mc_val) + 1

        if any([mc_auto_dt, prov_auto_dt, dist_auto_dt, area_auto_dt, utm_e_auto, utm_n_auto]):
            st.info(
                f"**Datos vinculados automáticamente al bloque {bl}:**  \n"
                f"• Microcuenca: **{mc_auto_dt or '-'}** | Zona: **{zona_auto_dt or '-'}**  \n"
                f"• Provincia: **{prov_auto_dt or '-'}** | Distrito: **{dist_auto_dt or '-'}**  \n"
                f"• Superficie: **{area_auto_dt:.3f} ha**  \n"
                f"• Centroide UTM (Zona 17S, WGS84): **{int(utm_e_auto):,} E / "
                f"{int(utm_n_auto):,} N**"
            )

        # ── Datos generales V5 (compartidos por todas las fichas) ────────
        st.markdown("### 1. Datos Generales (compartidos)")

        def_fecha_dt = datetime.now()
        def_evaluador = ""
        def_brigada = ""
        def_correlativo = ""
        def_hora = datetime.now().strftime("%H:%M")
        def_altitud = ""
        def_cp = ""
        def_cc = ""
        def_utm_e = str(int(utm_e_auto)) if utm_e_auto else ""
        def_utm_n = str(int(utm_n_auto)) if utm_n_auto else ""
        if dt_edit_id:
            def_evaluador = dt_edit.get("evaluador", "") or ""
            def_brigada = dt_edit.get("brigada", "") or ""
            def_correlativo = dt_edit.get("ficha_correlativo", "") or ""
            def_hora = dt_edit.get("hora_registro", "") or def_hora
            def_altitud = dt_edit.get("altitud_gps", "") or ""
            def_cp = dt_edit.get("centro_poblado_cercano", "") or ""
            def_cc = dt_edit.get("comunidad_campesina_dt", "") or ""
            def_utm_e = dt_edit.get("utm_este_dt", "") or def_utm_e
            def_utm_n = dt_edit.get("utm_norte_dt", "") or def_utm_n
            try:
                def_fecha_dt = datetime.strptime(dt_edit.get("fecha_evaluacion", ""), "%Y-%m-%d")
            except (ValueError, TypeError):
                pass

        rA, rB, rC = st.columns(3)
        fecha_ev = rA.date_input(
            "Fecha de evaluacion *", value=def_fecha_dt, key="dt_fecha",
            min_value=FECHA_MIN_PROYECTO, max_value=date.today())
        hora_reg = rB.text_input("Hora de registro", value=def_hora, key="dt_hora")
        correlativo = rC.text_input("Ficha N° (correlativo)", value=def_correlativo, key="dt_corr")

        rD, rE, rF = st.columns(3)
        evaluador = rD.text_input("Evaluador / Brigada / Responsable *",
                                  value=def_evaluador or def_brigada, key="dt_eval")
        brigada = rE.text_input("Brigada (si difiere del responsable)",
                                value=def_brigada, key="dt_brigada")
        mc = rF.selectbox("Microcuenca", [""] + MICROCUENCAS, index=mc_idx_dt, key="dt_mc")

        rG, rH, rI = st.columns(3)
        utm_e_in = rG.text_input("UTM Este (m) — punto de muestreo *",
                                 value=def_utm_e, key="dt_utm_e")
        utm_n_in = rH.text_input("UTM Norte (m) — punto de muestreo *",
                                 value=def_utm_n, key="dt_utm_n")
        altitud_gps = rI.text_input("Altitud GPS (msnm) *", value=def_altitud, key="dt_altitud")

        rJ, rK = st.columns(2)
        centro_poblado = rJ.text_input("Centro poblado más cercano",
                                       value=def_cp, key="dt_cp")
        comunidad_campesina = rK.text_input("Comunidad Campesina (si aplica)",
                                            value=def_cc, key="dt_cc")

        st.markdown("---")
        st.markdown("### 2. Fichas de Diagnostico V5")
        st.markdown("*Despliegue cada ficha y complete los parametros relevantes a la visita de campo.*")

        # ╔════════════════════════════════════════════════════════════════╗
        # ║ F-DT-01: DATOS GENERALES Y FISIOGRAFIA DEL BLOQUE              ║
        # ╚════════════════════════════════════════════════════════════════╝
        with st.expander("F-DT-01: DATOS GENERALES Y FISIOGRAFIA DEL BLOQUE", expanded=False):
            st.markdown("**Caracterizacion fisiografica del bloque**")
            c1, c2 = st.columns(2)
            forma_terreno = c1.selectbox(
                "Forma predominante del terreno *",
                [""] + FDT_FORMA_TERRENO,
                index=([""] + FDT_FORMA_TERRENO).index(dt_edit.get("forma_terreno", ""))
                    if dt_edit.get("forma_terreno", "") in FDT_FORMA_TERRENO else 0,
                key="f01_ft")
            pendiente = c2.selectbox(
                "Rango de pendiente dominante *",
                [""] + FDT_RANGO_PENDIENTE,
                index=([""] + FDT_RANGO_PENDIENTE).index(dt_edit.get("pendiente", ""))
                    if dt_edit.get("pendiente", "") in FDT_RANGO_PENDIENTE else 0,
                key="f01_pe")
            c3, c4 = st.columns(2)
            posicion_fisio = c3.selectbox(
                "Posición fisiográfica *",
                [""] + FDT_POSICION_FISIO,
                index=([""] + FDT_POSICION_FISIO).index(dt_edit.get("posicion_fisiografica", ""))
                    if dt_edit.get("posicion_fisiografica", "") in FDT_POSICION_FISIO else 0,
                key="f01_pf")
            exposicion = c4.selectbox(
                "Exposición / Orientación dominante *",
                [""] + FDT_EXPOSICION,
                index=([""] + FDT_EXPOSICION).index(dt_edit.get("exposicion_orientacion", ""))
                    if dt_edit.get("exposicion_orientacion", "") in FDT_EXPOSICION else 0,
                key="f01_ex")
            c5, c6 = st.columns(2)
            rango_alt = c5.selectbox(
                "Rango altitudinal del bloque *",
                [""] + FDT_RANGO_ALTITUD,
                index=([""] + FDT_RANGO_ALTITUD).index(dt_edit.get("rango_altitudinal", ""))
                    if dt_edit.get("rango_altitudinal", "") in FDT_RANGO_ALTITUD else 0,
                key="f01_ra")
            paisaje = c6.text_input("Paisaje dominante (descripción libre)",
                                    value=dt_edit.get("paisaje_dominante", ""), key="f01_pa")

            st.markdown("**Indicios de remoción en masa e inestabilidad**")
            d1, d2 = st.columns(2)
            f01_aflora = d1.selectbox(
                "Presencia de afloramientos rocosos", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt01_afloramientos_rocosos", ""))
                    if dt_edit.get("dt01_afloramientos_rocosos", "") in FDT_SI_NO else 0,
                key="f01_af")
            f01_escarpe = d2.selectbox(
                "Presencia de escarpes activos *", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt01_escarpes_activos", ""))
                    if dt_edit.get("dt01_escarpes_activos", "") in FDT_SI_NO else 0,
                key="f01_es")
            d3, d4 = st.columns(2)
            f01_reptacion = d3.selectbox(
                "Reptación de suelo observada *", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt01_reptacion_suelo", ""))
                    if dt_edit.get("dt01_reptacion_suelo", "") in FDT_SI_NO else 0,
                key="f01_rp")
            f01_desliz = d4.selectbox(
                "Deslizamientos antiguos observados", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt01_deslizamientos_antiguos", ""))
                    if dt_edit.get("dt01_deslizamientos_antiguos", "") in FDT_SI_NO else 0,
                key="f01_de")
            f01_remocion = st.selectbox(
                "Remociones en masa activas *", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt01_remociones_masa_activas", ""))
                    if dt_edit.get("dt01_remociones_masa_activas", "") in FDT_SI_NO else 0,
                key="f01_rm")

            f01_obs = st.text_area("Observaciones F-DT-01",
                                   value=dt_edit.get("dt01_observaciones", ""),
                                   key="f01_obs")

        # ╔════════════════════════════════════════════════════════════════╗
        # ║ F-DT-02: SUELO Y PROCESOS EROSIVOS (INCL. CARCAVAS)            ║
        # ╚════════════════════════════════════════════════════════════════╝
        with st.expander("F-DT-02: SUELO Y PROCESOS EROSIVOS", expanded=False):
            st.markdown("**Descripción de procesos erosivos del suelo**")
            e1, e2 = st.columns(2)
            f02_sell = e1.selectbox(
                "Sellamiento / Costra superficial", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt02_sellamiento_costra", ""))
                    if dt_edit.get("dt02_sellamiento_costra", "") in FDT_SI_NO else 0,
                key="f02_sell")
            f02_compa = e2.selectbox(
                "Compactación por pisoteo de ganado", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt02_compactacion_pisoteo", ""))
                    if dt_edit.get("dt02_compactacion_pisoteo", "") in FDT_SI_NO else 0,
                key="f02_compa")
            e3, e4 = st.columns(2)
            f02_raices = e3.selectbox(
                "Raíces expuestas en superficie", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt02_raices_expuestas", ""))
                    if dt_edit.get("dt02_raices_expuestas", "") in FDT_SI_NO else 0,
                key="f02_raices")
            f02_nivel = e4.selectbox(
                "Nivel general de erosión observado *", [""] + FDT_NIVEL_EROSION,
                index=([""] + FDT_NIVEL_EROSION).index(dt_edit.get("dt02_nivel_erosion_general", ""))
                    if dt_edit.get("dt02_nivel_erosion_general", "") in FDT_NIVEL_EROSION else 0,
                key="f02_nivel")

            st.markdown("**Inventario georreferenciado de cárcavas / surcos** "
                        "(registre una fila por cárcava o grupo homogéneo)")
            carcavas_cols = [
                ("codigo", "Código"), ("tipo", "Tipo"),
                ("utm_e_ini", "UTM E inicio"), ("utm_n_ini", "UTM N inicio"),
                ("utm_e_fin", "UTM E fin"), ("utm_n_fin", "UTM N fin"),
                ("longitud_m", "Long. (m)"), ("prof_m", "Prof. (m)"),
                ("ancho_m", "Ancho (m)"), ("estado", "Estado"),
                ("causa", "Causa principal"), ("foto", "Cód. foto"),
            ]
            carcavas_opts = {
                "tipo": FDT_TIPO_CARCAVA,
                "estado": FDT_ESTADO_CARCAVA,
                "causa": FDT_CAUSA_CARCAVA,
            }
            carcavas_data = _dt_load_json(dt_edit.get("dt02_carcavas_json", ""), [])
            carcavas_rows = _dt_dataeditor(
                "Cárcavas / surcos (10 filas)", carcavas_cols, 10,
                "f02_carcavas_ed", options=carcavas_opts, edit_data=carcavas_data)

            st.markdown("**Síntesis de procesos erosivos del bloque**")
            f1, f2 = st.columns(2)
            f02_sint = f1.selectbox(
                "Nivel general de erosión (síntesis) *", [""] + FDT_NIVEL_EROSION,
                index=([""] + FDT_NIVEL_EROSION).index(dt_edit.get("dt02_nivel_erosion_sintesis", ""))
                    if dt_edit.get("dt02_nivel_erosion_sintesis", "") in FDT_NIVEL_EROSION else 0,
                key="f02_sint")
            f02_num = f2.text_input("N° total de cárcavas registradas",
                                    value=dt_edit.get("dt02_num_carcavas", ""), key="f02_num")
            f3, f4 = st.columns(2)
            f02_long = f3.text_input("Longitud total de cárcavas (m)",
                                     value=dt_edit.get("dt02_longitud_total_carcavas", ""), key="f02_long")
            f02_pct = f4.text_input("% del bloque afectado por cárcavas",
                                    value=dt_edit.get("dt02_pct_bloque_carcavas", ""), key="f02_pct")
            f5, f6 = st.columns(2)
            f02_lam = f5.text_input("Erosión laminar observada (%)",
                                    value=dt_edit.get("dt02_erosion_laminar_pct", ""), key="f02_lam")
            f02_pat = f6.selectbox(
                "Patrón de cárcavas dominante", [""] + FDT_PATRON_CARCAVAS,
                index=([""] + FDT_PATRON_CARCAVAS).index(dt_edit.get("dt02_patron_carcavas", ""))
                    if dt_edit.get("dt02_patron_carcavas", "") in FDT_PATRON_CARCAVAS else 0,
                key="f02_pat")
            f7, f8 = st.columns(2)
            f02_soc = f7.selectbox(
                "Presencia de socavamiento de cauce", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt02_socavamiento_cauce", ""))
                    if dt_edit.get("dt02_socavamiento_cauce", "") in FDT_SI_NO else 0,
                key="f02_soc")
            f02_urg = f8.selectbox(
                "Urgencia de control", [""] + FDT_URGENCIA,
                index=([""] + FDT_URGENCIA).index(dt_edit.get("dt02_urgencia_control", ""))
                    if dt_edit.get("dt02_urgencia_control", "") in FDT_URGENCIA else 0,
                key="f02_urg")
            f02_obs = st.text_area("Observaciones F-DT-02",
                                   value=dt_edit.get("dt02_observaciones", ""), key="f02_obs")

        # ╔════════════════════════════════════════════════════════════════╗
        # ║ F-DT-03: ECOSISTEMA: COMPOSICION, ESTRUCTURA Y VALOR ECOLOGICO ║
        # ╚════════════════════════════════════════════════════════════════╝
        with st.expander("F-DT-03: ECOSISTEMA — COMPOSICION, ESTRUCTURA Y VALOR ECOLOGICO",
                         expanded=False):
            st.markdown("**Datos de la parcela de muestreo**")
            g1, g2, g3 = st.columns(3)
            f03_parcela = g1.text_input("Parcela de muestreo",
                                        value=dt_edit.get("dt03_parcela_muestreo", ""), key="f03_parcela")
            f03_dim = g2.text_input("Dimensiones (m × m)",
                                    value=dt_edit.get("dt03_dim_parcela", ""), key="f03_dim")
            f03_pend = g3.text_input("Pendiente promedio parcela (%)",
                                     value=dt_edit.get("dt03_pendiente_parcela", ""), key="f03_pend")
            g4, g5 = st.columns(2)
            f03_cobtot = g4.text_input("Cobertura vegetal total estimada (%) *",
                                       value=dt_edit.get("dt03_cobertura_total", ""), key="f03_cobtot")
            f03_uso = g5.selectbox(
                "Uso actual dominante del suelo *", [""] + FDT_USO_SUELO_DOM,
                index=([""] + FDT_USO_SUELO_DOM).index(dt_edit.get("dt03_uso_dominante", ""))
                    if dt_edit.get("dt03_uso_dominante", "") in FDT_USO_SUELO_DOM else 0,
                key="f03_uso")

            st.markdown("**Clasificación del ecosistema (UP)**")
            h1, h2 = st.columns(2)
            f03_eco = h1.selectbox(
                "Tipo de ecosistema MINAM (dominante) *", [""] + FDT_TIPO_ECOSISTEMA,
                index=([""] + FDT_TIPO_ECOSISTEMA).index(dt_edit.get("dt03_tipo_ecosistema", ""))
                    if dt_edit.get("dt03_tipo_ecosistema", "") in FDT_TIPO_ECOSISTEMA else 0,
                key="f03_eco")
            f03_supe = h2.text_input("Superficie del ecosistema en el bloque (ha)",
                                     value=dt_edit.get("dt03_superficie_ecosistema", ""), key="f03_supe")
            f03_cons = st.selectbox(
                "Estado de conservación general *", [""] + FDT_ESTADO_CONSERVACION,
                index=([""] + FDT_ESTADO_CONSERVACION).index(dt_edit.get("dt03_estado_conservacion_eco", ""))
                    if dt_edit.get("dt03_estado_conservacion_eco", "") in FDT_ESTADO_CONSERVACION else 0,
                key="f03_cons")

            st.markdown("**Estructura del ecosistema** (porcentajes y alturas)")
            i1, i2 = st.columns(2)
            f03_dosel = i1.text_input("Cobertura del dosel arbóreo (%)",
                                      value=dt_edit.get("dt03_cobertura_dosel", ""), key="f03_dosel")
            f03_arbus = i2.text_input("Cobertura arbustiva (%)",
                                      value=dt_edit.get("dt03_cobertura_arbustiva", ""), key="f03_arbus")
            i3, i4 = st.columns(2)
            f03_herb = i3.text_input("Cobertura herbácea-graminoide (%)",
                                     value=dt_edit.get("dt03_cobertura_herbacea", ""), key="f03_herb")
            f03_hoja = i4.text_input("Cobertura de hojarasca (%)",
                                     value=dt_edit.get("dt03_cobertura_hojarasca", ""), key="f03_hoja")
            i5, i6 = st.columns(2)
            f03_desn = i5.text_input("Cobertura de suelo desnudo (%)",
                                     value=dt_edit.get("dt03_suelo_desnudo", ""), key="f03_desn")
            f03_haltd = i6.text_input("Altura promedio estrato dominante (m)",
                                      value=dt_edit.get("dt03_altura_estrato_dom", ""), key="f03_haltd")
            i7, i8 = st.columns(2)
            f03_hmax = i7.text_input("Altura máxima observada (m)",
                                     value=dt_edit.get("dt03_altura_max", ""), key="f03_hmax")
            f03_dap = i8.text_input("DAP promedio árboles DAP≥10 cm (cm)",
                                    value=dt_edit.get("dt03_dap_promedio", ""), key="f03_dap")

            j1, j2 = st.columns(2)
            f03_regen = j1.selectbox(
                "Regeneración natural observada *", [""] + FDT_REGENERACION,
                index=([""] + FDT_REGENERACION).index(dt_edit.get("dt03_regeneracion_natural", ""))
                    if dt_edit.get("dt03_regeneracion_natural", "") in FDT_REGENERACION else 0,
                key="f03_regen")
            f03_san = j2.selectbox(
                "Estado sanitario general del dosel *", [""] + FDT_ESTADO_SANITARIO,
                index=([""] + FDT_ESTADO_SANITARIO).index(dt_edit.get("dt03_estado_sanitario", ""))
                    if dt_edit.get("dt03_estado_sanitario", "") in FDT_ESTADO_SANITARIO else 0,
                key="f03_san")
            j3, j4 = st.columns(2)
            f03_epif = j3.text_input("Presencia de epífitas (cualitativa)",
                                     value=dt_edit.get("dt03_presencia_epifitas", ""), key="f03_epif")
            f03_feno = j4.selectbox(
                "Fenología dominante (época de visita)", [""] + FDT_FENOLOGIA,
                index=([""] + FDT_FENOLOGIA).index(dt_edit.get("dt03_fenologia_dominante", ""))
                    if dt_edit.get("dt03_fenologia_dominante", "") in FDT_FENOLOGIA else 0,
                key="f03_feno")
            f03_tipocob = st.selectbox(
                "Tipo de cobertura vegetal dominante *", [""] + FDT_TIPO_COBERTURA,
                index=([""] + FDT_TIPO_COBERTURA).index(dt_edit.get("dt03_tipo_cobertura_dom", ""))
                    if dt_edit.get("dt03_tipo_cobertura_dom", "") in FDT_TIPO_COBERTURA else 0,
                key="f03_tipocob")

            st.markdown("**Composición florística (mín. 15 especies)**")
            flora_cols = [
                ("nombre_comun", "Nombre común"),
                ("nombre_cientifico", "Nombre científico"),
                ("familia", "Familia"),
                ("estrato", "Estrato"),
                ("origen", "Origen"),
                ("abundancia", "Abundancia"),
                ("dap_cm", "DAP (cm)"),
                ("altura_m", "Altura (m)"),
            ]
            flora_opts = {
                "estrato": FDT_ESTRATO,
                "origen": FDT_ORIGEN,
                "abundancia": FDT_ABUNDANCIA,
            }
            flora_data = _dt_load_json(dt_edit.get("dt03_floristica_json", ""), [])
            flora_rows = _dt_dataeditor(
                "Especies (15 filas)", flora_cols, 15,
                "f03_flora_ed", options=flora_opts, edit_data=flora_data)

            st.markdown("**Especies clave / indicadoras**")
            esp_cols = [
                ("nombre", "Nombre científico/común"),
                ("categoria", "Categoría"),
                ("estado_uicn", "Estado UICN / D.S. 043"),
                ("utm_e", "UTM Este"), ("utm_n", "UTM Norte"),
                ("n_indiv", "N° indiv."), ("foto", "Foto N°"),
                ("observacion", "Observación"),
            ]
            esp_opts = {
                "categoria": FDT_CATEGORIA_INDICADORA,
                "estado_uicn": FDT_ESTADO_UICN,
            }
            esp_data = _dt_load_json(dt_edit.get("dt03_especies_clave_json", ""), [])
            esp_rows = _dt_dataeditor(
                "Especies clave (10 filas)", esp_cols, 10,
                "f03_esp_ed", options=esp_opts, edit_data=esp_data)

            f03_obs = st.text_area("Observaciones F-DT-03",
                                   value=dt_edit.get("dt03_observaciones", ""), key="f03_obs")

        # ╔════════════════════════════════════════════════════════════════╗
        # ║ F-DT-04: CAUSAS E INDICADORES DE DEGRADACION                   ║
        # ╚════════════════════════════════════════════════════════════════╝
        with st.expander("F-DT-04: CAUSAS E INDICADORES DE DEGRADACION", expanded=False):
            st.markdown("**Matriz de causas de degradación** "
                        "(intensidad: Nula/Ligera/Moderada/Fuerte/Muy fuerte)")
            causas_cols = [
                ("n", "N°"), ("causa", "Causa / Factor"),
                ("presencia", "Presencia"), ("intensidad", "Intensidad"),
                ("extension", "Extensión (%)"),
                ("antiguedad", "Antigüedad (años)"),
                ("evidencia", "Evidencia / Descripción"),
            ]
            causas_opts = {
                "presencia": FDT_SI_NO,
                "intensidad": FDT_INTENSIDAD,
            }
            # Datos predefinidos: 16 causas fijas con presencia/intensidad vacios
            causas_existentes = _dt_load_json(dt_edit.get("dt04_causas_json", ""), [])
            causas_default = []
            for i, lbl in enumerate(FDT04_CAUSAS_LABELS, 1):
                row = {"n": str(i), "causa": lbl, "presencia": "", "intensidad": "",
                       "extension": "", "antiguedad": "", "evidencia": ""}
                if i - 1 < len(causas_existentes):
                    prev = causas_existentes[i - 1]
                    for k in row:
                        if prev.get(k):
                            row[k] = prev[k]
                causas_default.append(row)
            causas_rows = _dt_dataeditor(
                "Causas (16 fijas)", causas_cols, 16,
                "f04_causas_ed", options=causas_opts, edit_data=causas_default)

            st.markdown("**Indicadores cuantitativos de degradación**")
            ind_cols = [
                ("n", "N°"), ("indicador", "Indicador"), ("unidad", "Unidad"),
                ("valor", "Valor"), ("fuente", "Fuente"),
                ("umbral", "Umbral / Referencia"), ("nivel", "Nivel"),
            ]
            ind_opts = {"nivel": FDT_NIVEL_IND}
            ind_existentes = _dt_load_json(dt_edit.get("dt04_indicadores_json", ""), [])
            ind_default = []
            for i, (nombre, unidad, umbral) in enumerate(FDT04_INDICADORES_LABELS, 1):
                row = {"n": str(i), "indicador": nombre, "unidad": unidad,
                       "valor": "", "fuente": "", "umbral": umbral, "nivel": ""}
                if i - 1 < len(ind_existentes):
                    prev = ind_existentes[i - 1]
                    for k in row:
                        if prev.get(k):
                            row[k] = prev[k]
                ind_default.append(row)
            ind_rows = _dt_dataeditor(
                "Indicadores (8 fijos)", ind_cols, 8,
                "f04_ind_ed", options=ind_opts, edit_data=ind_default)

            st.markdown("**Síntesis diagnóstica de la degradación**")
            f04_dir = st.text_area(
                "Principales causas directas (texto libre)",
                value=dt_edit.get("dt04_causas_directas_texto", ""), key="f04_dir")
            k1, k2 = st.columns(2)
            f04_sub = k1.text_input("Principal causa subyacente (motor)",
                                    value=dt_edit.get("dt04_causa_subyacente", ""), key="f04_sub")
            f04_vel = k2.selectbox(
                "Velocidad de degradación percibida", [""] + FDT_VELOCIDAD,
                index=([""] + FDT_VELOCIDAD).index(dt_edit.get("dt04_velocidad_degradacion", ""))
                    if dt_edit.get("dt04_velocidad_degradacion", "") in FDT_VELOCIDAD else 0,
                key="f04_vel")
            k3, k4 = st.columns(2)
            f04_rev = k3.selectbox(
                "Reversibilidad técnica", [""] + FDT_REVERSIBILIDAD,
                index=([""] + FDT_REVERSIBILIDAD).index(dt_edit.get("dt04_reversibilidad", ""))
                    if dt_edit.get("dt04_reversibilidad", "") in FDT_REVERSIBILIDAD else 0,
                key="f04_rev")
            f04_urg = k4.selectbox(
                "Urgencia de intervención", [""] + FDT_URGENCIA,
                index=([""] + FDT_URGENCIA).index(dt_edit.get("dt04_urgencia_intervencion", ""))
                    if dt_edit.get("dt04_urgencia_intervencion", "") in FDT_URGENCIA else 0,
                key="f04_urg")
            f04_obs = st.text_area("Observaciones F-DT-04",
                                   value=dt_edit.get("dt04_observaciones", ""), key="f04_obs")

        # ╔════════════════════════════════════════════════════════════════╗
        # ║ F-DT-05: RECURSOS HIDRICOS Y ACCESIBILIDAD                     ║
        # ╚════════════════════════════════════════════════════════════════╝
        with st.expander("F-DT-05: RECURSOS HIDRICOS Y ACCESIBILIDAD", expanded=False):
            st.markdown("**Inventario de fuentes de agua** (dentro o hasta 500 m del bloque)")
            fuente_cols = [
                ("n", "N°"), ("tipo", "Tipo de fuente"),
                ("utm_e", "UTM Este"), ("utm_n", "UTM Norte"),
                ("regimen", "Régimen"), ("calidad", "Calidad aparente"),
                ("distancia_m", "Distancia (m)"),
                ("uso_obs", "Uso observado / Obs."),
            ]
            fuente_opts = {
                "tipo": FDT_TIPO_FUENTE,
                "regimen": FDT_REGIMEN_HIDRICO,
                "calidad": FDT_CALIDAD_AGUA,
            }
            fuentes_existentes = _dt_load_json(dt_edit.get("dt05_fuentes_agua_json", ""), [])
            fuente_default = []
            for i in range(1, 11):
                row = {"n": str(i), "tipo": "", "utm_e": "", "utm_n": "",
                       "regimen": "", "calidad": "", "distancia_m": "", "uso_obs": ""}
                if i - 1 < len(fuentes_existentes):
                    prev = fuentes_existentes[i - 1]
                    for k in row:
                        if prev.get(k):
                            row[k] = prev[k]
                fuente_default.append(row)
            fuente_rows = _dt_dataeditor(
                "Fuentes (10 filas)", fuente_cols, 10,
                "f05_fuentes_ed", options=fuente_opts, edit_data=fuente_default)

            st.markdown("**Análisis hídrico preliminar**")
            l1, l2 = st.columns(2)
            f05_recarga = l1.selectbox(
                "¿Bloque en zona de recarga hídrica?", [""] + FDT_SI_NO_NA,
                index=([""] + FDT_SI_NO_NA).index(dt_edit.get("dt05_zona_recarga", ""))
                    if dt_edit.get("dt05_zona_recarga", "") in FDT_SI_NO_NA else 0,
                key="f05_recarga")
            f05_humedad = l2.selectbox(
                "¿Zonas de humedad persistente observadas?", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt05_humedad_persistente", ""))
                    if dt_edit.get("dt05_humedad_persistente", "") in FDT_SI_NO else 0,
                key="f05_humedad")
            l3, l4 = st.columns(2)
            f05_escor = l3.selectbox(
                "¿Escorrentía concentrada observada?", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt05_escorrentia_concentrada", ""))
                    if dt_edit.get("dt05_escorrentia_concentrada", "") in FDT_SI_NO else 0,
                key="f05_escor")
            f05_distcap = l4.text_input("Distancia a captación poblacional más cercana (m)",
                                        value=dt_edit.get("dt05_dist_captacion", ""), key="f05_distcap")
            l5, l6 = st.columns(2)
            f05_jass = l5.text_input("Nombre JASS o captación asociada",
                                     value=dt_edit.get("dt05_jass_captacion", ""), key="f05_jass")
            f05_inter = l6.selectbox(
                "¿Interferencia con obras de riego?", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt05_interferencia_riego", ""))
                    if dt_edit.get("dt05_interferencia_riego", "") in FDT_SI_NO else 0,
                key="f05_inter")
            f05_riego = st.text_input("Nombre del sistema de riego (si aplica)",
                                      value=dt_edit.get("dt05_sistema_riego_nombre", ""), key="f05_riego")

            st.markdown("**Accesibilidad y logística**")
            m1, m2 = st.columns(2)
            f05_modo = m1.selectbox(
                "Modalidad de acceso al bloque *", [""] + FDT_MODALIDAD_ACCESO,
                index=([""] + FDT_MODALIDAD_ACCESO).index(dt_edit.get("dt05_modalidad_acceso", ""))
                    if dt_edit.get("dt05_modalidad_acceso", "") in FDT_MODALIDAD_ACCESO else 0,
                key="f05_modo")
            f05_via = m2.text_input("Vía principal de acceso (PE-/PI-/trocha) *",
                                    value=dt_edit.get("dt05_via_principal", ""), key="f05_via")
            m3, m4 = st.columns(2)
            f05_tvia = m3.selectbox(
                "Tipo de vía final", [""] + FDT_TIPO_VIA,
                index=([""] + FDT_TIPO_VIA).index(dt_edit.get("dt05_tipo_via_final", ""))
                    if dt_edit.get("dt05_tipo_via_final", "") in FDT_TIPO_VIA else 0,
                key="f05_tvia")
            f05_tseca = m4.selectbox(
                "Transitabilidad — época seca", [""] + FDT_NIVEL_TRANSITAB,
                index=([""] + FDT_NIVEL_TRANSITAB).index(dt_edit.get("dt05_transitabilidad_seca", ""))
                    if dt_edit.get("dt05_transitabilidad_seca", "") in FDT_NIVEL_TRANSITAB else 0,
                key="f05_tseca")
            m5, m6 = st.columns(2)
            f05_tllu = m5.selectbox(
                "Transitabilidad — época lluviosa", [""] + FDT_NIVEL_TRANSITAB,
                index=([""] + FDT_NIVEL_TRANSITAB).index(dt_edit.get("dt05_transitabilidad_lluviosa", ""))
                    if dt_edit.get("dt05_transitabilidad_lluviosa", "") in FDT_NIVEL_TRANSITAB else 0,
                key="f05_tllu")
            f05_tcap = m6.text_input("Tiempo desde capital distrital (min)",
                                     value=dt_edit.get("dt05_tiempo_dist_capital", ""), key="f05_tcap")
            m7, m8 = st.columns(2)
            f05_tprov = m7.text_input("Tiempo desde capital provincial (min)",
                                      value=dt_edit.get("dt05_tiempo_prov_capital", ""), key="f05_tprov")
            f05_senal = m8.selectbox(
                "Señal celular", [""] + FDT_SENAL_CELULAR,
                index=([""] + FDT_SENAL_CELULAR).index(dt_edit.get("dt05_senal_celular", ""))
                    if dt_edit.get("dt05_senal_celular", "") in FDT_SENAL_CELULAR else 0,
                key="f05_senal")
            m9, m10 = st.columns(2)
            f05_oper = m9.selectbox(
                "Operador celular dominante", [""] + FDT_OPERADOR,
                index=([""] + FDT_OPERADOR).index(dt_edit.get("dt05_operador_celular", ""))
                    if dt_edit.get("dt05_operador_celular", "") in FDT_OPERADOR else 0,
                key="f05_oper")
            f05_aloj = m10.selectbox(
                "Alojamiento rural disponible", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt05_alojamiento", ""))
                    if dt_edit.get("dt05_alojamiento", "") in FDT_SI_NO else 0,
                key="f05_aloj")
            m11, m12 = st.columns(2)
            f05_ronda = m11.selectbox(
                "¿Requiere autorización de Ronda Campesina? *", [""] + FDT_SI_NO,
                index=([""] + FDT_SI_NO).index(dt_edit.get("dt05_requiere_ronda", ""))
                    if dt_edit.get("dt05_requiere_ronda", "") in FDT_SI_NO else 0,
                key="f05_ronda")
            f05_contacto = m12.text_input("Nombre / Contacto responsable de Ronda",
                                          value=dt_edit.get("dt05_contacto_ronda", ""), key="f05_contacto")
            f05_obs = st.text_area("Observaciones F-DT-05",
                                   value=dt_edit.get("dt05_observaciones", ""), key="f05_obs")

        st.markdown("---")
        observ_gen = st.text_area("Observaciones generales del diagnóstico",
                                  value=dt_edit.get("observaciones_generales", ""),
                                  key="dt_obs")

        # ── Determinar fichas con datos ─────────────────────────────────
        fichas_sel = []
        if any([forma_terreno, pendiente, posicion_fisio, exposicion, rango_alt,
                paisaje, f01_aflora, f01_escarpe, f01_reptacion, f01_desliz,
                f01_remocion, f01_obs]):
            fichas_sel.append("F-DT-01")
        if any([f02_sell, f02_compa, f02_raices, f02_nivel, f02_sint,
                f02_num, f02_long, f02_pct, f02_lam, f02_pat, f02_soc,
                f02_urg, f02_obs]) or any(any(r.values()) for r in carcavas_rows):
            fichas_sel.append("F-DT-02")
        if any([f03_parcela, f03_dim, f03_pend, f03_cobtot, f03_uso,
                f03_eco, f03_supe, f03_cons, f03_dosel, f03_arbus, f03_herb,
                f03_hoja, f03_desn, f03_haltd, f03_hmax, f03_dap, f03_regen,
                f03_san, f03_epif, f03_feno, f03_tipocob, f03_obs]) or \
           any(any(r.values()) for r in flora_rows) or \
           any(any(r.values()) for r in esp_rows):
            fichas_sel.append("F-DT-03")
        if any([f04_dir, f04_sub, f04_vel, f04_rev, f04_urg, f04_obs]) or \
           any(r.get("presencia") or r.get("intensidad") or r.get("extension")
               or r.get("antiguedad") or r.get("evidencia") for r in causas_rows) or \
           any(r.get("valor") or r.get("fuente") or r.get("nivel") for r in ind_rows):
            fichas_sel.append("F-DT-04")
        if any([f05_recarga, f05_humedad, f05_escor, f05_distcap, f05_jass,
                f05_inter, f05_riego, f05_modo, f05_via, f05_tvia, f05_tseca,
                f05_tllu, f05_tcap, f05_tprov, f05_senal, f05_oper, f05_aloj,
                f05_ronda, f05_contacto, f05_obs]) or \
           any(any(r.values()) for r in fuente_rows):
            fichas_sel.append("F-DT-05")

        if fichas_sel:
            st.info(f"Fichas con datos: **{', '.join(fichas_sel)}** ({len(fichas_sel)}/5)")

        btn_label_dt = "Actualizar Diagnostico Territorial" if dt_edit_id else "Guardar Diagnostico Territorial"
        if st.button(btn_label_dt, type="primary", key="dt_guardar"):
            if not evaluador:
                st.warning("Ingrese el nombre del evaluador / responsable.")
            elif not fichas_sel:
                st.warning("Complete al menos una ficha de diagnostico.")
            else:
                try:
                    data_v5 = {
                        "ficha": ", ".join(fichas_sel),
                        "fecha_evaluacion": fecha_ev.strftime("%Y-%m-%d"),
                        "evaluador": evaluador,
                        "microcuenca": mc,
                        "brigada": brigada,
                        "ficha_correlativo": correlativo,
                        "altitud_gps": altitud_gps,
                        "centro_poblado_cercano": centro_poblado,
                        "comunidad_campesina_dt": comunidad_campesina,
                        "hora_registro": hora_reg,
                        "utm_este_dt": utm_e_in,
                        "utm_norte_dt": utm_n_in,
                        # F-DT-01
                        "forma_terreno": forma_terreno,
                        "pendiente": pendiente,
                        "posicion_fisiografica": posicion_fisio,
                        "exposicion_orientacion": exposicion,
                        "rango_altitudinal": rango_alt,
                        "paisaje_dominante": paisaje,
                        "dt01_afloramientos_rocosos": f01_aflora,
                        "dt01_escarpes_activos": f01_escarpe,
                        "dt01_reptacion_suelo": f01_reptacion,
                        "dt01_deslizamientos_antiguos": f01_desliz,
                        "dt01_remociones_masa_activas": f01_remocion,
                        "dt01_observaciones": f01_obs,
                        # F-DT-02
                        "dt02_sellamiento_costra": f02_sell,
                        "dt02_compactacion_pisoteo": f02_compa,
                        "dt02_raices_expuestas": f02_raices,
                        "dt02_nivel_erosion_general": f02_nivel,
                        "dt02_carcavas_json": _dt_dump_json(carcavas_rows),
                        "dt02_nivel_erosion_sintesis": f02_sint,
                        "dt02_num_carcavas": f02_num,
                        "dt02_longitud_total_carcavas": f02_long,
                        "dt02_pct_bloque_carcavas": f02_pct,
                        "dt02_erosion_laminar_pct": f02_lam,
                        "dt02_patron_carcavas": f02_pat,
                        "dt02_socavamiento_cauce": f02_soc,
                        "dt02_urgencia_control": f02_urg,
                        "dt02_observaciones": f02_obs,
                        # F-DT-03
                        "dt03_parcela_muestreo": f03_parcela,
                        "dt03_dim_parcela": f03_dim,
                        "dt03_pendiente_parcela": f03_pend,
                        "dt03_cobertura_total": f03_cobtot,
                        "dt03_tipo_ecosistema": f03_eco,
                        "dt03_superficie_ecosistema": f03_supe,
                        "dt03_estado_conservacion_eco": f03_cons,
                        "dt03_uso_dominante": f03_uso,
                        "dt03_cobertura_dosel": f03_dosel,
                        "dt03_cobertura_arbustiva": f03_arbus,
                        "dt03_cobertura_herbacea": f03_herb,
                        "dt03_cobertura_hojarasca": f03_hoja,
                        "dt03_suelo_desnudo": f03_desn,
                        "dt03_altura_estrato_dom": f03_haltd,
                        "dt03_altura_max": f03_hmax,
                        "dt03_dap_promedio": f03_dap,
                        "dt03_regeneracion_natural": f03_regen,
                        "dt03_estado_sanitario": f03_san,
                        "dt03_presencia_epifitas": f03_epif,
                        "dt03_fenologia_dominante": f03_feno,
                        "dt03_tipo_cobertura_dom": f03_tipocob,
                        "dt03_floristica_json": _dt_dump_json(flora_rows),
                        "dt03_especies_clave_json": _dt_dump_json(esp_rows),
                        "dt03_observaciones": f03_obs,
                        # F-DT-04
                        "dt04_causas_json": _dt_dump_json(causas_rows),
                        "dt04_indicadores_json": _dt_dump_json(ind_rows),
                        "dt04_causas_directas_texto": f04_dir,
                        "dt04_causa_subyacente": f04_sub,
                        "dt04_velocidad_degradacion": f04_vel,
                        "dt04_reversibilidad": f04_rev,
                        "dt04_urgencia_intervencion": f04_urg,
                        "dt04_observaciones": f04_obs,
                        # F-DT-05
                        "dt05_fuentes_agua_json": _dt_dump_json(fuente_rows),
                        "dt05_zona_recarga": f05_recarga,
                        "dt05_humedad_persistente": f05_humedad,
                        "dt05_escorrentia_concentrada": f05_escor,
                        "dt05_dist_captacion": f05_distcap,
                        "dt05_jass_captacion": f05_jass,
                        "dt05_interferencia_riego": f05_inter,
                        "dt05_sistema_riego_nombre": f05_riego,
                        "dt05_modalidad_acceso": f05_modo,
                        "dt05_via_principal": f05_via,
                        "dt05_tipo_via_final": f05_tvia,
                        "dt05_transitabilidad_seca": f05_tseca,
                        "dt05_transitabilidad_lluviosa": f05_tllu,
                        "dt05_tiempo_dist_capital": f05_tcap,
                        "dt05_tiempo_prov_capital": f05_tprov,
                        "dt05_senal_celular": f05_senal,
                        "dt05_operador_celular": f05_oper,
                        "dt05_alojamiento": f05_aloj,
                        "dt05_requiere_ronda": f05_ronda,
                        "dt05_contacto_ronda": f05_contacto,
                        "dt05_observaciones": f05_obs,
                        # Comun
                        "observaciones_generales": observ_gen,
                    }
                    if dt_edit_id:
                        db.actualizar_diagnostico_territorial_v5(dt_edit_id, data_v5)
                        _invalidar_cache()
                        st.session_state["dt_edit_id"] = None
                        st.session_state["dt_edit_data"] = None
                        _flash(f"Diagnostico territorial ID {dt_edit_id} actualizado "
                               f"correctamente ({', '.join(fichas_sel)}).")
                    else:
                        existentes = db.obtener_diagnosticos_por_bloque(bid)
                        dup = [e for e in existentes
                               if e.get("fecha_evaluacion") == fecha_ev.strftime("%Y-%m-%d")
                               and e.get("evaluador") == evaluador]
                        if dup:
                            st.markdown(
                                '<div class="dup-warning">Ya existe un diagnostico para este bloque en '
                                f'{fecha_ev.strftime("%Y-%m-%d")} por {evaluador}. '
                                f'Use <b>Editar</b> en Historial para modificarlo.</div>',
                                unsafe_allow_html=True)
                        else:
                            db.insertar_diagnostico_territorial_v5(bid, data_v5)
                            _invalidar_cache()
                            _flash(f"Diagnostico territorial guardado ({', '.join(fichas_sel)}).")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")

    with tab_hist:
        st.markdown("### Historial de Diagnosticos Territoriales")
        st.caption("Haga clic en **Editar** para modificar un diagnostico existente o en **Eliminar** para descartarlo.")
        if st.session_state.get("dt_edit_id"):
            st.info("✏️ Registro cargado en **modo edicion**. Abra la pestaña "
                    "**'Registro de Diagnostico'** (arriba) para corregir los campos y "
                    "pulsar **Actualizar Diagnostico Territorial**.")
        todos_dt = _cached_obtener_todos_diagnosticos(_cache_version())
        if not todos_dt:
            st.info("No hay diagnosticos registrados.")
        else:
            # Generar el consolidado SOLO al pulsar el boton: si se pasa
            # inline a download_button, se regenera en cada rerun de la
            # pagina (Streamlit re-ejecuta todo el script por interaccion)
            # y ese trabajo repetido de pandas/openpyxl agota la memoria
            # del servidor.
            if st.button(
                    "Generar Excel consolidado", key="dt_export_prep", type="secondary",
                    help="Genera un unico archivo Excel con una hoja por ficha (F-DT-01..05) "
                         "y hojas adicionales para las tablas (carcavas, floristica, causas, etc.)."):
                st.session_state["dt_export_bytes"] = exp_diag.exportar_fdt_consolidado(todos_dt)
            if st.session_state.get("dt_export_bytes"):
                st.download_button(
                    "⬇️ Descargar todo (Excel)",
                    data=st.session_state["dt_export_bytes"],
                    file_name=f"Diagnostico_Territorial_FDT_{datetime.now():%Y%m%d}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="dt_export_excel", type="secondary")

            # ── Ficha PDF individual por bloque ────────────────────────
            st.markdown("---")
            st.markdown("#### Ficha PDF individual por bloque")
            st.caption("Genera un PDF con la identificacion del bloque y todas sus "
                       "fichas F-DT-01 a F-DT-05 registradas. La ficha se arma solo "
                       "al pulsar el boton para no recargar el servidor en cada rerun.")
            cods_dt = sorted({(d.get("bloque_codigo", "") or "") for d in todos_dt
                              if d.get("bloque_codigo")})
            if not cods_dt:
                st.info("Aun no hay diagnosticos territoriales asociados a un bloque.")
            else:
                c_dtpdf1, c_dtpdf2 = st.columns([2, 1])
                bl_dt_pdf = c_dtpdf1.selectbox("Bloque", cods_dt, key="dt_pdf_bl")
                if c_dtpdf2.button("Generar ficha PDF", key="dt_pdf_gen", type="primary"):
                    bid_pdf = bm.get(bl_dt_pdf)
                    if not bid_pdf:
                        st.error(f"El bloque {bl_dt_pdf} ya no existe en la base de datos.")
                    else:
                        try:
                            nombre_pdf, bytes_pdf = reports.generar_ficha_dt_bloque_pdf(bid_pdf)
                            st.session_state["dt_pdf_bytes"] = bytes_pdf
                            st.session_state["dt_pdf_nombre"] = nombre_pdf
                            st.session_state["dt_pdf_bloque"] = bl_dt_pdf
                        except Exception as e:
                            st.error(f"No se pudo generar la ficha PDF: {e}")
                # Solo se ofrece la descarga si corresponde al bloque seleccionado,
                # para no entregar un PDF de un bloque distinto al elegido.
                if (st.session_state.get("dt_pdf_bytes")
                        and st.session_state.get("dt_pdf_bloque") == bl_dt_pdf):
                    st.download_button(
                        f"⬇️ Descargar ficha DT del bloque {bl_dt_pdf} (PDF)",
                        data=st.session_state["dt_pdf_bytes"],
                        file_name=st.session_state["dt_pdf_nombre"],
                        mime="application/pdf", key="dt_pdf_dl")
            st.markdown("---")

            dt_pag, total_pags_dt, pag_actual_dt = _paginar(todos_dt, "pag_dt")
            _controles_paginacion(total_pags_dt, pag_actual_dt, "pag_dt")
            col_widths_dt = [0.4, 1, 0.8, 0.8, 0.8, 0.8, 0.8, 0.5, 0.6]
            header_cols = st.columns(col_widths_dt)
            for col, h in zip(header_cols,
                              ["ID", "Bloque", "Fichas", "Fecha", "Evaluador",
                               "Microcuenca", "Distrito", "", ""]):
                col.markdown(f"**{h}**")
            st.markdown("---")
            confirm_del_dt_id = st.session_state.get("dt_confirm_del_id")
            for d in dt_pag:
                row = st.columns(col_widths_dt)
                row[0].write(d["id"])
                row[1].write(d.get("bloque_codigo", ""))
                row[2].write(d.get("ficha", ""))
                row[3].write(d.get("fecha_evaluacion", ""))
                row[4].write(d.get("evaluador", ""))
                row[5].write(d.get("microcuenca", "") or "")
                row[6].write(d.get("distrito", ""))
                if row[7].button("Editar", key=f"edit_dt_{d['id']}", type="primary"):
                    det = db.obtener_diagnostico_por_id(d["id"])
                    if det:
                        # Limpiar los widgets para que la precarga (value=/index=)
                        # del registro a editar surta efecto.
                        _dt_limpiar_widgets_edicion()
                        st.session_state["dt_edit_id"] = det["id"]
                        st.session_state["dt_edit_data"] = det
                        # Posicionar el selector de bloque en el bloque del registro.
                        cod = det.get("bloque_codigo", "")
                        label_bl = buscar_label_bloque(cod, bm)
                        if label_bl:
                            st.session_state["dt_bl"] = label_bl
                    st.session_state.pop("dt_confirm_del_id", None)
                    st.rerun()
                if confirm_del_dt_id == d["id"]:
                    if row[8].button("Confirmar", key=f"del_confirm_dt_{d['id']}", type="primary"):
                        db.eliminar_diagnostico(d["id"])
                        _invalidar_cache()
                        st.session_state.pop("dt_confirm_del_id", None)
                        st.success(f"Diagnostico territorial ID {d['id']} eliminado.")
                        st.rerun()
                else:
                    if row[8].button("Eliminar", key=f"del_dt_{d['id']}", type="secondary"):
                        st.session_state["dt_confirm_del_id"] = d["id"]
                        st.rerun()
            if confirm_del_dt_id is not None:
                st.warning(f"Confirme la eliminacion del diagnostico ID {confirm_del_dt_id} pulsando 'Confirmar' en su fila. "
                           "Esta accion no puede deshacerse.")
                if st.button("Cancelar eliminacion", key="dt_cancel_del"):
                    st.session_state.pop("dt_confirm_del_id", None)
                    st.rerun()

            st.markdown("---")
            st.markdown("### Detalle de Diagnostico")
            dm = {f"ID {d['id']} - {d.get('bloque_codigo','')} ({d.get('ficha','')})": d["id"]
                  for d in todos_dt}
            sel_dt = st.selectbox("Seleccionar diagnostico", [""] + list(dm.keys()), key="dt_det")
            if sel_dt and sel_dt in dm:
                det = db.obtener_diagnostico_por_id(dm[sel_dt])
                if det:
                    st.markdown(f"**Bloque:** {det.get('bloque_codigo','')} | "
                                f"**Fecha:** {det.get('fecha_evaluacion','')} | "
                                f"**Evaluador:** {det.get('evaluador','')}")
                    fichas_str = det.get("ficha", "")

                    if "F-DT-01" in fichas_str:
                        with st.expander("F-DT-01: Datos generales y fisiografía", expanded=True):
                            c1, c2 = st.columns(2)
                            c1.markdown(f"**Forma terreno:** {det.get('forma_terreno','') or '-'}")
                            c2.markdown(f"**Pendiente:** {det.get('pendiente','') or '-'}")
                            c1.markdown(f"**Posición fisio.:** {det.get('posicion_fisiografica','') or '-'}")
                            c2.markdown(f"**Exposición:** {det.get('exposicion_orientacion','') or '-'}")
                            c1.markdown(f"**Altitud:** {det.get('rango_altitudinal','') or '-'}")
                            c2.markdown(f"**Paisaje:** {det.get('paisaje_dominante','') or '-'}")
                            c1.markdown(f"**Afloramientos rocosos:** {det.get('dt01_afloramientos_rocosos','') or '-'}")
                            c2.markdown(f"**Escarpes activos:** {det.get('dt01_escarpes_activos','') or '-'}")
                            c1.markdown(f"**Reptación suelo:** {det.get('dt01_reptacion_suelo','') or '-'}")
                            c2.markdown(f"**Deslizamientos antiguos:** {det.get('dt01_deslizamientos_antiguos','') or '-'}")
                            st.markdown(f"**Remociones masa activas:** {det.get('dt01_remociones_masa_activas','') or '-'}")
                            if det.get("dt01_observaciones"):
                                st.markdown(f"**Obs:** {det['dt01_observaciones']}")

                    if "F-DT-02" in fichas_str:
                        with st.expander("F-DT-02: Suelo y procesos erosivos", expanded=True):
                            c1, c2 = st.columns(2)
                            c1.markdown(f"**Sellamiento/costra:** {det.get('dt02_sellamiento_costra','') or '-'}")
                            c2.markdown(f"**Compactación:** {det.get('dt02_compactacion_pisoteo','') or '-'}")
                            c1.markdown(f"**Raíces expuestas:** {det.get('dt02_raices_expuestas','') or '-'}")
                            c2.markdown(f"**Nivel erosión:** {det.get('dt02_nivel_erosion_general','') or '-'}")
                            cars = _dt_load_json(det.get("dt02_carcavas_json", ""), [])
                            if cars:
                                st.markdown(f"**Cárcavas registradas:** {len(cars)}")
                                st.dataframe(pd.DataFrame(cars), use_container_width=True, hide_index=True)
                            c1.markdown(f"**Nivel erosión (síntesis):** {det.get('dt02_nivel_erosion_sintesis','') or '-'}")
                            c2.markdown(f"**N° cárcavas:** {det.get('dt02_num_carcavas','') or '-'}")
                            c1.markdown(f"**Longitud total (m):** {det.get('dt02_longitud_total_carcavas','') or '-'}")
                            c2.markdown(f"**% bloque afectado:** {det.get('dt02_pct_bloque_carcavas','') or '-'}")
                            c1.markdown(f"**Patrón cárcavas:** {det.get('dt02_patron_carcavas','') or '-'}")
                            c2.markdown(f"**Urgencia control:** {det.get('dt02_urgencia_control','') or '-'}")
                            if det.get("dt02_observaciones"):
                                st.markdown(f"**Obs:** {det['dt02_observaciones']}")

                    if "F-DT-03" in fichas_str:
                        with st.expander("F-DT-03: Ecosistema", expanded=True):
                            c1, c2 = st.columns(2)
                            c1.markdown(f"**Tipo ecosistema:** {det.get('dt03_tipo_ecosistema','') or '-'}")
                            c2.markdown(f"**Estado conservación:** {det.get('dt03_estado_conservacion_eco','') or '-'}")
                            c1.markdown(f"**Uso dominante:** {det.get('dt03_uso_dominante','') or '-'}")
                            c2.markdown(f"**Cobertura total (%):** {det.get('dt03_cobertura_total','') or '-'}")
                            c1.markdown(f"**Tipo cobertura dom.:** {det.get('dt03_tipo_cobertura_dom','') or '-'}")
                            c2.markdown(f"**Regeneración:** {det.get('dt03_regeneracion_natural','') or '-'}")
                            flora = _dt_load_json(det.get("dt03_floristica_json", ""), [])
                            if flora:
                                st.markdown(f"**Especies registradas:** {len(flora)}")
                                st.dataframe(pd.DataFrame(flora), use_container_width=True, hide_index=True)
                            esp = _dt_load_json(det.get("dt03_especies_clave_json", ""), [])
                            if esp:
                                st.markdown(f"**Especies clave/indicadoras:** {len(esp)}")
                                st.dataframe(pd.DataFrame(esp), use_container_width=True, hide_index=True)
                            if det.get("dt03_observaciones"):
                                st.markdown(f"**Obs:** {det['dt03_observaciones']}")

                    if "F-DT-04" in fichas_str:
                        with st.expander("F-DT-04: Causas e indicadores de degradación", expanded=True):
                            causas = _dt_load_json(det.get("dt04_causas_json", ""), [])
                            if causas:
                                st.markdown("**Matriz de causas**")
                                st.dataframe(pd.DataFrame(causas), use_container_width=True, hide_index=True)
                            inds = _dt_load_json(det.get("dt04_indicadores_json", ""), [])
                            if inds:
                                st.markdown("**Indicadores cuantitativos**")
                                st.dataframe(pd.DataFrame(inds), use_container_width=True, hide_index=True)
                            c1, c2 = st.columns(2)
                            c1.markdown(f"**Causa subyacente:** {det.get('dt04_causa_subyacente','') or '-'}")
                            c2.markdown(f"**Velocidad degradación:** {det.get('dt04_velocidad_degradacion','') or '-'}")
                            c1.markdown(f"**Reversibilidad:** {det.get('dt04_reversibilidad','') or '-'}")
                            c2.markdown(f"**Urgencia intervención:** {det.get('dt04_urgencia_intervencion','') or '-'}")
                            if det.get("dt04_causas_directas_texto"):
                                st.markdown(f"**Causas directas:** {det['dt04_causas_directas_texto']}")
                            if det.get("dt04_observaciones"):
                                st.markdown(f"**Obs:** {det['dt04_observaciones']}")

                    if "F-DT-05" in fichas_str:
                        with st.expander("F-DT-05: Recursos hídricos y accesibilidad", expanded=True):
                            fts = _dt_load_json(det.get("dt05_fuentes_agua_json", ""), [])
                            if fts:
                                st.markdown(f"**Fuentes de agua registradas:** {len(fts)}")
                                st.dataframe(pd.DataFrame(fts), use_container_width=True, hide_index=True)
                            c1, c2 = st.columns(2)
                            c1.markdown(f"**Zona de recarga:** {det.get('dt05_zona_recarga','') or '-'}")
                            c2.markdown(f"**Humedad persistente:** {det.get('dt05_humedad_persistente','') or '-'}")
                            c1.markdown(f"**Modalidad acceso:** {det.get('dt05_modalidad_acceso','') or '-'}")
                            c2.markdown(f"**Vía principal:** {det.get('dt05_via_principal','') or '-'}")
                            c1.markdown(f"**Transit. seca:** {det.get('dt05_transitabilidad_seca','') or '-'}")
                            c2.markdown(f"**Transit. lluviosa:** {det.get('dt05_transitabilidad_lluviosa','') or '-'}")
                            c1.markdown(f"**Señal celular:** {det.get('dt05_senal_celular','') or '-'}")
                            c2.markdown(f"**Operador:** {det.get('dt05_operador_celular','') or '-'}")
                            c1.markdown(f"**Requiere autoriz. Ronda:** {det.get('dt05_requiere_ronda','') or '-'}")
                            c2.markdown(f"**Contacto Ronda:** {det.get('dt05_contacto_ronda','') or '-'}")
                            if det.get("dt05_observaciones"):
                                st.markdown(f"**Obs:** {det['dt05_observaciones']}")

                    if det.get("observaciones_generales"):
                        st.markdown(f"**Observaciones generales:** {det['observaciones_generales']}")

                    if st.button("Eliminar este diagnostico", key="dt_eliminar"):
                        db.eliminar_diagnostico(dm[sel_dt])
                        _invalidar_cache()
                        st.success("Diagnostico eliminado.")
                        st.rerun()

            st.markdown("---")
            st.markdown("### Resumen por Bloque")
            resumen = db.obtener_resumen_diagnosticos()
            if resumen:
                st.dataframe(pd.DataFrame([{
                    "Bloque": r["codigo"],
                    "Tipo": r["tipo_intervencion"],
                    "Distrito": r["distrito"],
                    "Total Fichas": r["total_fichas"],
                    "Fichas Completadas": r.get("fichas_completadas", "") or "Ninguna",
                } for r in resumen]), use_container_width=True, hide_index=True)

    # ══════════════════════════════════════════════════════════════════
    # TAB IMPORTAR DESDE EXCEL
    # ══════════════════════════════════════════════════════════════════
    with tab_excel:
        st.markdown("### Importar Diagnostico Territorial desde Excel")
        st.caption("Genere la plantilla V5 y suba el archivo llenado por el técnico.")

        st.markdown("---")
        st.markdown("**1. Descargar Plantilla V5 para Tecnicos**")
        col_dl1, col_dl2 = st.columns(2)
        fichas_descarga_dt = col_dl1.multiselect(
            "Fichas a incluir en la plantilla",
            FICHAS_DT, default=FICHAS_DT, key="dt_excel_fichas_dl")
        if col_dl2.button("Generar Plantilla V5", type="secondary", key="dt_gen_plantilla"):
            if fichas_descarga_dt:
                bloques_data_dt = [
                    (b[1], b[2], b[4], b[5], b[3], b[8], b[9],
                     (b[11] if len(b) > 11 else ""))
                    for b in BLOQUES_V5
                ]
                plantilla_bytes_dt = generar_plantilla_dt(fichas_descarga_dt, bloques_data_dt)
                st.session_state["dt_plantilla_bytes"] = plantilla_bytes_dt
                st.success("Plantilla V5 generada correctamente.")

        if st.session_state.get("dt_plantilla_bytes"):
            st.download_button(
                "Descargar Plantilla V5 (.xlsx)",
                st.session_state["dt_plantilla_bytes"],
                file_name="Plantilla_DT_Campo_Check_Validada_V5.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="dt_dl_plantilla")

        st.markdown("---")
        st.markdown("**2. Subir Excel V5 Llenado**")
        st.info("Al cargar el archivo, el sistema leera los datos y autocompletara "
                "el formulario en la pestana **Registro de Diagnostico**. Podra revisar "
                "y ajustar antes de guardar.")
        st.caption("Importador Excel V5 — rev. 2")

        uploaded_excel_dt = st.file_uploader(
            "Seleccionar archivo Excel (.xlsx, max. 25 MB)",
            type=["xlsx"], key="dt_excel_upload")

        if uploaded_excel_dt is not None and uploaded_excel_dt.size > 25 * 1024 * 1024:
            st.error(f"El archivo '{uploaded_excel_dt.name}' pesa "
                     f"{uploaded_excel_dt.size / (1024 * 1024):.1f} MB y excede el "
                     "limite de 25 MB. Guarde una copia sin imagenes/hojas extra "
                     "e intente de nuevo.")
            uploaded_excel_dt = None

        if uploaded_excel_dt is not None:
            try:
                # Cachear el parseo por archivo: Streamlit re-ejecuta el
                # script en cada interaccion mientras el archivo siga en el
                # uploader, y re-parsear cada vez es trabajo repetido.
                _dt_x_key = (uploaded_excel_dt.name, uploaded_excel_dt.size)
                if st.session_state.get("_dt_excel_cache_key") == _dt_x_key:
                    resultados_dt = st.session_state["_dt_excel_cache_val"]
                else:
                    resultados_dt = parsear_excel_dt(uploaded_excel_dt)
                    st.session_state["_dt_excel_cache_key"] = _dt_x_key
                    st.session_state["_dt_excel_cache_val"] = resultados_dt
                if not resultados_dt:
                    st.error("No se pudieron detectar fichas V5 en el archivo.")
                else:
                    st.success(f"Se detectaron {len(resultados_dt)} ficha(s) en el archivo.")
                    fichas_detectadas = [r["ficha"] for r in resultados_dt]
                    datos_todos = {}
                    for r in resultados_dt:
                        datos_todos.update(r["datos"])

                    with st.expander("Vista previa de datos detectados", expanded=True):
                        c1, c2, c3 = st.columns(3)
                        c1.markdown(f"**Fecha:** {datos_todos.get('fecha_evaluacion', '-')}")
                        c2.markdown(f"**Evaluador:** {datos_todos.get('evaluador', '-')}")
                        c3.markdown(f"**Bloque:** {datos_todos.get('codigo_bloque', '-')}")
                        st.markdown(f"**Fichas detectadas:** {', '.join(fichas_detectadas)}")
                        campos_pob = sum(1 for v in datos_todos.values() if v)
                        st.markdown(f"**Campos con datos:** {campos_pob}")

                    if st.button("Autocompletar formulario", type="primary", key="dt_autocompletar"):
                        ss_vals = mapear_dt_a_session_state(
                            {"ficha": ", ".join(fichas_detectadas), "datos": datos_todos}, bm)
                        st.session_state["_dt_autocompletar_pending"] = ss_vals
                        st.success(
                            f"Formulario autocompletado con {len(fichas_detectadas)} ficha(s). "
                            "Cambie a la pestaña **Registro de Diagnostico** para revisar y guardar.")
                        st.rerun()
            except Exception as e:
                st.error(f"Error al leer el archivo Excel: {e}")

    # ══════════════════════════════════════════════════════════════════
    # TAB RESUMENES EXCEL POR BLOQUE (117 libros)
    # ══════════════════════════════════════════════════════════════════
    with tab_resumen:
        _tab_resumenes_bloques(bm)

# ══════════════════════════════════════════════════════════════════════════
# DIAGNOSTICO SOCIAL
# ══════════════════════════════════════════════════════════════════════════
def _tabla_demografia_cp(cp_info):
    """DataFrame con la demografia INEI de los centros poblados de un bloque.
    Devuelve None si el catalogo no trae detalle para ese bloque."""
    detalle = (cp_info or {}).get("demografia", [])
    if not detalle:
        return None
    return pd.DataFrame([{
        "N": i,
        "Centro Poblado": d.get("centro_poblado", ""),
        "Poblacion": d.get("poblacion_total", 0),
        "Hombres": d.get("hombres", 0),
        "Mujeres": d.get("mujeres", 0),
        "Pob. vulnerable": d.get("poblacion_vulnerable", 0),
        "Viviendas": d.get("viviendas", 0),
        "Tipo": d.get("tipo", ""),
    } for i, d in enumerate(detalle, 1)])


def _ds_datos_generales(bloque_label=""):
    """Campos de datos generales compartidos por todas las fichas DS.
    Auto-vincula centros poblados, comunidades campesinas, provincia,
    distrito y coordenadas aproximadas del bloque seleccionado."""
    codigo_bloque = bloque_label.split(" - ")[0].strip() if " - " in bloque_label else bloque_label.strip()
    bloque_info = BLOQUES_128_MAP.get(codigo_bloque, {})
    cp_info = _cp_bloque(codigo_bloque)
    lista_cp = cp_info.get("centros_poblados", [])
    lista_cc = cp_info.get("comunidades_campesinas", [])
    pob_total = cp_info.get("poblacion_total", 0)

    # ── Vinculacion automatica de centros poblados ──
    if lista_cp:
        n_cp = len(lista_cp)
        n_cc = len(lista_cc)
        resumen = f"**{n_cp}** centro(s) poblado(s)"
        if lista_cc:
            resumen += f" y **{n_cc}** comunidad(es) campesina(s)"
        resumen += f" vinculado(s) al bloque **{codigo_bloque}**"
        if pob_total:
            resumen += (f" | Poblacion: **{pob_total:,}** hab. "
                        f"({cp_info.get('hombres', 0):,} H / {cp_info.get('mujeres', 0):,} M) "
                        f"| Viviendas: **{cp_info.get('viviendas', 0):,}**")
        st.info(resumen)

        # Detalle demografico INEI por centro poblado.
        with st.expander(f"Ver {n_cp} centro(s) poblado(s) del bloque {codigo_bloque} "
                         "y su demografia", expanded=False):
            df_demo = _tabla_demografia_cp(cp_info)
            if df_demo is not None:
                st.dataframe(df_demo, use_container_width=True, hide_index=True)
                st.caption("Fuente: INEI. La poblacion corresponde a los centros "
                           "poblados asociados al bloque, no a la poblacion "
                           "residente dentro del poligono.")
            else:
                st.dataframe(pd.DataFrame({"N": range(1, n_cp + 1),
                                           "Centro Poblado": lista_cp}),
                             use_container_width=True, hide_index=True)
            if lista_cc:
                st.markdown(f"**Comunidades campesinas:** {', '.join(lista_cc)}")

    # ── Auto-resolver provincia y distrito del bloque ──
    prov_auto = bloque_info.get("provincia", "")
    dist_auto = bloque_info.get("distrito", "")
    utm_este_auto = float(bloque_info.get("utm_este", 0))
    utm_norte_auto = float(bloque_info.get("utm_norte", 0))

    # Pre-poblar session_state con valores del bloque si estan vacios
    if "ds_prov" not in st.session_state and prov_auto:
        st.session_state["ds_prov"] = prov_auto
    if "ds_dist" not in st.session_state and dist_auto:
        st.session_state["ds_dist"] = dist_auto
    if "ds_cpob" not in st.session_state and lista_cp:
        st.session_state["ds_cpob"] = " / ".join(lista_cp)
    if "ds_ccam" not in st.session_state and lista_cc:
        st.session_state["ds_ccam"] = " / ".join(lista_cc)
    if "ds_este" not in st.session_state and utm_este_auto:
        st.session_state["ds_este"] = utm_este_auto
    if "ds_norte" not in st.session_state and utm_norte_auto:
        st.session_state["ds_norte"] = utm_norte_auto

    c1, c2, c3, c4 = st.columns(4)
    prov = c1.text_input("Provincia", key="ds_prov")
    dist = c2.text_input("Distrito", key="ds_dist")

    # Selector de centro poblado cuando hay multiples opciones
    if len(lista_cp) > 1:
        opciones_cp = [" / ".join(lista_cp)] + lista_cp
        # Asegurar que el valor en session_state sea valido para el selectbox
        val_cpob = st.session_state.get("ds_cpob", "")
        if val_cpob and val_cpob not in opciones_cp:
            st.session_state["ds_cpob"] = opciones_cp[0]
        cpob = c3.selectbox("Centro Poblado / Localidad", opciones_cp,
                            key="ds_cpob",
                            help="Seleccione un centro poblado especifico o todos los asociados al bloque")
    else:
        cpob = c3.text_input("Centro Poblado / Localidad", key="ds_cpob")

    if len(lista_cc) > 1:
        opciones_cc = [" / ".join(lista_cc)] + lista_cc
        val_ccam = st.session_state.get("ds_ccam", "")
        if val_ccam and val_ccam not in opciones_cc:
            st.session_state["ds_ccam"] = opciones_cc[0]
        ccam = c4.selectbox("Comunidad Campesina", opciones_cc,
                            key="ds_ccam",
                            help="Seleccione una comunidad campesina especifica o todas las asociadas")
    else:
        ccam = c4.text_input("Comunidad Campesina", key="ds_ccam")

    # ── Coordenadas: usar centroide del bloque como aproximacion ──
    c5, c6, c7, c8 = st.columns(4)
    este = c5.number_input("Coordenada Este (UTM)", format="%.1f", key="ds_este",
                           help="Coordenada UTM Este (Zona 17S). Auto-completada con centroide del bloque.")
    norte = c6.number_input("Coordenada Norte (UTM)", format="%.1f", key="ds_norte",
                            help="Coordenada UTM Norte (Zona 17S). Auto-completada con centroide del bloque.")
    alt_v = c7.number_input("Altitud (msnm)", value=0.0, format="%.0f", key="ds_alt")
    ubigeo = c8.text_input("Codigo UBIGEO", key="ds_ubigeo")

    if utm_este_auto and utm_norte_auto and (este == utm_este_auto and norte == utm_norte_auto):
        st.caption("📍 Coordenadas aproximadas (centroide del bloque). Ajuste manualmente si dispone de la ubicacion exacta del centro poblado.")

    # ── Datos del entrevistado (Datos Generales y Localizacion del Excel) ──
    st.markdown("**Datos del entrevistado**")
    e1, e2, e3 = st.columns([2, 1, 1.5])
    nombre_entrev = e1.text_input(
        "Nombres y apellidos del entrevistado", key="ds_entrev_nombre",
        help="Persona entrevistada al momento de llenar la ficha.")
    dni_entrev = e2.text_input(
        "DNI", key="ds_entrev_dni", max_chars=8,
        help="Documento Nacional de Identidad del entrevistado.")
    oficio_entrev = e3.text_input(
        "Oficio / ocupacion", key="ds_entrev_oficio")

    return dict(provincia=prov, distrito=dist, centro_poblado=cpob,
                comunidad_campesina=ccam, coordenada_este=este,
                coordenada_norte=norte, altitud=alt_v, codigo_ubigeo=ubigeo,
                nombre_entrevistado=nombre_entrev, dni_entrevistado=dni_entrev,
                oficio_ocupacion=oficio_entrev)


# ══════════════════════════════════════════════════════════════════════════
# DIAGNOSTICO SOCIAL V3 — Plantilla validada (F-DS-01 a F-DS-07)
# Formularios con celdas de validacion (desplegables) que replican las listas
# oficiales del Excel `Plantilla_Diagnostico_Social_IN_Piura_V4`.
# Cada ficha guarda su formulario completo como JSON en la columna dsNN_data_v3
# y, donde aplica, alimenta las columnas legacy para compatibilidad de reportes.
# Convencion: la clave del dict del formulario == la key del widget Streamlit,
# por lo que la precarga (edicion / import) es generica y sin desfases.
# ══════════════════════════════════════════════════════════════════════════

# Slots que corresponden a tablas (st.data_editor) y no a widgets escalares.
_DS_TABLE_SLOTS = {
    "f1_activ", "f2_actores", "f4_part", "f4_agenda", "f4_acuerdos",
    "f5_conflictos", "f5_oportunidades", "f6_peligros", "f6_cambios",
}


def _ds_nonce():
    return st.session_state.get("_ds_nonce", 0)


def _T(f, container, label, key, **kw):
    f[key] = container.text_input(label, key=key, **kw)
    return f[key]


def _TA(f, label, key, height=80, **kw):
    f[key] = st.text_area(label, key=key, height=height, **kw)
    return f[key]


def _SB(f, container, label, options, key, help=None):
    """Selectbox 'marcar uno' (celda de validacion)."""
    opts = [""] + list(options)
    if key in st.session_state and st.session_state[key] not in opts:
        st.session_state[key] = ""
    f[key] = container.selectbox(label, opts, key=key, help=help)
    return f[key]


def _MS(f, container, label, options, key, help=None):
    """Multiselect 'marcar las que apliquen' (celda de validacion)."""
    opts = list(options)
    if key in st.session_state:
        cur = st.session_state[key]
        # Compatibilidad con registros antiguos guardados como escalar (str)
        if isinstance(cur, str):
            cur = [cur] if cur else []
        elif isinstance(cur, (tuple, set)):
            cur = list(cur)
        elif not isinstance(cur, list):
            cur = []
        st.session_state[key] = [v for v in cur if v in opts]
    f[key] = container.multiselect(label, opts, key=key, help=help)
    return f[key]


def _ds_tabla(label, slot, columns, default_rows=None, default_n=3, help=None):
    """Editor de tabla con celdas de validacion por columna (st.data_editor)."""
    if label:
        st.markdown(label)
    if help:
        st.caption(help)
    col_names = [c[0] for c in columns]
    init = st.session_state.get(f"_dsinit_{slot}")
    if init is None:
        if default_rows is not None:
            init = [dict(r) for r in default_rows]
        else:
            init = [{c: "" for c in col_names} for _ in range(default_n)]
    rows = [{c: r.get(c, "") for c in col_names} for r in init]
    df = pd.DataFrame(rows, columns=col_names)
    colcfg = {}
    for name, kind, opts in columns:
        if kind == "select":
            colcfg[name] = st.column_config.SelectboxColumn(name, options=list(opts), width="medium")
        else:
            colcfg[name] = st.column_config.TextColumn(name)
    edited = st.data_editor(
        df, key=f"_dstbl_{slot}_{_ds_nonce()}", column_config=colcfg,
        num_rows="dynamic", use_container_width=True, hide_index=True)
    out = []
    for r in edited.to_dict("records"):
        if any(str(v).strip() for v in r.values() if v is not None):
            out.append({k: ("" if v is None else str(v)) for k, v in r.items()})
    return out


def _TB(f, label, slot, columns, **kw):
    f[slot] = _ds_tabla(label, slot, columns, **kw)
    return f[slot]


# ─── Render de cada ficha: devuelven el dict completo del formulario V3 ──────

def _render_fds01():
    f = {}
    st.markdown("**2. Datos Demograficos**")
    _SB(f, st, "2.1 Tipo de organizacion territorial", FL.L_ORG_COMUNAL, "f1_org_terr")
    c1, c2 = st.columns(2)
    _T(f, c1, "Nombre oficial completo (CP/CC/Anexo)", "f1_nombre_oficial")
    _T(f, c2, "Año de fundacion", "f1_anio_fund")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "N total de familias / viviendas *", "f1_nfam")
    _T(f, c2, "Poblacion total estimada (hab.) *", "f1_pob_t")
    _T(f, c3, "Pob. autoidentificada originaria", "f1_pob_orig")
    c1, c2, c3, c4 = st.columns(4)
    _T(f, c1, "Pob. hombres", "f1_pob_h")
    _T(f, c2, "Pob. mujeres", "f1_pob_m")
    _T(f, c3, "Pob. < 18 años", "f1_pob_men18")
    _T(f, c4, "Pob. > 65 años", "f1_pob_may65")
    c1, c2 = st.columns(2)
    _SB(f, c1, "2.3 Idioma predominante", FL.L_IDIOMA, "f1_idioma")
    _SB(f, c2, "2.4 Nivel educativo predominante", FL.L_NIV_EDU, "f1_nivel_edu")
    c1, c2 = st.columns(2)
    _SB(f, c1, "2.5 Tasa de migracion juvenil", FL.L_ABC, "f1_migracion")
    _SB(f, c2, "2.6 Destino principal de migracion", FL.L_MIG_DEST, "f1_destino_mig")

    st.markdown("**3. Organizacion Comunal y Gobernanza Local**")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿Junta Directiva vigente?", DS_SINO, "f1_junta_vig")
    _T(f, c2, "Fin de mandato (AAAA)", "f1_junta_fin")
    _SB(f, c3, "3.1 Periodicidad de asambleas", FL.L_PERIODIC, "f1_periodicidad")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Presidente/a de Junta", "f1_pres_junta")
    _T(f, c2, "DNI", "f1_pres_dni")
    _T(f, c3, "Telefono", "f1_pres_tel")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿Ronda Campesina activa? *", DS_SINO, "f1_ronda")
    _T(f, c2, "Presidente/a de Ronda", "f1_pres_ronda")
    _T(f, c3, "Telefono Pres. Ronda", "f1_ronda_tel")
    _T(f, st, "Autoridad adicional (Tnte Gobernador, Agente Municipal)", "f1_aut_adic")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿Existe reglamento interno?", DS_SINONA, "f1_reglamento")
    _SB(f, c2, "¿Comite de RRNN?", DS_SINO, "f1_comite_rrnn")
    _T(f, c3, "Nombre del comite (si existe)", "f1_nombre_comite")

    st.markdown("**4. Tenencia de la Tierra**")
    _SB(f, st, "4.1 Regimen predominante de tenencia", FL.L_TENENCIA, "f1_tenencia")
    c1, c2 = st.columns(2)
    _T(f, c1, "N aprox. de predios individuales", "f1_n_predios")
    _T(f, c2, "% tierras tituladas", "f1_pct_tituladas")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Conflictos de linderos registrados?", DS_SINO, "f1_conf_linderos")
    _SB(f, c2, "¿Bloque se superpone a tierras comunales?", DS_SINO, "f1_superpone")
    _SB(f, st, "4.2 Organismo responsable del registro", FL.L_REG_TIT, "f1_reg_titulacion")

    st.markdown("**5. Servicios Basicos e Infraestructura Social**")
    c1, c2, c3, c4 = st.columns(4)
    _MS(f, c1, "5.1 Agua para consumo", FL.L_AGUA, "f1_agua",
        help="Marque todas las fuentes que apliquen (la poblacion puede usar mas de una).")
    _T(f, c2, "Cobertura agua (%)", "f1_agua_cob")
    _T(f, c3, "Pago mensual S/", "f1_agua_pago")
    _T(f, c4, "Tiempo acarreo / viajes", "f1_agua_acarreo")
    c1, c2 = st.columns(2)
    _MS(f, c1, "5.2 Saneamiento", FL.L_SANEA, "f1_sanea",
        help="Marque todos los tipos que apliquen (p. ej. una parte usa letrina seca y otra pozo septico).")
    _MS(f, c2, "5.3 Energia electrica", FL.L_ENERG, "f1_energia",
        help="Marque todas las fuentes que apliquen (la poblacion puede usar mas de una).")
    c1, c2 = st.columns(2)
    _T(f, c1, "Cobertura energia (%)", "f1_energia_cob")
    _T(f, c2, "Pago mensual energia S/", "f1_energia_pago")
    c1, c2 = st.columns(2)
    _SB(f, c1, "5.4 Telecomunicaciones", FL.L_TELECOM, "f1_telecom")
    _T(f, c2, "Operador celular dominante", "f1_telecom_op")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "5.5 IE - niveles disponibles", FL.L_NIV_EDU_IE, "f1_ie_niveles")
    _T(f, c2, "Nombre IE principal", "f1_ie_nombre")
    _T(f, c3, "Distancia al CP (Km)", "f1_ie_dist")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "5.6 EESS - categoria", FL.L_CAT_EESS, "f1_eess")
    _T(f, c2, "Nombre EESS mas cercano", "f1_eess_nombre")
    _T(f, c3, "Distancia EESS (km)", "f1_eess_dist")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Existe local comunal?", DS_SINO, "f1_local_comunal")
    _SB(f, c2, "Estado del local comunal", FL.L_BRM, "f1_local_estado")

    _TB(f, "**6. Actividades Economicas y Medios de Vida**", "f1_activ",
        [("Actividad / Rubro", "select", FL.L_ACTIV),
         ("N fam.", "text", None),
         ("Productos principales", "text", None),
         ("Destino", "select", FL.L_DESTINO),
         ("Ingreso (S/./mes)", "text", None)],
        default_n=3,
        help="Registre hasta 8 actividades. Elija la actividad y el destino del desplegable.")

    st.markdown("**7. Programas Sociales y Presencia Institucional**")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Beneficiarios JUNTOS (N fam.)", "f1_juntos")
    _T(f, c2, "Pension 65 (N pers.)", "f1_pension65")
    _T(f, c3, "Qali Warma (IIEE)", "f1_qaliwarma")
    c1, c2 = st.columns(2)
    _T(f, c1, "Beca 18 (N pers.)", "f1_beca18")
    _T(f, c2, "Otros programas (especificar)", "f1_otros_prog")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿Proyectos AGRORURAL?", DS_SINO, "f1_agrorural")
    _SB(f, c2, "¿PRODERN / FONCODES?", DS_SINO, "f1_prodern")
    _SB(f, c3, "¿Otros proyectos?", DS_SINO, "f1_otros_proy")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿PDC vigente?", DS_SINO, "f1_pdc")
    _SB(f, c2, "¿ONGs operando?", DS_SINO, "f1_ongs")
    _T(f, c3, "Nombre de ONGs", "f1_nombre_ongs")
    _SB(f, st, "7.1 Percepcion de presencia estatal", FL.L_ABC, "f1_presencia_estatal")
    return f


def _render_fds02():
    f = {}
    st.info("TIPO de actor, Influencia, Interes, Posicion y Nivel territorial se eligen "
            "de los desplegables (valores completos). Ver hoja _Codigos del Excel para la leyenda.")
    _TB(f, "**3. Registro de Actores Identificados**", "f2_actores",
        [("Nombre del actor / Organizacion", "text", None),
         ("Tipo", "select", FL.L_TIPO_ACTOR),
         ("Rol / Funcion frente al proyecto", "text", None),
         ("Influencia", "select", FL.L_ABC),
         ("Interes", "select", FL.L_ABC),
         ("Posicion", "select", FL.L_POSICION),
         ("Nivel territorial", "select", FL.L_NIV_TERR),
         ("Telefono", "text", None),
         ("Correo / Contacto", "text", None),
         ("Observaciones / Historial", "text", None)],
        default_n=5,
        help="Registre todos los actores relevantes para la zona del bloque.")
    st.markdown("**5. Actores Criticos Prioritarios (sintesis)**")
    _T(f, st, "Actor mas influyente a favor", "f2_favor")
    _T(f, st, "Actor mas influyente en contra / reticente", "f2_contra")
    _T(f, st, "Actor clave en decisiones comunales", "f2_decision")
    _T(f, st, "Actor clave para coordinar acceso (Ronda)", "f2_ronda")
    _T(f, st, "Plataforma / Mesa existente que podria servir de vehiculo", "f2_plataforma")
    return f


def _render_fds03():
    f = {}
    st.markdown("**2. Datos del Entrevistado/a**")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Nombres y apellidos *", "f3_nombre")
    _T(f, c2, "DNI", "f3_dni")
    _T(f, c3, "Edad", "f3_edad")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "Genero", ["M", "F"], "f3_genero")
    _T(f, c2, "Cargo / Rol *", "f3_cargo")
    _T(f, c3, "Institucion / Organizacion", "f3_inst")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Años en el cargo", "f3_anios")
    _T(f, c2, "Telefono", "f3_tel")
    _T(f, c3, "Correo", "f3_correo")
    c1, c2 = st.columns(2)
    _T(f, c1, "Lugar de la entrevista", "f3_lugar")
    _T(f, c2, "Duracion (min)", "f3_dur")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Consiente uso de nombre en el informe?", DS_SINO, "f3_c_nom")
    _SB(f, c2, "¿Consiente toma de fotografias?", DS_SINO, "f3_c_foto")

    st.markdown("**3. Percepcion del Territorio y de los Recursos Naturales**")
    _TA(f, "3.1 ¿Que especies de arboles y arbustos nativos/silvestres existen actualmente "
           "y cuales han disminuido o desaparecido?", "f3_r1")
    _TA(f, "3.2 En los ultimos 10-15 años, ¿ha observado cambios en la disponibilidad de "
           "agua, bosque, suelo? Describa.", "f3_r2")
    _TA(f, "3.3 ¿Cuales son los principales problemas ambientales actuales (deforestacion, "
           "erosion, sequias, contaminacion, carcavas, huaicos)? ¿con que frecuencia e intensidad?", "f3_r3")
    _TA(f, "3.4 ¿Que zonas del territorio (bosques, manantiales, etc) considera mas "
           "importantes para conservar y por que?", "f3_r4")

    st.markdown("**4. Actividades Productivas y Medios de Vida**")
    _TA(f, "4.1 ¿Cuales son las actividades economicas mas importantes de la comunidad y "
           "quienes se dedican a cada una (hombres/mujeres)?", "f3_r5")
    _TA(f, "4.2 ¿Como se abastecen de agua para riego y consumo? ¿Hay deficit en alguna "
           "epoca del año, cuando? ¿Hay conflictos por el agua?", "f3_r6")
    _TA(f, "4.3 ¿Utilizan productos del bosque? ¿Cuales?", "f3_r7")
    _TA(f, "4.4 ¿Existen cadenas productivas organizadas o asociaciones de productores en la zona?", "f3_r8")

    st.markdown("**5. Organizacion, Gobernanza y Relacion con el Estado**")
    _TA(f, "5.1 ¿Que organizaciones sociales de base existen en la comunidad y cual es su "
           "rol en la toma de decisiones sobre el territorio?", "f3_r9")
    _TA(f, "5.2 ¿Como se toman las decisiones sobre el uso de recursos comunales (agua, bosque, pastos)?", "f3_r10")
    _TA(f, "5.3 ¿Como ha sido la relacion historica con el Estado y con proyectos de inversion "
           "externos (incluidos los mineros)?", "f3_r11")

    st.markdown("**6. Expectativas frente al Proyecto IN Piura**")
    _TA(f, "6.1 ¿Usted se encuentra de acuerdo con el proyecto o tiene alguna duda?", "f3_r_acuerdo")
    _TA(f, "6.2 ¿En que dias de la semana y horarios puede o preferiria participar en "
           "actividades relacionadas al proyecto?", "f3_r_horarios")
    _TA(f, "6.3 ¿Hay antecedentes de conflictos por proyectos externos (mineros, hidrocarburos, "
           "infraestructura) que ANIN deba tener en cuenta?", "f3_r_ant")
    _TA(f, "7. Cierre y observaciones del entrevistador/a", "f3_cierre")
    return f


def _render_fds04():
    f = {}
    st.markdown("**2. Datos del Taller**")
    c1, c2 = st.columns(2)
    _T(f, c1, "Lugar del taller *", "f4_lugar")
    _T(f, c2, "Entidad convocante", "f4_conv")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Fecha del taller *", "f4_fecha")
    _T(f, c2, "Hora inicio", "f4_hi")
    _T(f, c3, "Hora fin", "f4_hf")
    st.caption("2.1 Asistencia")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "N convocados", "f4_conv_n")
    _T(f, c2, "N hombres", "f4_h")
    _T(f, c3, "N mujeres", "f4_m")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "N jovenes (<30)", "f4_jov")
    _T(f, c2, "N adultos mayores (>60)", "f4_am")
    _T(f, c3, "N total asistentes", "f4_tot")
    _TA(f, "Objetivo general del taller *", "f4_obj", height=60)
    METODOS = ["Exposicion magistral", "Mesas de trabajo / Grupos focales", "Mapa parlante",
               "Matriz Foda / Vester", "Cartografia participativa", "Lluvia de ideas",
               "Entrevistas semiestructuradas", "Sociodrama / Dinamicas"]
    MATERIALES = ["Papelografos", "Plumones / Lapices", "Tarjetas de colores", "Cinta adhesiva",
                  "Mapas impresos / Ortofotos", "Proyector / Laptop", "Camara fotografica",
                  "Grabadora de audio", "Refrigerio", "Otros"]
    _MS(f, st, "2.2 Metodologia empleada", METODOS, "f4_metod")
    _MS(f, st, "2.3 Materiales utilizados", MATERIALES, "f4_mater")
    _SB(f, st, "2.4 Idioma de la facilitacion",
        ["Español", "Quechua", "Bilingue español-quechua", "Otro"], "f4_idioma")

    _TB(f, "**3. Lista de Participantes**", "f4_part",
        [("Nombres y Apellidos", "text", None), ("DNI", "text", None),
         ("Institucion / Comunidad", "text", None), ("Cargo / Rol", "text", None),
         ("Telefono", "text", None), ("Sexo", "select", ["M", "F"]),
         ("Edad", "text", None)],
        default_n=10)
    _TB(f, "**4. Agenda Desarrollada**", "f4_agenda",
        [("Hora", "text", None), ("Agenda", "text", None),
         ("Responsable", "text", None), ("Resultado / Aporte", "text", None)],
        default_n=3)
    _TB(f, "**5. Acuerdos y Compromisos**", "f4_acuerdos",
        [("Acuerdo / Compromiso", "text", None), ("Responsable", "text", None),
         ("Plazo", "text", None), ("Medio de verificacion", "text", None)],
        default_n=3)
    return f


def _render_fds05():
    f = {}
    st.info("TIPO: SM=Minero | SH=Hidrico | SF=Forestal ... ESTADO: LT=Latente | ES=Escalada | "
            "AC=Activo | NG=Negociacion | RS=Resuelto (ver hoja _Codigos).")
    _TB(f, "**2. Identificacion de Conflictos**", "f5_conflictos",
        [("Tipo", "select", FL.L_TIPO_CONFL),
         ("Actores involucrados", "text", None),
         ("Estado", "select", FL.L_NIVEL_CONFL),
         ("Antiguedad", "select", FL.L_ANTIG_CONFL),
         ("Descripcion / Causa raiz", "text", None),
         ("Impacto potencial en el proyecto", "text", None)],
        default_n=3,
        help="Registre conflictos activos, latentes y resueltos recientes.")

    st.markdown("**3. Contexto especifico - Conflicto minero Rio Blanco y otros**")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Vinculo historico con conflicto Rio Blanco?", DS_SINONA, "f5_rb1")
    _SB(f, c2, "¿Fue parte de la consulta de 2007?", DS_SINONA, "f5_rb2")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Persiste sentimiento anti-minero fuerte?", DS_SINONA, "f5_rb3")
    _SB(f, c2, "¿Liderazgos activos anti-mineros?", DS_SINONA, "f5_rb4")
    _SB(f, st, "¿Se diferencia el proyecto IN del contexto minero?", DS_SINONA, "f5_rb5")
    _T(f, st, "Otros conflictos relevantes (Tambogrande, Majaz, otros)", "f5_otros")
    _T(f, st, "Rol de las rondas en conflictos historicos", "f5_rol_rondas")
    _SB(f, st, "3.1 Nivel de polarizacion actual",
        ["Muy alto", "Alto", "Medio", "Bajo", "Muy bajo / Inexistente"], "f5_polar")

    _TB(f, "**4. Identificacion de Oportunidades**", "f5_oportunidades",
        [("Oportunidad identificada", "text", None),
         ("Actores relacionados", "text", None),
         ("Tipo (alianza / plataforma / proy.)", "text", None),
         ("Potencial", "select", FL.L_ABC),
         ("Como aprovecharla", "text", None)],
        default_n=3)

    st.markdown("**5. Sintesis Estrategica**")
    _SB(f, st, "5.1 Nivel global de conflictividad",
        ["Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"], "f5_confglob")
    _SB(f, st, "5.2 Viabilidad social preliminar",
        ["Alta — viable para intervencion inmediata", "Media — requiere acercamiento reforzado",
         "Baja — requiere mesa de dialogo previa", "Muy baja — reevaluar inclusion del bloque"], "f5_viab")
    _T(f, st, "Estrategia de acercamiento recomendada", "f5_estrategia")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Se requiere mesa de dialogo especifica?", DS_SINO, "f5_mesa")
    _SB(f, c2, "5.3 Plazo estimado para aceptacion comunal",
        ["Inmediato (<1 mes)", "Corto (1-3 meses)", "Medio (3-6 meses)",
         "Largo (6-12 meses)", "Requiere >12 meses"], "f5_plazo")
    return f


def _render_fds06():
    f = {}
    _T(f, st, "Fuente de informacion (N personas consultadas)", "f6_fuente")
    peligros_default = [{"Peligro observado": p} for p in FL.L_PELIGRO_OBS[:-1]]
    _TB(f, "**2. Percepcion de Peligros Naturales**", "f6_peligros",
        [("Peligro observado", "text", None),
         ("¿Ocurre?", "select", DS_SINO),
         ("Frecuencia", "select", FL.FDS06_FRECUENCIA),
         ("Magnitud", "select", FL.FDS06_MAGNITUD),
         ("Tendencia", "select", FL.FDS06_TENDENCIA),
         ("Ultimo evento (año)", "text", None),
         ("Principales daños observados", "text", None)],
        default_rows=peligros_default,
        help="Para cada peligro indique ocurrencia, frecuencia, magnitud y tendencia (desplegables).")

    cambios_default = [{"Cambio observado": c} for c in FL.L_CAMBIO_CLIMA[:-1]]
    _TB(f, "**3. Cambios Climaticos Observados (ultimos 10-15 años)**", "f6_cambios",
        [("Cambio observado", "text", None),
         ("¿Se percibe?", "select", DS_SINO),
         ("Intensidad", "select", FL.FDS06_INTENSIDAD),
         ("Año aprox. de inicio", "text", None),
         ("Impacto en la comunidad / territorio", "text", None)],
        default_rows=cambios_default)

    st.markdown("**4. Respuestas y Adaptaciones Locales**")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿La comunidad ha tomado medidas?", DS_SINO, "f6_medidas")
    _SB(f, c2, "¿Sistemas de alerta temprana comunitarios?", DS_SINO, "f6_alerta")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Saberes tradicionales de prediccion?", DS_SINO, "f6_saberes")
    _SB(f, c2, "¿Se requiere apoyo externo para adaptacion?", DS_SINO, "f6_apoyo")
    _TA(f, "Describa medidas / sistemas / saberes / apoyo requerido", "f6_desc")

    st.markdown("**5. Priorizacion Local de Peligros**")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Peligro mas grave (1)", "f6_p1")
    _T(f, c2, "Peligro mas grave (2)", "f6_p2")
    _T(f, c3, "Peligro mas grave (3)", "f6_p3")
    _SB(f, st, "¿Percepcion diferenciada por genero?", DS_SINO, "f6_genero")
    _T(f, st, "Percepcion diferenciada (describa)", "f6_genero_desc")
    return f


def _render_fds07():
    f = {}
    st.markdown("**2. Datos del Titular / Representante**")
    _SB(f, st, "2.1 Tipo de propietario/representante *", FL.L_TIPO_PROPIETARIO, "f7_tipo_prop")
    c1, c2, c3 = st.columns(3)
    _T(f, c1, "Nombres y apellidos *", "f7_nombre")
    _T(f, c2, "DNI *", "f7_dni")
    _T(f, c3, "Edad", "f7_edad")
    c1, c2 = st.columns(2)
    _SB(f, c1, "Genero", ["Hombre", "Mujer", "Otro / Pref. no decir"], "f7_genero")
    _T(f, c2, "Direccion / Residencia habitual", "f7_residencia")
    c1, c2 = st.columns(2)
    _T(f, c1, "Telefono / Correo de contacto", "f7_contacto")
    _T(f, c2, "Superficie predio en el bloque (ha)", "f7_superficie")
    DOCS = ["Titulo de propiedad SUNARP", "Constancia de posesion (municipal)", "Titulo COFOPRI",
            "Certificado catastral", "Resolucion de adjudicacion", "Sin documentacion disponible"]
    _MS(f, st, "2.2 Documentacion de tenencia disponible", DOCS, "f7_docs")
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Tiene conflictos de linderos?", DS_SINO, "f7_linderos")
    _SB(f, c2, "¿Es residente permanente?", DS_SINO, "f7_residente")

    st.markdown("**3. Informacion Provista al Titular / Representante**")
    st.caption("Marque Si cuando el punto fue efectivamente explicado y comprendido.")
    PUNTOS = [
        ("f7_info_anin", "3.1 Se explico que es la ANIN"),
        ("f7_info_objetivo", "3.2 Se explico el objetivo del proyecto IN Piura"),
        ("f7_info_no_minero", "3.3 Se explico que NO es actividad minera ni extractiva"),
        ("f7_info_medidas", "3.4 Se explico que medidas podrian implementarse en el predio"),
        ("f7_info_temporalidad", "3.5 Se explico la temporalidad del proyecto"),
        ("f7_info_voluntaria", "3.6 Se explico que la participacion es voluntaria"),
        ("f7_info_actualizada", "3.7 Se explico el derecho a informacion actualizada"),
        ("f7_info_confidencialidad", "3.8 Se explico el tratamiento confidencial de datos"),
        ("f7_info_preguntas", "3.9 Se absolvieron todas las preguntas"),
        ("f7_info_material", "3.10 Se entrego material informativo"),
    ]
    for i in range(0, len(PUNTOS), 2):
        cols = st.columns(2)
        for j, (k, lbl) in enumerate(PUNTOS[i:i + 2]):
            _SB(f, cols[j], lbl, DS_SINO, k)

    st.markdown("**4. Manifestacion de Disposicion a Participar**")
    _SB(f, st, "4.1 Disposicion general a participar *", FL.L_DISPOSICION, "f7_disp")
    _TA(f, "Condiciones o requisitos planteados", "f7_cond", height=70)
    c1, c2 = st.columns(2)
    _SB(f, c1, "¿Requiere consultar con familia/asamblea?", DS_SINO, "f7_consultar")
    _T(f, c2, "Plazo solicitado para respuesta (dias)", "f7_plazo")
    c1, c2, c3 = st.columns(3)
    _SB(f, c1, "¿Autoriza ingreso preliminar?", DS_SINO, "f7_aut_ing")
    _SB(f, c2, "¿Autoriza fotografias del predio?", DS_SINO, "f7_aut_foto")
    _SB(f, c3, "¿Autoriza uso de su nombre?", DS_SINO, "f7_aut_nom")

    st.markdown("**5. Preguntas, Preocupaciones y Compromisos**")
    _TA(f, "5.1 Preguntas / preocupaciones del titular", "f7_preg")
    _TA(f, "5.2 Compromisos adquiridos por ANIN/SESDI", "f7_comp")
    return f


_DS_RENDERERS = {
    "F-DS-01": _render_fds01, "F-DS-02": _render_fds02, "F-DS-03": _render_fds03,
    "F-DS-04": _render_fds04, "F-DS-05": _render_fds05, "F-DS-06": _render_fds06,
    "F-DS-07": _render_fds07,
}


def _ds_join(v):
    """Serializa a texto un valor que puede ser lista (multiselect) o escalar."""
    if isinstance(v, (list, tuple, set)):
        return " / ".join(str(x) for x in v)
    return v if v is not None else ""


def _ds_legacy_cols(ficha, f):
    """Mapea el formulario V3 a columnas legacy para compatibilidad de reportes."""
    L = {}
    if ficha == "F-DS-01":
        L.update({
            "ds01_num_familias": f.get("f1_nfam", ""),
            "ds01_poblacion_hombres": f.get("f1_pob_h", ""),
            "ds01_poblacion_mujeres": f.get("f1_pob_m", ""),
            "ds01_poblacion_total": f.get("f1_pob_t", ""),
            "ds01_idioma": f.get("f1_idioma", ""),
            "ds01_nivel_educativo": f.get("f1_nivel_edu", ""),
            "ds01_tasa_migracion": f.get("f1_migracion", ""),
            "ds01_destino_migracion": f.get("f1_destino_mig", ""),
            "ds01_organizacion_comunal": f.get("f1_org_terr", ""),
            "ds01_junta_directiva": f.get("f1_junta_vig", ""),
            "ds01_presidente_junta": f.get("f1_pres_junta", ""),
            "ds01_agua_potable_tipo": _ds_join(f.get("f1_agua", "")),
            "ds01_agua_potable_cobertura": f.get("f1_agua_cob", ""),
            "ds01_saneamiento": _ds_join(f.get("f1_sanea", "")),
            "ds01_energia_tipo": _ds_join(f.get("f1_energia", "")),
            "ds01_energia_cobertura": f.get("f1_energia_cob", ""),
            "ds01_telecomunicaciones": f.get("f1_telecom", ""),
            "ds01_telecom_operador": f.get("f1_telecom_op", ""),
            "ds01_salud_tipo": f.get("f1_eess", ""),
            "ds01_salud_distancia": f.get("f1_eess_dist", ""),
            "ds01_educacion": f.get("f1_ie_niveles", ""),
            "ds01_actividades_economicas": json.dumps(f.get("f1_activ", []), ensure_ascii=False) if f.get("f1_activ") else "",
        })
    elif ficha == "F-DS-02":
        L["ds02_registro_actores"] = json.dumps(f.get("f2_actores", []), ensure_ascii=False) if f.get("f2_actores") else ""
    elif ficha == "F-DS-03":
        L.update({
            "ds03_nombre_entrevistado": f.get("f3_nombre", ""),
            "ds03_cargo_funcion": f.get("f3_cargo", ""),
            "ds03_institucion": f.get("f3_inst", ""),
            "ds03_telefono_correo": f.get("f3_tel", "") or f.get("f3_correo", ""),
            "ds03_duracion": f.get("f3_dur", ""),
            "ds03_resp_recursos_naturales": f.get("f3_r1", ""),
            "ds03_resp_cambios_ambiente": f.get("f3_r2", ""),
            "ds03_resp_problemas_ambientales": f.get("f3_r3", ""),
            "ds03_resp_zonas_conservacion": f.get("f3_r4", ""),
            "ds03_resp_actividades_economicas": f.get("f3_r5", ""),
            "ds03_resp_abastecimiento_agua": f.get("f3_r6", ""),
            "ds03_resp_productos_bosque": f.get("f3_r7", ""),
            "ds03_resp_cadenas_productivas": f.get("f3_r8", ""),
            "ds03_resp_organizaciones": f.get("f3_r9", ""),
            "ds03_resp_decisiones_territorio": f.get("f3_r10", ""),
            "ds03_resp_expectativas": f.get("f3_r_acuerdo", ""),
            "ds03_resp_condiciones": f.get("f3_r_horarios", ""),
        })
    elif ficha == "F-DS-04":
        L.update({
            "ds04_lugar_taller": f.get("f4_lugar", ""),
            "ds04_convocante": f.get("f4_conv", ""),
            "ds04_hora_inicio": f.get("f4_hi", ""),
            "ds04_hora_fin": f.get("f4_hf", ""),
            "ds04_objetivo": f.get("f4_obj", ""),
            "ds04_lista_participantes": json.dumps(f.get("f4_part", []), ensure_ascii=False) if f.get("f4_part") else "",
        })
    elif ficha == "F-DS-05":
        L["ds05_conflictos"] = json.dumps(f.get("f5_conflictos", []), ensure_ascii=False) if f.get("f5_conflictos") else ""
        L["ds05_oportunidades"] = json.dumps(f.get("f5_oportunidades", []), ensure_ascii=False) if f.get("f5_oportunidades") else ""
    return L


def _ds_build_edit_pending(det):
    """Construye {session_key: valor} para precargar un registro (modo edicion)."""
    ficha = det.get("ficha", "")
    pend = {
        "ds_mc": det.get("microcuenca", "") or "",
        "ds_eval": det.get("evaluador", "") or "",
        "ds_fnum": det.get("ficha_numero", "") or "",
        "ds_prov": det.get("provincia", "") or "",
        "ds_dist": det.get("distrito", "") or "",
        "ds_cpob": det.get("centro_poblado", "") or "",
        "ds_ccam": det.get("comunidad_campesina", "") or "",
        "ds_este": float(det.get("coordenada_este") or 0),
        "ds_norte": float(det.get("coordenada_norte") or 0),
        "ds_alt": float(det.get("altitud") or 0),
        "ds_ubigeo": det.get("codigo_ubigeo", "") or "",
        "ds_entrev_nombre": det.get("nombre_entrevistado", "") or "",
        "ds_entrev_dni": det.get("dni_entrevistado", "") or "",
        "ds_entrev_oficio": det.get("oficio_ocupacion", "") or "",
        "ds_obs": det.get("observaciones_generales", "") or "",
        "ds_ficha_sel": ficha,
    }
    if det.get("fecha_evaluacion"):
        try:
            pend["ds_fecha"] = datetime.strptime(det["fecha_evaluacion"], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            pass
    num = ficha.split("-")[-1] if ficha else ""
    form = {}
    raw = det.get(f"ds{num}_data_v3", "") or ""
    if raw:
        try:
            form = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            form = {}
    for k, v in form.items():
        if k in _DS_TABLE_SLOTS:
            pend[f"_dsinit_{k}"] = v if isinstance(v, list) else []
        else:
            pend[k] = v
    return pend


def _ds_apply_pending():
    """Aplica precarga pendiente (edicion / import) a session_state una vez."""
    pend = st.session_state.pop("_ds_pending_state", None)
    if not pend:
        return
    edit_id = st.session_state.pop("_ds_pending_edit_id", None)
    # Limpiar widgets de la ficha anterior para evitar valores residuales
    st.session_state["_ds_nonce"] = _ds_nonce() + 1
    for k, v in pend.items():
        st.session_state[k] = v
    st.session_state["ds_edit_id"] = edit_id


def _ds_humaniza(key):
    s = key
    for p in ("f1_", "f2_", "f3_", "f4_", "f5_", "f6_", "f7_"):
        if s.startswith(p):
            s = s[len(p):]
            break
    return s.replace("_", " ").capitalize()


def _ds_render_detalle(ficha, form):
    """Muestra el formulario V3 de un registro (vista de Historial)."""
    if not isinstance(form, dict) or not form:
        st.caption("Sin datos detallados V4 para esta ficha.")
        return
    # Tablas primero
    for slot in _DS_TABLE_SLOTS:
        if slot in form and isinstance(form[slot], list) and form[slot]:
            titulo = {
                "f1_activ": "Actividades economicas", "f2_actores": "Registro de actores",
                "f4_part": "Participantes", "f4_agenda": "Agenda", "f4_acuerdos": "Acuerdos",
                "f5_conflictos": "Conflictos", "f5_oportunidades": "Oportunidades",
                "f6_peligros": "Peligros naturales", "f6_cambios": "Cambios climaticos",
            }.get(slot, slot)
            with st.expander(f"{titulo} ({len(form[slot])})", expanded=True):
                st.dataframe(pd.DataFrame(form[slot]), use_container_width=True, hide_index=True)
    # Escalares
    escalares = {k: v for k, v in form.items()
                 if k not in _DS_TABLE_SLOTS and v not in ("", None, [])}
    if escalares:
        with st.expander("Campos de la ficha", expanded=True):
            items = list(escalares.items())
            for i in range(0, len(items), 2):
                cols = st.columns(2)
                for j, (k, v) in enumerate(items[i:i + 2]):
                    if isinstance(v, list):
                        v = ", ".join(str(x) for x in v)
                    cols[j].markdown(f"**{_ds_humaniza(k)}:** {v}")


# ══════════════════════════════════════════════════════════════════════════
# GRAFICOS Y RESUMENES DEL DIAGNOSTICO SOCIAL
# ══════════════════════════════════════════════════════════════════════════
# Contraparte social de los resumenes Excel del Diagnostico Territorial: las
# mismas fichas F-DS-01..07 que alimentan el PDF se leen aqui como graficos
# interactivos y se descargan como libro Excel con graficos nativos.

_TONOS_METRICA = {"favorable": "#2E7D4F", "critico": "#C0392B",
                  "neutro": "#7A7975"}


def _ds_tema():
    """Tema activo de Streamlit, para elegir la paleta del grafico.

    La deteccion cambio de sitio entre versiones; si ninguna via responde se
    asume el tema claro, que es el que usa el aplicativo por defecto.
    """
    try:
        tipo = st.context.theme.type          # Streamlit >= 1.44
        if tipo:
            return "oscuro" if tipo == "dark" else "claro"
    except Exception:
        pass
    try:
        return "oscuro" if st.get_option("theme.base") == "dark" else "claro"
    except Exception:
        return "claro"


def _ds_metricas(metricas):
    """Fila de cifras de cabecera, de cuatro en cuatro."""
    for inicio in range(0, len(metricas), 4):
        for col, m in zip(st.columns(4), metricas[inicio:inicio + 4]):
            col.metric(m["etiqueta"], m["valor"])
            detalle = m.get("detalle", "")
            if detalle:
                # El detalle sube a pegarse al valor y deja aire por debajo,
                # para que no se confunda con el rotulo de la fila siguiente.
                color = _TONOS_METRICA.get(m.get("tono", "neutro"),
                                           _TONOS_METRICA["neutro"])
                col.markdown(
                    f'<div style="margin:-.7rem 0 .9rem;font-size:.78rem;'
                    f'line-height:1.2;color:{color}">{detalle}</div>',
                    unsafe_allow_html=True)


def _ds_render_serie(serie, tema, clave):
    """Un grafico interactivo con su tabla de respaldo desplegable."""
    try:
        grafico = ans.grafico_altair(serie, tema=tema)
    except Exception as exc:
        st.warning(f"No se pudo dibujar «{serie['titulo']}»: {exc}")
        return
    if grafico is None:
        return
    # theme=None: el tema propio de Streamlit reescribe colores, tipografia y
    # tamanos de banda, y deja las barras apiladas sin dibujar. La paleta y la
    # geometria ya vienen resueltas y validadas desde `analitica_social`.
    st.altair_chart(grafico, use_container_width=True, theme=None)
    # La tabla no es un adorno: sostiene la lectura de los tonos claros y
    # permite copiar las cifras sin exportar el libro.
    with st.expander("Ver los datos del gráfico", expanded=False):
        st.dataframe(ans.tabla_serie(serie), use_container_width=True,
                     hide_index=True)
        if serie.get("nota"):
            st.caption("Fuente: " + serie["nota"])


def _ds_descargas_analitica(informe, clave):
    """Botones de descarga del libro Excel y del anexo grafico en PDF."""
    st.markdown("**Descargas**")
    st.caption("El libro Excel trae una hoja por sección con su tabla de "
               "datos y su gráfico nativo (editable en Excel), más las hojas "
               "de respaldo con el detalle ficha por ficha. El anexo PDF "
               "reproduce los mismos gráficos con el formato institucional.")
    c1, c2 = st.columns(2)
    if c1.button("Generar Excel con gráficos", key=f"{clave}_gen_xlsx",
                 type="primary", use_container_width=True):
        with st.spinner("Construyendo el libro..."):
            try:
                st.session_state[f"{clave}_xlsx"] = (
                    ans.nombre_excel(informe), ans.generar_excel_social(informe))
            except Exception as exc:
                st.error(f"No se pudo generar el Excel: {exc}")
    if c2.button("Generar anexo gráfico (PDF)", key=f"{clave}_gen_pdf",
                 use_container_width=True):
        with st.spinner("Construyendo el anexo..."):
            try:
                st.session_state[f"{clave}_pdf"] = (
                    ans.nombre_pdf(informe), ans.generar_pdf_social(informe))
            except Exception as exc:
                st.error(f"No se pudo generar el PDF: {exc}")
    listo_xlsx = st.session_state.get(f"{clave}_xlsx")
    if listo_xlsx:
        c1.download_button(f"⬇️ Descargar {listo_xlsx[0]}", listo_xlsx[1],
                           file_name=listo_xlsx[0], mime=_mime_xlsx(),
                           key=f"{clave}_dl_xlsx", use_container_width=True)
    listo_pdf = st.session_state.get(f"{clave}_pdf")
    if listo_pdf:
        c2.download_button(f"⬇️ Descargar {listo_pdf[0]}", listo_pdf[1],
                           file_name=listo_pdf[0], mime="application/pdf",
                           key=f"{clave}_dl_pdf", use_container_width=True)


def _ds_render_informe(informe, clave):
    """Informe analitico completo: cifras, descargas y graficos por ficha."""
    if not informe.get("secciones"):
        st.info("No hay fichas sociales registradas en el ámbito "
                "seleccionado; no hay nada que graficar todavía.")
        return
    _ds_metricas(informe.get("metricas", []))
    for aviso in informe.get("avisos", []):
        st.caption("⚠️ " + aviso)
    st.markdown("---")
    _ds_descargas_analitica(informe, clave)
    st.markdown("---")

    tema = informe.get("tema", "claro")
    titulos = [s["titulo"] for s in informe["secciones"]]
    for pestana, seccion in zip(st.tabs(titulos), informe["secciones"]):
        with pestana:
            if seccion.get("descripcion"):
                st.caption(seccion["descripcion"])
            for serie in seccion["series"]:
                _ds_render_serie(serie, tema, f"{clave}_{serie['id']}")
                st.markdown("")


@st.cache_data(ttl=300, show_spinner=False, max_entries=8)
def _cached_informe_social(codigo, bloque_id, tema, _version):
    """Informe analitico de un bloque, tal como lo ve el PDF de la ficha.

    Se cachea porque la pagina de Reportes y el historial lo reconstruyen en
    cada rerun: sin cache, cada clic en cualquier control del formulario
    dispara dos consultas y el parseo de todas las fichas del bloque.
    """
    bloque = db.obtener_bloque_por_id(bloque_id) or {"codigo": codigo}
    return ans.indicadores_bloque(
        bloque, db.obtener_diagnosticos_sociales_por_bloque(bloque_id),
        datos_cp=_cp_bloque(codigo), tema=tema)


def _ds_informe_bloque(codigo, bloque_id):
    return _cached_informe_social(codigo, bloque_id, _ds_tema(),
                                  _cache_version())


def _tab_graficos_sociales(bm):
    """Pestana de graficos y resumenes del Diagnostico Social."""
    st.markdown("### Gráficos y resúmenes del Diagnóstico Social")
    st.caption(
        "Lectura analítica de las fichas F-DS-01 a F-DS-07 registradas: "
        "cobertura del levantamiento, demografía y servicios, mapa de "
        "actores, talleres, conflictos y oportunidades, percepción de "
        "peligros y cambio climático, y consentimiento previo informado. "
        "Los gráficos son interactivos (pase el cursor por cada barra) y se "
        "descargan como libro Excel con gráficos nativos y como anexo PDF, "
        "para acompañar a la ficha PDF del bloque.")

    ambito = st.radio("Ámbito del análisis",
                      ["Un bloque", "Consolidado de varios bloques"],
                      horizontal=True, key="ds_graf_ambito")
    todos = _cached_obtener_todos_diagnosticos_sociales(_cache_version())
    if not todos:
        st.info("Aún no hay fichas sociales registradas.")
        return

    if ambito == "Un bloque":
        codigos = sorted({d.get("bloque_codigo", "") for d in todos
                          if d.get("bloque_codigo")})
        if not codigos:
            st.info("Las fichas registradas no están asociadas a un bloque.")
            return
        codigo = st.selectbox("Bloque", codigos, key="ds_graf_bloque")
        bloque_id = bm.get(codigo)
        if not bloque_id:
            st.error(f"El bloque {codigo} ya no existe en la base de datos.")
            return
        informe = _ds_informe_bloque(codigo, bloque_id)
        st.markdown(f"#### Bloque {codigo}")
        _ds_render_informe(informe, f"ds_graf_b_{codigo}")
        return

    # ── Consolidado ──
    f1, f2, f3 = st.columns(3)
    provincias = sorted({d.get("provincia", "") for d in todos if d.get("provincia")})
    distritos = sorted({d.get("distrito", "") for d in todos if d.get("distrito")})
    microcuencas = sorted({d.get("microcuenca", "") for d in todos if d.get("microcuenca")})
    fil_prov = f1.multiselect("Provincia", provincias, key="ds_graf_prov")
    fil_dist = f2.multiselect("Distrito", distritos, key="ds_graf_dist")
    fil_micro = f3.multiselect("Microcuenca", microcuencas, key="ds_graf_micro")
    filtrados = [
        d for d in todos
        if (not fil_prov or d.get("provincia") in fil_prov)
        and (not fil_dist or d.get("distrito") in fil_dist)
        and (not fil_micro or d.get("microcuenca") in fil_micro)
    ]
    etiqueta = " / ".join(filter(None, [
        ", ".join(fil_prov), ", ".join(fil_dist), ", ".join(fil_micro)])) \
        or "todo el ámbito"
    st.caption(f"{len(filtrados)} ficha(s) social(es) tras aplicar los filtros "
               f"({etiqueta}).")
    if not filtrados:
        st.info("Ningún registro cumple los filtros seleccionados.")
        return
    informe = ans.indicadores_consolidado(filtrados, etiqueta=etiqueta,
                                          tema=_ds_tema())
    # La clave del estado incluye el filtro: asi un Excel ya generado no se
    # ofrece como descarga cuando el usuario cambia de ambito.
    _ds_render_informe(informe, "ds_graf_cons_" + _clave_filtro(etiqueta))


def _clave_filtro(etiqueta):
    """Clave de session_state estable a partir de la etiqueta del filtro."""
    return re.sub(r"[^A-Za-z0-9]+", "_", etiqueta)[:60] or "todo"


def pagina_diagnostico_social():
    st.subheader("Diagnostico Social - Fichas de Campo (V4)")
    st.caption("Proyecto IN Piura CUI 2669244 | ANIN - DIME - SESDI | "
               "Plantilla validada F-DS-01 a F-DS-07 con celdas de validacion")
    _mostrar_flash()
    bm = _bloques_map()
    if not bm:
        st.warning("Registre un bloque primero.")
        return

    if "ds_edit_id" not in st.session_state:
        st.session_state["ds_edit_id"] = None

    # Aplicar precarga pendiente (import Excel o edicion) antes de los widgets
    _ds_apply_pending()

    ficha_sel = st.radio(
        "Seleccionar ficha", FICHAS_DS, horizontal=True, key="ds_ficha_sel",
        format_func=lambda x: f"{x} - {FICHAS_DS_TITULOS.get(x, '')}")

    tab_reg, tab_hist, tab_graf, tab_excel = st.tabs(
        ["Registro", "Historial / Consulta", "Gráficos y Resúmenes",
         "Importar desde Excel"])

    with tab_reg:
        edit_id = st.session_state.get("ds_edit_id")
        if edit_id:
            st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                        f'Modo Edicion - Diagnostico Social ID {edit_id}</div>', unsafe_allow_html=True)
            if st.button("Cancelar edicion (nuevo registro)", key="ds_cancel_edit"):
                st.session_state["ds_edit_id"] = None
                st.session_state["_ds_nonce"] = _ds_nonce() + 1
                st.rerun()

        bl = st.selectbox("Bloque de Intervencion", list(bm.keys()), key="ds_bl")
        bid = bm[bl]

        prev_bl = st.session_state.get("_ds_prev_bl", "")
        if prev_bl and prev_bl != bl and not edit_id:
            for k in ("ds_prov", "ds_dist", "ds_cpob", "ds_ccam", "ds_este", "ds_norte",
                      "ds_entrev_nombre", "ds_entrev_dni", "ds_entrev_oficio"):
                st.session_state.pop(k, None)
        st.session_state["_ds_prev_bl"] = bl

        mc_auto_ds = _resolver_microcuenca(bl)
        if mc_auto_ds:
            mc_idx_ds = MICROCUENCAS.index(mc_auto_ds) + 1
            st.info(f"Microcuenca vinculada automaticamente: **{mc_auto_ds}**")
        else:
            mc_idx_ds = 0

        r1, r2, r3, r4 = st.columns(4)
        mc = r1.selectbox("Microcuenca", [""] + MICROCUENCAS, index=mc_idx_ds, key="ds_mc")
        fecha_ev = r2.date_input("Fecha", value=datetime.now(), key="ds_fecha",
                                 min_value=FECHA_MIN_PROYECTO, max_value=date.today())
        evaluador = r3.text_input("Responsable", key="ds_eval")
        ficha_num = r4.text_input("Ficha N", key="ds_fnum")
        dg = _ds_datos_generales(bloque_label=bl)
        st.markdown("---")
        st.markdown(f"### {ficha_sel}: {FICHAS_DS_TITULOS.get(ficha_sel, '').upper()}")

        renderer = _DS_RENDERERS.get(ficha_sel)
        form = renderer() if renderer else {}

        st.markdown("---")
        observ_gen = st.text_area("Observaciones generales", key="ds_obs")
        adj_files = st.file_uploader(
            "Adjuntar archivos de soporte (PDF, max. 25 MB por archivo)",
            type=["pdf"], accept_multiple_files=True, key="ds_adj_upload")

        btn_label = "Actualizar Diagnostico Social" if edit_id else "Guardar Diagnostico Social"
        if st.button(btn_label, type="primary", key="ds_guardar"):
            if not evaluador:
                st.warning("Ingrese el nombre del responsable.")
            else:
                try:
                    archivos_guardados = []
                    if adj_files:
                        carpeta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "adjuntos_ds")
                        os.makedirs(carpeta, exist_ok=True)
                        for fobj in adj_files:
                            if fobj.size > 25 * 1024 * 1024:
                                st.warning(f"Archivo {fobj.name} excede 25 MB, omitido.")
                                continue
                            nombre = f"{uuid.uuid4().hex[:8]}_{fobj.name}"
                            ruta = os.path.join(carpeta, nombre)
                            with open(ruta, "wb") as out:
                                out.write(fobj.getbuffer())
                            archivos_guardados.append(nombre)

                    num = ficha_sel.split("-")[-1]
                    reg = {
                        "bloque_id": bid, "ficha": ficha_sel,
                        "ficha_numero": ficha_num, "microcuenca": mc,
                        "fecha_evaluacion": fecha_ev.strftime("%Y-%m-%d"),
                        "evaluador": evaluador,
                        "observaciones_generales": observ_gen,
                        f"ds{num}_data_v3": json.dumps(form, ensure_ascii=False),
                    }
                    reg.update(_ds_legacy_cols(ficha_sel, form))
                    if archivos_guardados:
                        reg["archivos_adjuntos"] = "|".join(archivos_guardados)
                    reg.update(dg)

                    if edit_id:
                        db.actualizar_diagnostico_social(edit_id, reg)
                        _invalidar_cache()
                        st.session_state["ds_edit_id"] = None
                        _flash(f"Ficha {ficha_sel} actualizada correctamente (ID {edit_id}).")
                    else:
                        existentes_ds = db.obtener_diagnosticos_sociales_por_bloque(bid)
                        dup_ds = [e for e in existentes_ds
                                  if e.get("ficha") == ficha_sel
                                  and e.get("fecha_evaluacion") == fecha_ev.strftime("%Y-%m-%d")
                                  and e.get("evaluador") == evaluador]
                        if dup_ds:
                            st.markdown('<div class="dup-warning">Ya existe una ficha '
                                       f'{ficha_sel} para este bloque en '
                                       f'{fecha_ev.strftime("%Y-%m-%d")} por {evaluador}. '
                                       f'Use <b>Editar</b> en Historial para modificarla.</div>',
                                       unsafe_allow_html=True)
                        else:
                            if "archivos_adjuntos" not in reg:
                                reg["archivos_adjuntos"] = ""
                            db.insertar_diagnostico_social(reg)
                            _invalidar_cache()
                            _flash(f"Ficha {ficha_sel} guardada correctamente.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")

    # ── HISTORIAL ──────────────────────────────────────────────────────
    with tab_hist:
        st.markdown("### Historial de Diagnosticos Sociales")
        st.caption("Pulse **Editar** para modificar un registro o **Eliminar** para descartarlo.")
        if st.session_state.get("ds_edit_id"):
            st.info("✏️ Registro cargado en **modo edicion**. Abra la pestaña "
                    "**'Registro'** (arriba) para corregir los campos y "
                    "pulsar **Actualizar Diagnostico Social**.")
        todos_ds = _cached_obtener_todos_diagnosticos_sociales(_cache_version())
        if not todos_ds:
            st.info("No hay diagnosticos sociales registrados.")
        else:
            # Igual que en FDT: generar solo bajo demanda para no repetir
            # la exportacion completa en cada rerun.
            if st.button(
                    "Generar Excel consolidado", key="ds_export_prep", type="secondary",
                    help="Genera un unico archivo Excel con una hoja por ficha (F-DS-01..07) "
                         "y hojas adicionales para las tablas (actores, participantes, conflictos, etc.)."):
                st.session_state["ds_export_bytes"] = exp_diag.exportar_fds_consolidado(todos_ds)
            if st.session_state.get("ds_export_bytes"):
                st.download_button(
                    "⬇️ Descargar todo (Excel)",
                    data=st.session_state["ds_export_bytes"],
                    file_name=f"Diagnostico_Social_FDS_{datetime.now():%Y%m%d}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="ds_export_excel", type="secondary")

            # ── Ficha PDF individual por bloque y sus centros poblados ──
            st.markdown("---")
            st.markdown("#### Ficha PDF individual por bloque (con sus Centros Poblados)")
            st.caption("Genera un PDF por bloque con la relacion de sus centros "
                       "poblados y todas las fichas F-DS-01 a F-DS-07 registradas, "
                       "agrupadas por centro poblado.")
            cods_ds = sorted({(d.get("bloque_codigo", "") or "") for d in todos_ds
                              if d.get("bloque_codigo")})
            if not cods_ds:
                st.info("Aun no hay fichas sociales asociadas a un bloque.")
            else:
                c_dspdf1, c_dspdf2 = st.columns([2, 1])
                bl_ds_pdf = c_dspdf1.selectbox("Bloque", cods_ds, key="ds_pdf_bl")
                cp_info_pdf = _cp_bloque(bl_ds_pdf)
                cps_pdf = cp_info_pdf.get("centros_poblados", [])
                if cps_pdf:
                    pob_cp = cp_info_pdf.get("poblacion_total", 0)
                    detalle_pob = f" | {pob_cp:,} hab." if pob_cp else ""
                    c_dspdf1.caption(f"Centros poblados del catalogo: "
                                     f"{', '.join(cps_pdf)}{detalle_pob}")
                else:
                    c_dspdf1.caption("Sin centros poblados en el catalogo oficial para "
                                     "este bloque; la ficha usara los consignados en campo.")
                if c_dspdf2.button("Generar ficha PDF", key="ds_pdf_gen", type="primary"):
                    bid_ds_pdf = bm.get(bl_ds_pdf)
                    if not bid_ds_pdf:
                        st.error(f"El bloque {bl_ds_pdf} ya no existe en la base de datos.")
                    else:
                        try:
                            nombre_pdf, bytes_pdf = reports.generar_ficha_ds_bloque_pdf(
                                bid_ds_pdf, datos_cp=cp_info_pdf)
                            st.session_state["ds_pdf_bytes"] = bytes_pdf
                            st.session_state["ds_pdf_nombre"] = nombre_pdf
                            st.session_state["ds_pdf_bloque"] = bl_ds_pdf
                        except Exception as e:
                            st.error(f"No se pudo generar la ficha PDF: {e}")
                if (st.session_state.get("ds_pdf_bytes")
                        and st.session_state.get("ds_pdf_bloque") == bl_ds_pdf):
                    st.download_button(
                        f"⬇️ Descargar ficha DS del bloque {bl_ds_pdf} (PDF)",
                        data=st.session_state["ds_pdf_bytes"],
                        file_name=st.session_state["ds_pdf_nombre"],
                        mime="application/pdf", key="ds_pdf_dl")

                # Graficos y resumenes del mismo bloque, para descargarlos
                # junto con la ficha PDF.
                st.markdown("**Gráficos y resúmenes del bloque**")
                st.caption("Mismo contenido de la ficha leído como gráficos: "
                           "libro Excel con gráficos nativos y anexo PDF. La "
                           "versión interactiva está en la pestaña "
                           "**Gráficos y Resúmenes**.")
                bid_graf = bm.get(bl_ds_pdf)
                if bid_graf:
                    try:
                        _ds_descargas_analitica(
                            _ds_informe_bloque(bl_ds_pdf, bid_graf),
                            f"ds_hist_graf_{bl_ds_pdf}")
                    except Exception as exc:
                        st.error(f"No se pudo preparar la analítica del "
                                 f"bloque {bl_ds_pdf}: {exc}")
            st.markdown("---")

            ds_pag, total_pags_ds, pag_actual_ds = _paginar(todos_ds, "pag_ds")
            _controles_paginacion(total_pags_ds, pag_actual_ds, "pag_ds")
            col_widths_ds = [0.4, 0.9, 0.7, 0.8, 0.8, 0.8, 0.8, 0.5, 0.6]
            header_cols = st.columns(col_widths_ds)
            for col, h in zip(header_cols, ["ID", "Bloque", "Ficha", "Fecha", "Responsable", "C.Poblado", "Distrito", "", ""]):
                col.markdown(f"**{h}**")
            st.markdown("---")
            confirm_del_ds_id = st.session_state.get("ds_confirm_del_id")
            for d in ds_pag:
                row = st.columns(col_widths_ds)
                row[0].write(d["id"])
                row[1].write(d.get("bloque_codigo", ""))
                row[2].write(d.get("ficha", ""))
                row[3].write(d.get("fecha_evaluacion", ""))
                row[4].write(d.get("evaluador", ""))
                row[5].write(d.get("centro_poblado", "") or "")
                row[6].write(d.get("distrito", "") or "")
                if row[7].button("Editar", key=f"edit_ds_{d['id']}", type="primary"):
                    det = db.obtener_diagnostico_social_por_id(d["id"])
                    if det:
                        st.session_state["_ds_pending_state"] = _ds_build_edit_pending(det)
                        st.session_state["_ds_pending_edit_id"] = det["id"]
                    st.session_state.pop("ds_confirm_del_id", None)
                    st.rerun()
                if confirm_del_ds_id == d["id"]:
                    if row[8].button("Confirmar", key=f"del_confirm_ds_{d['id']}", type="primary"):
                        db.eliminar_diagnostico_social(d["id"])
                        _invalidar_cache()
                        st.session_state.pop("ds_confirm_del_id", None)
                        st.success(f"Diagnostico social ID {d['id']} eliminado.")
                        st.rerun()
                else:
                    if row[8].button("Eliminar", key=f"del_ds_{d['id']}", type="secondary"):
                        st.session_state["ds_confirm_del_id"] = d["id"]
                        st.rerun()
            if confirm_del_ds_id is not None:
                st.warning(f"Confirme la eliminacion del diagnostico social ID {confirm_del_ds_id} "
                           "pulsando 'Confirmar' en su fila. Esta accion no puede deshacerse.")
                if st.button("Cancelar eliminacion", key="ds_cancel_del"):
                    st.session_state.pop("ds_confirm_del_id", None)
                    st.rerun()
            st.markdown("---")

            st.markdown("### Detalle de Ficha")
            dm_ds = {f"ID {d['id']} - {d.get('bloque_codigo','')} ({d.get('ficha','')})": d["id"] for d in todos_ds}
            sel_ds = st.selectbox("Seleccionar registro", [""] + list(dm_ds.keys()), key="ds_det")
            if sel_ds and sel_ds in dm_ds:
                det = db.obtener_diagnostico_social_por_id(dm_ds[sel_ds])
                if det:
                    ficha_t = det.get("ficha", "")
                    st.markdown(f"**Ficha:** {ficha_t} | **Bloque:** {det.get('bloque_codigo','')} | "
                                f"**Fecha:** {det.get('fecha_evaluacion','')} | "
                                f"**Responsable:** {det.get('evaluador','')}")
                    if det.get("centro_poblado"):
                        st.markdown(f"**Centro Poblado:** {det['centro_poblado']} | "
                                    f"**Comunidad:** {det.get('comunidad_campesina','') or '-'} | "
                                    f"**Distrito:** {det.get('distrito','') or det.get('provincia','')}")
                    if det.get("nombre_entrevistado") or det.get("dni_entrevistado") or det.get("oficio_ocupacion"):
                        st.markdown(f"**Entrevistado:** {det.get('nombre_entrevistado','') or '-'} | "
                                    f"**DNI:** {det.get('dni_entrevistado','') or '-'} | "
                                    f"**Oficio/Ocupacion:** {det.get('oficio_ocupacion','') or '-'}")
                    num = ficha_t.split("-")[-1] if ficha_t else ""
                    raw = det.get(f"ds{num}_data_v3", "") or ""
                    form_det = {}
                    if raw:
                        try:
                            form_det = json.loads(raw)
                        except (json.JSONDecodeError, TypeError):
                            form_det = {}
                    _ds_render_detalle(ficha_t, form_det)

                    if det.get("observaciones_generales"):
                        st.markdown(f"**Observaciones generales:** {det['observaciones_generales']}")
                    if det.get("archivos_adjuntos"):
                        st.markdown("**Archivos adjuntos:**")
                        carpeta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "adjuntos_ds")
                        for archivo in det["archivos_adjuntos"].split("|"):
                            if archivo.strip():
                                ruta = os.path.join(carpeta, archivo.strip())
                                if os.path.exists(ruta):
                                    with open(ruta, "rb") as fp:
                                        st.download_button(
                                            f"Descargar {archivo.strip().split('_', 1)[-1]}",
                                            fp.read(), archivo.strip(), mime="application/pdf",
                                            key=f"ds_dl_{archivo.strip()}")
                    if st.button("Eliminar este registro", key="ds_eliminar"):
                        db.eliminar_diagnostico_social(dm_ds[sel_ds])
                        _invalidar_cache()
                        st.success("Registro eliminado.")
                        st.rerun()

            st.markdown("---")
            st.markdown("### Resumen por Bloque")
            resumen_ds = db.obtener_resumen_diagnosticos_sociales()
            if resumen_ds:
                st.dataframe(pd.DataFrame([{
                    "Bloque": r["codigo"],
                    "Total Fichas": r.get("total_fichas", "") or "",
                    "Fichas Completadas": r.get("fichas_completadas", "") or "",
                } for r in resumen_ds]), use_container_width=True, hide_index=True)

    # ── GRAFICOS Y RESUMENES ───────────────────────────────────────────
    with tab_graf:
        _tab_graficos_sociales(bm)

    # ── IMPORTAR DESDE EXCEL ───────────────────────────────────────────
    with tab_excel:
        st.markdown("### Plantilla Excel de Diagnostico Social (V4 validada)")
        st.caption("Descargue la plantilla oficial con celdas de validacion (desplegables) "
                   "para el llenado en campo, o suba un archivo llenado para autocompletar.")
        st.markdown("---")
        st.markdown("**1. Descargar Plantilla Oficial para Tecnicos**")
        if st.button("Generar Plantilla Excel V4", type="secondary", key="ds_gen_plantilla"):
            try:
                bloques_data_ds = [(b[1], b[2], b[4], b[5]) for b in BLOQUES_128]
                st.session_state["ds_plantilla_bytes"] = generar_plantilla_ds(None, bloques_data_ds)
                st.success("Plantilla V4 generada correctamente.")
            except Exception as e:
                st.error(f"No se pudo generar la plantilla: {e}")
        if st.session_state.get("ds_plantilla_bytes"):
            st.download_button(
                "Descargar Plantilla Excel V4",
                st.session_state["ds_plantilla_bytes"],
                file_name="Plantilla_Diagnostico_Social_IN_Piura_V4.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="ds_dl_plantilla")

        st.markdown("---")
        st.markdown("**2. Subir Excel Llenado por el Tecnico**")
        st.info("El sistema leera los datos disponibles y autocompletara el formulario "
                "en la pestana **Registro** para su revision antes de guardar.")
        uploaded_excel = st.file_uploader("Seleccionar archivo Excel (.xlsx, max. 25 MB)", type=["xlsx"], key="ds_excel_upload")
        if uploaded_excel is not None and uploaded_excel.size > 25 * 1024 * 1024:
            st.error(f"El archivo '{uploaded_excel.name}' excede el limite de 25 MB.")
            uploaded_excel = None
        if uploaded_excel is not None:
            try:
                resultados = parsear_excel_ds(uploaded_excel)
                if not resultados:
                    st.error("No se detectaron fichas F-DS en el archivo. Verifique el formato.")
                else:
                    st.success(f"Se detectaron {len(resultados)} ficha(s) en el archivo.")
                    for i, res in enumerate(resultados):
                        ficha_det = res.get("ficha", "")
                        datos_res = res.get("datos", {})
                        with st.expander(f"Vista previa: {ficha_det}", expanded=True):
                            cols_prev = st.columns(4)
                            cols_prev[0].markdown(f"**Fecha:** {datos_res.get('fecha', '-')}")
                            cols_prev[1].markdown(f"**Responsable:** {datos_res.get('evaluador', '-')}")
                            cols_prev[2].markdown(f"**Bloque:** {datos_res.get('codigo_bloque', '-')}")
                            cols_prev[3].markdown(f"**Distrito:** {datos_res.get('distrito', '-')}")
                            form_prev = datos_res.get("form", {})
                            n_campos = sum(1 for v in form_prev.values() if v not in ("", None, []))
                            st.markdown(f"**Campos detectados:** {n_campos}")
                        if st.button(f"Autocompletar formulario {ficha_det}", type="primary", key=f"ds_ac_{i}"):
                            pend = mapear_a_session_state(res, bm)
                            st.session_state["_ds_pending_state"] = pend
                            st.session_state["_ds_pending_edit_id"] = None
                            st.success(f"Formulario {ficha_det} autocompletado. "
                                       "Vaya a la pestana **Registro** para revisar y guardar.")
                            st.rerun()
            except Exception as e:
                st.error(f"Error al leer el archivo Excel: {e}")




# ══════════════════════════════════════════════════════════════════════════
# ELEMENTOS EXPUESTOS (AdR / RIESGOS)
# ══════════════════════════════════════════════════════════════════════════
def pagina_elementos_expuestos():
    st.subheader("Elementos Expuestos - Analisis de Riesgos (AdR)")
    st.caption("Formatos F-EE-01 a F-EE-07 | Registro de activos expuestos, vulnerabilidad y peligros.")

    # Obtener bloques
    bloques = db.obtener_bloques()
    if not bloques:
        st.warning("No hay bloques registrados. Registre bloques primero.")
        return

    bloques_map = {b["codigo"]: b["id"] for b in bloques}
    bloques_labels = list(bloques_map.keys())
    bloques_data = [(b["codigo"], b.get("microcuenca", ""), b.get("provincia", ""),
                     b["distrito"]) for b in bloques]

    # ── Toolbar ──────────────────────────────────────────────────────────
    col_dl, col_up = st.columns(2)
    with col_dl:
        st.markdown("**Descargar plantilla Excel F-EE**")
        # Generar la plantilla solo bajo demanda: hacerlo inline la
        # reconstruia con openpyxl en cada rerun de la pagina.
        if st.button("Generar Plantilla F-EE", key="ee_gen_plantilla"):
            st.session_state["ee_plantilla_bytes"] = generar_plantilla_ee(bloques_data)
        if st.session_state.get("ee_plantilla_bytes"):
            st.download_button("Descargar Plantilla F-EE (Excel)",
                               st.session_state["ee_plantilla_bytes"],
                               "Plantilla_Elementos_Expuestos_IN_Piura.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               key="dl_ee")

    with col_up:
        st.markdown("**Importar Excel llenado**")
        archivo = st.file_uploader("Cargar Excel F-EE llenado (max. 25 MB)", type=["xlsx"], key="up_ee")
        if archivo is not None and archivo.size > 25 * 1024 * 1024:
            st.error(f"El archivo '{archivo.name}' excede el limite de 25 MB.")
            archivo = None
        if archivo and st.button("Procesar Excel F-EE", key="btn_proc_ee"):
            try:
                resultados = parsear_excel_ee(archivo.read())
                if resultados:
                    st.success(f"Se procesaron {len(resultados)} fichas: {', '.join(resultados.keys())}")
                    st.session_state["ee_import"] = resultados
                else:
                    st.warning("No se encontraron fichas validas en el archivo.")
            except Exception as e:
                st.error(f"Error al procesar: {e}")

    st.markdown("---")

    # ── Tabs: Registrar / Consultar ──────────────────────────────────────
    tab_reg, tab_con = st.tabs(["Registrar / Editar", "Consultar Registros"])

    with tab_reg:
        fichas_ee = ["F-EE-01", "F-EE-02", "F-EE-03", "F-EE-04", "F-EE-05", "F-EE-06", "F-EE-07"]
        ficha_sel = st.selectbox("Seleccionar Ficha", fichas_ee, key="ee_ficha_sel")

        # Bloque
        bloque_label = st.selectbox("Bloque de Intervencion", [""] + bloques_labels, key="ee_bl")
        if not bloque_label:
            st.info("Seleccione un bloque para continuar.")
            return

        bloque_id = bloques_map[bloque_label]
        bloque_info = next((b for b in bloques if b["id"] == bloque_id), {})

        # Datos generales
        st.markdown("**Datos de Identificacion**")
        c1, c2 = st.columns(2)
        ee_fecha = c1.text_input("Fecha de campo (DD/MM/AAAA)", key="ee_fecha")
        ee_resp = c2.text_input("Responsable / Brigada", key="ee_resp")
        ee_cp = st.text_input("Centro(s) Poblado(s)", key="ee_cp")
        c3, c4, c5 = st.columns(3)
        ee_este = c3.text_input("Coord. UTM Este (m)", value=str(bloque_info.get("utm_este", "")), key="ee_este")
        ee_norte = c4.text_input("Coord. UTM Norte (m)", value=str(bloque_info.get("utm_norte", "")), key="ee_norte")
        ee_alt = c5.text_input("Altitud (msnm)", value=str(bloque_info.get("altitud", "")), key="ee_alt")

        st.markdown("---")
        datos = {}

        # ── F-EE-01: Inventario ──────────────────────────────────────────
        if ficha_sel == "F-EE-01":
            st.markdown("### F-EE-01: INVENTARIO DE ELEMENTOS EXPUESTOS")
            st.caption("Registro general de activos dentro del area de impacto de cada bloque.")
            n_reg = st.number_input("N de elementos a registrar", 1, 20, 5, key="e01_n")
            registros = []
            for i in range(int(n_reg)):
                with st.expander(f"Elemento {i+1}", expanded=(i < 3)):
                    cx = st.columns([2, 2, 2])
                    tipo = cx[0].selectbox("Tipo", [""] + FEE01_TIPO_ELEMENTO, key=f"e01_t{i}")
                    subtipo = cx[1].text_input("Subtipo/Categoria", key=f"e01_st{i}")
                    nombre = cx[2].text_input("Nombre/Identificador", key=f"e01_nm{i}")
                    cx2 = st.columns([1, 1, 1, 1])
                    ub = cx2[0].selectbox("Ubicacion Peligro", [""] + FEE01_UBICACION_PELIGRO, key=f"e01_ub{i}")
                    estado = cx2[1].selectbox("Estado (B/R/M)", [""] + FEE_ESTADO, key=f"e01_es{i}")
                    dist = cx2[2].text_input("Distancia Bloque (m)", key=f"e01_di{i}")
                    benef = cx2[3].text_input("N Beneficiarios", key=f"e01_be{i}")
                    material = st.text_input("Material predominante", key=f"e01_ma{i}")
                    if tipo:
                        registros.append({"tipo_elemento": tipo, "subtipo": subtipo,
                            "nombre": nombre, "ubicacion_peligro": ub, "estado": estado,
                            "distancia_bloque": dist, "beneficiarios": benef, "material": material})
            datos["ee01_registros"] = json.dumps(registros, ensure_ascii=False) if registros else ""

        # ── F-EE-02: Poblacion y Viviendas ───────────────────────────────
        elif ficha_sel == "F-EE-02":
            st.markdown("### F-EE-02: POBLACION Y VIVIENDAS")
            st.caption("Detalle de centros poblados, poblacion y viviendas en area de peligro.")
            n_reg = st.number_input("N de centros poblados", 1, 15, 3, key="e02_n")
            registros = []
            for i in range(int(n_reg)):
                with st.expander(f"Centro Poblado {i+1}", expanded=(i < 2)):
                    cx = st.columns([2, 1, 1, 1])
                    cp_nom = cx[0].text_input("Nombre", key=f"e02_cp{i}")
                    viv_t = cx[1].text_input("N Viviendas Total", key=f"e02_vt{i}")
                    viv_p = cx[2].text_input("Viviendas en Peligro", key=f"e02_vp{i}")
                    pob_t = cx[3].text_input("Poblacion Total", key=f"e02_pt{i}")
                    cx2 = st.columns([1, 1, 1, 1])
                    mat = cx2[0].selectbox("Material Viviendas", [""] + FEE02_MATERIAL_VIV, key=f"e02_mat{i}")
                    agua = cx2[1].selectbox("Agua Potable", [""] + FEE_SI_NO, key=f"e02_ag{i}")
                    elec = cx2[2].selectbox("Electricidad", [""] + FEE_SI_NO, key=f"e02_el{i}")
                    antec = cx2[3].selectbox("Antecedente Evento", [""] + FEE_SI_NO, key=f"e02_ant{i}")
                    cx3 = st.columns([1, 1])
                    nd = cx3[0].selectbox("Nivel Danio Anterior", [""] + FEE_NIVEL_AMB, key=f"e02_nd{i}")
                    obs = cx3[1].text_input("Observaciones", key=f"e02_obs{i}")
                    if cp_nom:
                        registros.append({"centro_poblado": cp_nom, "viviendas_total": viv_t,
                            "viviendas_peligro": viv_p, "poblacion_total": pob_t,
                            "material_viviendas": mat, "agua_potable": agua,
                            "electricidad": elec, "antecedente_evento": antec,
                            "nivel_danio": nd, "observaciones": obs})
            datos["ee02_registros"] = json.dumps(registros, ensure_ascii=False) if registros else ""

        # ── F-EE-03: Infraestructura Publica ─────────────────────────────
        elif ficha_sel == "F-EE-03":
            st.markdown("### F-EE-03: INFRAESTRUCTURA PUBLICA EXPUESTA")
            st.caption("I.E., EESS, locales comunales, infraestructura vial, riego, saneamiento.")
            n_reg = st.number_input("N de infraestructuras", 1, 15, 3, key="e03_n")
            registros = []
            for i in range(int(n_reg)):
                with st.expander(f"Infraestructura {i+1}", expanded=(i < 2)):
                    cx = st.columns([1, 2, 2])
                    sector = cx[0].selectbox("Sector", [""] + FEE03_SECTOR, key=f"e03_sec{i}")
                    tipo_inf = cx[1].text_input("Tipo Infraestructura", key=f"e03_ti{i}")
                    nombre = cx[2].text_input("Nombre/Identificador", key=f"e03_nm{i}")
                    cx2 = st.columns([1, 1, 1, 1])
                    estado = cx2[0].selectbox("Estado", [""] + FEE_ESTADO, key=f"e03_es{i}")
                    nexp = cx2[1].selectbox("Nivel Exposicion", [""] + FEE_NIVEL_AMB, key=f"e03_ne{i}")
                    tpel = cx2[2].selectbox("Tipo Peligro", [""] + FEE_TIPO_PELIGRO, key=f"e03_tp{i}")
                    antd = cx2[3].selectbox("Antecedente Danio", [""] + FEE_SI_NO, key=f"e03_ad{i}")
                    cx3 = st.columns([1, 1])
                    costo = cx3[0].text_input("Costo Estimado Activo (S/)", key=f"e03_ca{i}")
                    crepo = cx3[1].text_input("Costo Reposicion (S/)", key=f"e03_cr{i}")
                    if sector or nombre:
                        registros.append({"sector": sector, "tipo_infraestructura": tipo_inf,
                            "nombre": nombre, "estado": estado, "nivel_exposicion": nexp,
                            "tipo_peligro": tpel, "antecedente_danio": antd,
                            "costo_activo": costo, "costo_reposicion": crepo})
            datos["ee03_registros"] = json.dumps(registros, ensure_ascii=False) if registros else ""

        # ── F-EE-04: Actividades Economicas ──────────────────────────────
        elif ficha_sel == "F-EE-04":
            st.markdown("### F-EE-04: ACTIVIDADES ECONOMICAS Y AGROPECUARIAS")
            st.caption("Parcelas agricolas, ganado, actividades productivas expuestas.")
            n_reg = st.number_input("N de actividades", 1, 14, 3, key="e04_n")
            registros = []
            for i in range(int(n_reg)):
                with st.expander(f"Actividad {i+1}", expanded=(i < 2)):
                    cx = st.columns([1, 2, 1])
                    tipo_act = cx[0].selectbox("Tipo", [""] + FEE04_TIPO_ACTIVIDAD, key=f"e04_ta{i}")
                    desc = cx[1].text_input("Descripcion/Cultivo Principal", key=f"e04_de{i}")
                    area = cx[2].text_input("Area (ha)", key=f"e04_ar{i}")
                    cx2 = st.columns([1, 1, 1, 1])
                    fam = cx2[0].text_input("N Familias Depend.", key=f"e04_fa{i}")
                    val_prod = cx2[1].text_input("Valor Prod. Anual (S/)", key=f"e04_vp{i}")
                    nexp = cx2[2].selectbox("Nivel Exposicion", [""] + FEE_NIVEL_AMB, key=f"e04_ne{i}")
                    tpel = cx2[3].selectbox("Tipo Peligro", [""] + FEE_TIPO_PELIGRO, key=f"e04_tp{i}")
                    cx3 = st.columns([1, 1])
                    perd = cx3[0].selectbox("Perdidas Anteriores", [""] + FEE_SI_NO, key=f"e04_pe{i}")
                    monto = cx3[1].text_input("Monto Perdida (S/)", key=f"e04_mp{i}")
                    if tipo_act:
                        registros.append({"tipo_actividad": tipo_act, "descripcion": desc,
                            "area_ha": area, "familias_dependientes": fam,
                            "valor_produccion": val_prod, "nivel_exposicion": nexp,
                            "tipo_peligro": tpel, "perdidas_anteriores": perd,
                            "monto_perdida": monto})
            datos["ee04_registros"] = json.dumps(registros, ensure_ascii=False) if registros else ""

        # ── F-EE-05: Ecosistema ──────────────────────────────────────────
        elif ficha_sel == "F-EE-05":
            st.markdown("### F-EE-05: ECOSISTEMA (UP) Y ACTIVOS AMBIENTALES")
            st.caption("Estado del ecosistema, cobertura vegetal, suelos, peligros observados.")

            st.markdown("**A. Caracterizacion del Ecosistema**")
            c1, c2 = st.columns(2)
            e05_eco = c1.text_input("Tipo de Ecosistema (MINAM)", key="e05_eco")
            e05_zv = c2.text_input("Zona de Vida (Holdridge)", key="e05_zv")
            e05_cv = st.text_input("Cobertura Vegetal Predominante", key="e05_cv")
            c3, c4 = st.columns(2)
            e05_pcv = c3.text_input("% Cobertura Vegetal Estimado", key="e05_pcv")
            e05_esp = c4.text_input("Especies Dominantes (listar)", key="e05_esp")
            c5, c6 = st.columns(2)
            e05_deg = c5.selectbox("Evidencia de Degradacion", [""] + FEE_SI_NO, key="e05_deg")
            e05_tdeg = c6.selectbox("Tipo de Degradacion", [""] + FEE05_TIPO_DEGRADACION, key="e05_tdeg")
            c7, c8 = st.columns(2)
            e05_ndeg = c7.selectbox("Nivel de Degradacion (1-5)", ["", "1", "2", "3", "4", "5"], key="e05_ndeg")
            e05_pend = c8.text_input("Pendiente Predominante (%)", key="e05_pend")
            c9, c10 = st.columns(2)
            e05_suelo = c9.text_input("Tipo de Suelo Observado", key="e05_suelo")
            e05_prof = c10.text_input("Profundidad Efectiva Estimada (cm)", key="e05_prof")
            c11, c12 = st.columns(2)
            e05_carc = c11.selectbox("Presencia de Carcavas/Surcos", [""] + FEE_SI_NO, key="e05_carc")
            e05_queb = c12.selectbox("Presencia de Quebrada/Cauce", [""] + FEE_SI_NO, key="e05_queb")
            c13, c14 = st.columns(2)
            e05_nqueb = c13.text_input("Nombre de Quebrada", key="e05_nqueb")
            e05_fag = c14.selectbox("Fuentes de Agua Identificadas", [""] + FEE05_FUENTES_AGUA, key="e05_fag")

            datos.update({
                "ee05_tipo_ecosistema": e05_eco, "ee05_zona_vida": e05_zv,
                "ee05_cobertura_vegetal": e05_cv, "ee05_pct_cobertura": e05_pcv,
                "ee05_especies_dominantes": e05_esp, "ee05_evidencia_degradacion": e05_deg,
                "ee05_tipo_degradacion": e05_tdeg, "ee05_nivel_degradacion": e05_ndeg,
                "ee05_pendiente": e05_pend, "ee05_tipo_suelo": e05_suelo,
                "ee05_profundidad_efectiva": e05_prof, "ee05_presencia_carcavas": e05_carc,
                "ee05_presencia_quebrada": e05_queb, "ee05_nombre_quebrada": e05_nqueb,
                "ee05_fuentes_agua": e05_fag,
            })

            st.markdown("**B. Evidencias de Peligros Observados en Campo**")
            n_pel = st.number_input("N de peligros observados", 1, 8, 2, key="e05_np")
            peligros = []
            for i in range(int(n_pel)):
                with st.expander(f"Peligro {i+1}", expanded=(i < 2)):
                    cx = st.columns([2, 3])
                    tp = cx[0].selectbox("Tipo Peligro", [""] + FEE_TIPO_PELIGRO, key=f"e05p_tp{i}")
                    desc = cx[1].text_input("Descripcion Indicio/Evidencia", key=f"e05p_de{i}")
                    cx2 = st.columns([1, 1, 1])
                    niv = cx2[0].selectbox("Nivel Estimado", [""] + FEE_NIVEL_AMB, key=f"e05p_ni{i}")
                    prob = cx2[1].selectbox("Prob. Recurrencia", [""] + FEE05_PROB_RECURRENCIA, key=f"e05p_pr{i}")
                    actam = cx2[2].text_input("Activos Amenazados", key=f"e05p_aa{i}")
                    if tp:
                        peligros.append({"tipo_peligro": tp, "descripcion": desc,
                            "nivel_estimado": niv, "probabilidad": prob,
                            "activos_amenazados": actam})
            datos["ee05_peligros_observados"] = json.dumps(peligros, ensure_ascii=False) if peligros else ""

        # ── F-EE-06: Resumen Vulnerabilidad ──────────────────────────────
        elif ficha_sel == "F-EE-06":
            st.markdown("### F-EE-06: RESUMEN DE VULNERABILIDAD DEL BLOQUE")
            st.caption("Sintesis de exposicion, fragilidad y resiliencia del bloque.")

            st.markdown("**A. Cuantificacion de Elementos Expuestos**")
            cuant = []
            for idx, elem in enumerate(FEE06_ELEMENTOS):
                cx = st.columns([3, 1, 1, 1, 2])
                cx[0].text_input("Elemento", value=elem, disabled=True, key=f"e06e_lb{idx}")
                gab = cx[1].text_input("Gabinete", key=f"e06e_gab{idx}")
                campo = cx[2].text_input("Campo", key=f"e06e_cam{idx}")
                coinc = cx[3].selectbox("Coincide", [""] + FEE_SI_NO, key=f"e06e_co{idx}")
                obs = cx[4].text_input("Obs.", key=f"e06e_obs{idx}")
                cuant.append({"elemento": elem, "cantidad_gabinete": gab,
                    "cantidad_campo": campo, "coincide": coinc, "observaciones": obs})
            datos["ee06_cuantificacion"] = json.dumps(cuant, ensure_ascii=False)

            st.markdown("**B. Valoracion Cualitativa de Vulnerabilidad**")
            valor = []
            for idx, (factor, descriptor) in enumerate(FEE06_FACTORES):
                cx = st.columns([2, 2, 1, 1, 3])
                cx[0].text_input("Factor", value=factor, disabled=True, key=f"e06v_fc{idx}")
                cx[1].text_input("Descriptor", value=descriptor, disabled=True, key=f"e06v_ds{idx}")
                nivel = cx[2].selectbox("Nivel", [""] + FEE06_NIVEL_VULN, key=f"e06v_nv{idx}")
                peso = cx[3].text_input("Peso", key=f"e06v_pe{idx}")
                just = cx[4].text_input("Justificacion", key=f"e06v_ju{idx}")
                valor.append({"factor": factor, "descriptor": descriptor,
                    "nivel": nivel, "peso": peso, "justificacion": just})
            datos["ee06_valoracion_vulnerabilidad"] = json.dumps(valor, ensure_ascii=False)

            st.markdown("---")
            c1, c2 = st.columns(2)
            e06_nvuln = c1.selectbox("NIVEL DE VULNERABILIDAD DEL BLOQUE",
                                      [""] + FEE06_NIVEL_VULN, key="e06_nvuln")
            e06_nriesgo = c2.selectbox("NIVEL DE RIESGO PRELIMINAR DEL BLOQUE",
                                        [""] + FEE06_NIVEL_VULN, key="e06_nriesgo")
            datos["ee06_nivel_vulnerabilidad"] = e06_nvuln
            datos["ee06_nivel_riesgo"] = e06_nriesgo

        # ── F-EE-07: Control Fotografico ─────────────────────────────────
        elif ficha_sel == "F-EE-07":
            st.markdown("### F-EE-07: CONTROL DE REGISTRO FOTOGRAFICO")
            st.caption("Inventario de fotografias georeferenciadas vinculadas a elementos expuestos.")
            n_reg = st.number_input("N de fotos a registrar", 1, 25, 5, key="e07_n")
            registros = []
            for i in range(int(n_reg)):
                with st.expander(f"Foto {i+1}", expanded=(i < 3)):
                    cx = st.columns([1, 1, 1, 2])
                    cod = cx[0].text_input("Codigo Foto", key=f"e07_cf{i}")
                    fecha = cx[1].text_input("Fecha", key=f"e07_fe{i}")
                    hora = cx[2].text_input("Hora", key=f"e07_ho{i}")
                    elem = cx[3].text_input("Elemento Fotografiado", key=f"e07_el{i}")
                    cx2 = st.columns([1, 2])
                    ref = cx2[0].text_input("Formato Ref. (F-EE-XX)", key=f"e07_rf{i}")
                    desc = cx2[1].text_input("Descripcion", key=f"e07_de{i}")
                    if cod:
                        registros.append({"codigo_foto": cod, "fecha": fecha, "hora": hora,
                            "elemento_fotografiado": elem, "formato_referencia": ref,
                            "descripcion": desc})
            datos["ee07_registros"] = json.dumps(registros, ensure_ascii=False) if registros else ""

        # ── Guardar ──────────────────────────────────────────────────────
        st.markdown("---")
        observaciones = st.text_area("Observaciones generales", key="ee_obs", height=80)

        if st.button("Guardar Ficha", type="primary", key="btn_guardar_ee"):
            if not ee_fecha or not ee_resp:
                st.error("Fecha de campo y Responsable son obligatorios.")
                return

            datos_guardar = {
                "bloque_id": bloque_id,
                "ficha": ficha_sel,
                "fecha_campo": ee_fecha,
                "responsable_brigada": ee_resp,
                "centro_poblado": ee_cp,
                "coordenada_este": ee_este,
                "coordenada_norte": ee_norte,
                "altitud": ee_alt,
                "observaciones_generales": observaciones,
            }
            datos_guardar.update(datos)

            try:
                edit_id = st.session_state.get("ee_edit_id")
                if edit_id:
                    db.actualizar_elementos_expuestos(edit_id, datos_guardar)
                    st.success(f"Ficha {ficha_sel} actualizada correctamente.")
                    st.session_state.pop("ee_edit_id", None)
                else:
                    db.insertar_elementos_expuestos(datos_guardar)
                    st.success(f"Ficha {ficha_sel} guardada correctamente.")
                _invalidar_cache()
            except Exception as e:
                if "uq_ee_bloque_ficha_fecha_responsable" in str(e):
                    st.error("Ya existe un registro con ese bloque/ficha/fecha/responsable.")
                else:
                    st.error(f"Error al guardar: {e}")

    # ── Tab Consultar ────────────────────────────────────────────────────
    with tab_con:
        registros_ee = db.obtener_todos_elementos_expuestos()
        if not registros_ee:
            st.info("No hay fichas de Elementos Expuestos registradas.")
            return

        df = pd.DataFrame(registros_ee)

        st.markdown("### Historial de Fichas de Elementos Expuestos")
        st.caption("Haga clic en **Editar** para modificar una ficha existente o en **Eliminar** para descartarla.")
        col_widths_ee = [0.4, 0.9, 0.7, 0.8, 1.0, 0.5, 0.6]
        header_cols = st.columns(col_widths_ee)
        for col, h in zip(header_cols, ["ID", "Bloque", "Ficha", "Fecha", "Responsable", "", ""]):
            col.markdown(f"**{h}**")
        st.markdown("---")
        confirm_del_ee_id = st.session_state.get("ee_confirm_del_id")
        for r in registros_ee:
            row = st.columns(col_widths_ee)
            row[0].write(r.get("id", ""))
            row[1].write(r.get("bloque_codigo", "") or "")
            row[2].write(r.get("ficha", "") or "")
            row[3].write(r.get("fecha_campo", "") or "")
            row[4].write(r.get("responsable_brigada", "") or "")
            if row[5].button("Editar", key=f"edit_ee_row_{r['id']}", type="primary"):
                st.session_state["ee_edit_id"] = r["id"]
                st.session_state["ee_ficha_sel"] = r.get("ficha", "")
                st.session_state.pop("ee_confirm_del_id", None)
                st.rerun()
            if confirm_del_ee_id == r["id"]:
                if row[6].button("Confirmar", key=f"del_confirm_ee_{r['id']}", type="primary"):
                    db.eliminar_elementos_expuestos(r["id"])
                    _invalidar_cache()
                    st.session_state.pop("ee_confirm_del_id", None)
                    st.success(f"Ficha de Elementos Expuestos ID {r['id']} eliminada.")
                    st.rerun()
            else:
                if row[6].button("Eliminar", key=f"del_ee_row_{r['id']}", type="secondary"):
                    st.session_state["ee_confirm_del_id"] = r["id"]
                    st.rerun()
        if confirm_del_ee_id is not None:
            st.warning(f"Confirme la eliminacion de la ficha ID {confirm_del_ee_id} pulsando 'Confirmar' en su fila. "
                       "Esta accion no puede deshacerse.")
            if st.button("Cancelar eliminacion", key="ee_cancel_del"):
                st.session_state.pop("ee_confirm_del_id", None)
                st.rerun()
        st.markdown("---")

        sel_id = st.selectbox("Seleccionar ficha para ver detalle",
                              df["id"].tolist() if "id" in df.columns else [],
                              format_func=lambda x: f"ID {x} - {df[df['id']==x].iloc[0].get('ficha','')} - {df[df['id']==x].iloc[0].get('bloque_codigo','')}",
                              key="ee_sel_det")

        if sel_id:
            det = db.obtener_elementos_expuestos_por_id(sel_id)
            if det:
                ficha_t = det.get("ficha", "")
                st.markdown(f"**{ficha_t}** | Bloque: {det.get('bloque_codigo','')} | "
                            f"Fecha: {det.get('fecha_campo','')} | Resp: {det.get('responsable_brigada','')}")

                # Mostrar datos de tabla segun ficha
                for json_field in ["ee01_registros", "ee02_registros", "ee03_registros",
                                   "ee04_registros", "ee05_peligros_observados",
                                   "ee06_cuantificacion", "ee06_valoracion_vulnerabilidad",
                                   "ee07_registros"]:
                    val = det.get(json_field, "")
                    if val:
                        try:
                            items = json.loads(val)
                            if items:
                                label = json_field.replace("ee0", "F-EE-0").replace("_", " ").upper()
                                with st.expander(label, expanded=True):
                                    st.dataframe(pd.DataFrame(items), use_container_width=True, hide_index=True)
                        except (json.JSONDecodeError, TypeError):
                            pass

                # F-EE-05 campos individuales
                if ficha_t == "F-EE-05":
                    with st.expander("ECOSISTEMA - CARACTERIZACION", expanded=True):
                        for campo, label in [
                            ("ee05_tipo_ecosistema", "Tipo Ecosistema"),
                            ("ee05_zona_vida", "Zona de Vida"),
                            ("ee05_cobertura_vegetal", "Cobertura Vegetal"),
                            ("ee05_pct_cobertura", "% Cobertura"),
                            ("ee05_evidencia_degradacion", "Evidencia Degradacion"),
                            ("ee05_tipo_degradacion", "Tipo Degradacion"),
                            ("ee05_nivel_degradacion", "Nivel Degradacion"),
                            ("ee05_presencia_carcavas", "Carcavas/Surcos"),
                            ("ee05_presencia_quebrada", "Quebrada/Cauce"),
                            ("ee05_fuentes_agua", "Fuentes Agua"),
                        ]:
                            v = det.get(campo, "") or ""
                            if v:
                                st.markdown(f"**{label}:** {v}")

                # F-EE-06 resumen
                if ficha_t == "F-EE-06":
                    c1, c2 = st.columns(2)
                    c1.metric("Nivel Vulnerabilidad", det.get("ee06_nivel_vulnerabilidad", "-"))
                    c2.metric("Nivel Riesgo Preliminar", det.get("ee06_nivel_riesgo", "-"))

                obs = det.get("observaciones_generales", "")
                if obs:
                    st.markdown(f"**Observaciones:** {obs}")

                # Botones de accion
                c1, c2 = st.columns(2)
                if c1.button("Editar", key="btn_edit_ee"):
                    st.session_state["ee_edit_id"] = sel_id
                    st.session_state["ee_ficha_sel"] = ficha_t
                    st.rerun()
                if c2.button("Eliminar", key="btn_del_ee"):
                    db.eliminar_elementos_expuestos(sel_id)
                    st.success("Ficha eliminada.")
                    _invalidar_cache()
                    st.rerun()


# ══════════════════════════════════════════════════════════════════════════
# PRESUPUESTO
# ══════════════════════════════════════════════════════════════════════════
def pagina_presupuesto():
    st.subheader("Presupuesto y Recursos")
    bm = _bloques_map()
    if not bm: st.warning("Registre un bloque primero."); return

    # Inicializar estado de edicion
    if "pres_edit_id" not in st.session_state:
        st.session_state["pres_edit_id"] = None

    edit_id = st.session_state.get("pres_edit_id")

    if edit_id:
        st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                    f'Modo Edicion - Partida ID {edit_id}</div>', unsafe_allow_html=True)
        if st.button("Cancelar edicion", key="pres_cancel_edit"):
            st.session_state["pres_edit_id"] = None
            for k in list(st.session_state.keys()):
                if k.startswith("pres_e_"):
                    del st.session_state[k]
            st.rerun()

    bl = st.selectbox("Bloque", list(bm.keys()), key="pres_bl")
    bid = bm[bl]

    def_cat_idx = 0
    def_desc = ""
    def_mp = 0.0
    def_me = 0.0
    def_fu_idx = 0
    if edit_id:
        def_cat = st.session_state.get("pres_e_cat", "")
        if def_cat and def_cat in CATEGORIAS_PRESUPUESTO:
            def_cat_idx = CATEGORIAS_PRESUPUESTO.index(def_cat)
        def_desc = st.session_state.get("pres_e_desc", "")
        def_mp = float(st.session_state.get("pres_e_mp", 0))
        def_me = float(st.session_state.get("pres_e_me", 0))
        def_fu = st.session_state.get("pres_e_fu", "")
        if def_fu and def_fu in FUENTES_FINANCIAMIENTO:
            def_fu_idx = FUENTES_FINANCIAMIENTO.index(def_fu)

    with st.form("form_pres", clear_on_submit=not edit_id):
        cat = st.selectbox("Categoria", CATEGORIAS_PRESUPUESTO, index=def_cat_idx)
        desc = st.text_input("Descripcion", value=def_desc)
        x1,x2 = st.columns(2)
        mp = x1.number_input("Monto planificado (S/)", 0.0, value=def_mp, format="%.2f")
        me = x2.number_input("Monto ejecutado (S/)", 0.0, value=def_me, format="%.2f")
        fu = st.selectbox("Fuente financiamiento", FUENTES_FINANCIAMIENTO, index=def_fu_idx)
        btn_label = "Actualizar Partida" if edit_id else "Guardar Partida"
        guardar = st.form_submit_button(btn_label, type="primary")
    if guardar:
        try:
            if edit_id:
                db.actualizar_presupuesto(edit_id, cat, desc, mp, me, fu)
                _invalidar_cache()
                st.session_state["pres_edit_id"] = None
                for k in list(st.session_state.keys()):
                    if k.startswith("pres_e_"):
                        del st.session_state[k]
                st.success("Partida actualizada."); st.rerun()
            else:
                # Verificar duplicados
                existentes = db.obtener_presupuesto_por_bloque(bid)
                dup = [e for e in existentes if e["categoria"] == cat and e["descripcion"] == desc]
                if dup:
                    st.warning(f"Ya existe una partida '{cat} - {desc}' para este bloque. "
                               f"Use 'Editar' en la tabla para modificarla.")
                else:
                    db.insertar_presupuesto(bid, cat, desc, mp, me, fu)
                    _invalidar_cache()
                    st.success("Partida registrada."); st.rerun()
        except Exception as e: st.error(f"Error: {e}")
    st.markdown("---")
    st.markdown("**Partidas del Bloque**")
    st.caption("Haga clic en **Editar** para modificar una partida existente.")
    pa = db.obtener_presupuesto_por_bloque(bid)
    if pa:
        tp = sum(p["monto_planificado"] for p in pa)
        te = sum(p["monto_ejecutado"] for p in pa)
        # Tabla con botones de edicion
        header_cols = st.columns([0.5, 1.2, 1.2, 1, 1, 0.7, 1, 0.5])
        for col, h in zip(header_cols, ["ID", "Categoria", "Descripcion", "Planificado", "Ejecutado", "%Ejec", "Fuente", ""]):
            col.markdown(f"**{h}**")
        st.markdown("---")
        for p in pa:
            row = st.columns([0.5, 1.2, 1.2, 1, 1, 0.7, 1, 0.5])
            row[0].write(p["id"])
            row[1].write(p["categoria"])
            row[2].write(p["descripcion"])
            row[3].write(f"S/ {p['monto_planificado']:,.2f}")
            row[4].write(f"S/ {p['monto_ejecutado']:,.2f}")
            row[5].write(f"{(p['monto_ejecutado']/p['monto_planificado']*100) if p['monto_planificado']>0 else 0:.1f}%")
            row[6].write(p["fuente_financiamiento"])
            if row[7].button("Editar", key=f"edit_pres_{p['id']}", type="primary"):
                st.session_state["pres_edit_id"] = p["id"]
                st.session_state["pres_e_cat"] = p["categoria"]
                st.session_state["pres_e_desc"] = p["descripcion"]
                st.session_state["pres_e_mp"] = p["monto_planificado"]
                st.session_state["pres_e_me"] = p["monto_ejecutado"]
                st.session_state["pres_e_fu"] = p["fuente_financiamiento"]
                st.rerun()
        st.markdown("---")
        st.info(f"**Subtotal:** Plan S/ {tp:,.2f} | Ejec S/ {te:,.2f} | {(te/tp*100) if tp>0 else 0:.1f}%")
        pm = {f"ID {p['id']} - {p['categoria']}":p["id"] for p in pa}
        sp = st.selectbox("Partida a eliminar",[""]+list(pm.keys()),key="del_pa")
        if sp and sp in pm and st.button("Eliminar partida"):
            db.eliminar_presupuesto(pm[sp]); _invalidar_cache(); st.success("Eliminada."); st.rerun()
    st.markdown("---")
    st.markdown("**Resumen General**")
    rp = db.obtener_resumen_presupuesto()
    if rp:
        def _fmt_money(v):
            try:
                return f"S/ {float(v):,.2f}" if v not in (None, "", 0, 0.0) else ""
            except (TypeError, ValueError):
                return ""
        def _fmt_pct(num, den):
            try:
                num_f = float(num or 0); den_f = float(den or 0)
                if den_f <= 0: return ""
                return f"{(num_f/den_f*100):.1f}%"
            except (TypeError, ValueError):
                return ""
        def _fmt_count(v):
            try:
                iv = int(v); return iv if iv else ""
            except (TypeError, ValueError):
                return ""
        st.dataframe(pd.DataFrame([{
            "Codigo": r["codigo"],
            "Planificado": _fmt_money(r.get("total_planificado")),
            "Ejecutado": _fmt_money(r.get("total_ejecutado")),
            "%Ejec": _fmt_pct(r.get("total_ejecutado"), r.get("total_planificado")),
            "Partidas": _fmt_count(r.get("num_partidas")),
        } for r in rp]),
            use_container_width=True, hide_index=True)
        t = db.obtener_presupuesto_total()
        pt,et = t["total_planificado"],t["total_ejecutado"]
        st.success(f"**TOTAL:** Plan S/ {pt:,.2f} | Ejec S/ {et:,.2f} ({(et/pt*100) if pt>0 else 0:.1f}%) | Saldo S/ {pt-et:,.2f}")

# ══════════════════════════════════════════════════════════════════════════
# CRONOGRAMA
# ══════════════════════════════════════════════════════════════════════════
def pagina_cronograma():
    st.subheader("Cronograma de Actividades")
    bm = _bloques_map()
    if not bm: st.warning("Registre un bloque primero."); return

    # Inicializar estado de edicion
    if "crono_edit_id" not in st.session_state:
        st.session_state["crono_edit_id"] = None

    edit_id = st.session_state.get("crono_edit_id")

    if edit_id:
        st.markdown('<div class="edit-mode-banner"><span class="icon">&#9998;</span> '
                    f'Modo Edicion - Actividad ID {edit_id}</div>', unsafe_allow_html=True)
        if st.button("Cancelar edicion", key="crono_cancel_edit"):
            st.session_state["crono_edit_id"] = None
            for k in list(st.session_state.keys()):
                if k.startswith("crono_e_"):
                    del st.session_state[k]
            st.rerun()

    bl = st.selectbox("Bloque", list(bm.keys()), key="crono_bl")
    bid = bm[bl]

    def_act_idx = 0
    def_ip = datetime.now()
    def_fp = datetime.now()
    def_ir = None
    def_fr = None
    def_av = 0.0
    def_ea_idx = 0
    def_re = ""
    def_ob = ""
    if edit_id:
        def_act = st.session_state.get("crono_e_act", "")
        if def_act and def_act in ACTIVIDADES_TIPO:
            def_act_idx = ACTIVIDADES_TIPO.index(def_act)
        try:
            def_ip = datetime.strptime(st.session_state.get("crono_e_ip", ""), "%Y-%m-%d")
        except (ValueError, TypeError):
            pass
        try:
            def_fp = datetime.strptime(st.session_state.get("crono_e_fp", ""), "%Y-%m-%d")
        except (ValueError, TypeError):
            pass
        ir_str = st.session_state.get("crono_e_ir", "") or ""
        fr_str = st.session_state.get("crono_e_fr", "") or ""
        try:
            def_ir = datetime.strptime(ir_str, "%Y-%m-%d").date() if ir_str else None
        except (ValueError, TypeError):
            def_ir = None
        try:
            def_fr = datetime.strptime(fr_str, "%Y-%m-%d").date() if fr_str else None
        except (ValueError, TypeError):
            def_fr = None
        def_av = float(st.session_state.get("crono_e_av", 0))
        def_ea = st.session_state.get("crono_e_ea", "")
        if def_ea and def_ea in ESTADOS_ACTIVIDAD:
            def_ea_idx = ESTADOS_ACTIVIDAD.index(def_ea)
        def_re = st.session_state.get("crono_e_re", "")
        def_ob = st.session_state.get("crono_e_ob", "")

    with st.form("form_crono", clear_on_submit=not edit_id):
        act = st.selectbox("Actividad", ACTIVIDADES_TIPO, index=def_act_idx)
        x1,x2 = st.columns(2)
        ip = x1.date_input("Inicio planificado", value=def_ip,
                           min_value=FECHA_MIN_PROYECTO, max_value=FECHA_MAX_PROYECTO,
                           help="Fecha de inicio planificada")
        fp = x2.date_input("Fin planificado", value=def_fp,
                           min_value=FECHA_MIN_PROYECTO, max_value=FECHA_MAX_PROYECTO,
                           help="Fecha de fin planificada")
        x3,x4 = st.columns(2)
        ir = x3.date_input("Inicio real", value=def_ir,
                           min_value=FECHA_MIN_PROYECTO, max_value=date.today(),
                           help="Fecha de inicio real (dejar vacio si no ha iniciado)")
        fr = x4.date_input("Fin real", value=def_fr,
                           min_value=FECHA_MIN_PROYECTO, max_value=date.today(),
                           help="Fecha de fin real (dejar vacio si no ha finalizado)")
        x5,x6 = st.columns(2)
        av = x5.number_input("Avance %", 0.0, 100.0, def_av)
        ea = x6.selectbox("Estado", ESTADOS_ACTIVIDAD, index=def_ea_idx)
        re = st.text_input("Responsable", value=def_re); ob = st.text_area("Observaciones", value=def_ob)
        btn_label = "Actualizar Actividad" if edit_id else "Guardar Actividad"
        guardar = st.form_submit_button(btn_label, type="primary")
    if guardar:
        ir_str = ir.strftime("%Y-%m-%d") if ir else ""
        fr_str = fr.strftime("%Y-%m-%d") if fr else ""
        try:
            if edit_id:
                db.actualizar_actividad(actividad_id=edit_id, actividad=act,
                    fecha_inicio_plan=ip.strftime("%Y-%m-%d"), fecha_fin_plan=fp.strftime("%Y-%m-%d"),
                    fecha_inicio_real=ir_str, fecha_fin_real=fr_str, porcentaje_avance=av,
                    responsable=re, observaciones=ob, estado=ea)
                _invalidar_cache()
                st.session_state["crono_edit_id"] = None
                for k in list(st.session_state.keys()):
                    if k.startswith("crono_e_"):
                        del st.session_state[k]
                st.success("Actividad actualizada."); st.rerun()
            else:
                db.insertar_actividad(bloque_id=bid, actividad=act,
                    fecha_inicio_plan=ip.strftime("%Y-%m-%d"), fecha_fin_plan=fp.strftime("%Y-%m-%d"),
                    fecha_inicio_real=ir_str, fecha_fin_real=fr_str, porcentaje_avance=av,
                    responsable=re, observaciones=ob, estado=ea)
                _invalidar_cache()
                st.success("Actividad registrada."); st.rerun()
        except Exception as e: st.error(f"Error: {e}")
    st.markdown("---")
    st.markdown("**Actividades del Bloque**")
    st.caption("Haga clic en **Editar** para modificar una actividad existente.")
    acs = db.obtener_actividades_por_bloque(bid)
    if acs:
        header_cols = st.columns([0.4, 1.2, 0.8, 0.8, 0.7, 0.7, 0.6, 0.7, 0.8, 0.5])
        for col, h in zip(header_cols, ["ID", "Actividad", "Inicio", "Fin", "Ini.Real", "Fin Real", "Avance", "Estado", "Resp.", ""]):
            col.markdown(f"**{h}**")
        st.markdown("---")
        for a in acs:
            row = st.columns([0.4, 1.2, 0.8, 0.8, 0.7, 0.7, 0.6, 0.7, 0.8, 0.5])
            row[0].write(a["id"])
            row[1].write(a["actividad"])
            row[2].write(a["fecha_inicio_plan"])
            row[3].write(a["fecha_fin_plan"])
            row[4].write(a["fecha_inicio_real"] or "-")
            row[5].write(a["fecha_fin_real"] or "-")
            row[6].write(f"{a['porcentaje_avance']:.0f}%")
            row[7].write(a["estado"])
            row[8].write(a["responsable"])
            if row[9].button("Editar", key=f"edit_crono_{a['id']}", type="primary"):
                st.session_state["crono_edit_id"] = a["id"]
                st.session_state["crono_e_act"] = a["actividad"]
                st.session_state["crono_e_ip"] = a["fecha_inicio_plan"]
                st.session_state["crono_e_fp"] = a["fecha_fin_plan"]
                st.session_state["crono_e_ir"] = a["fecha_inicio_real"] or ""
                st.session_state["crono_e_fr"] = a["fecha_fin_real"] or ""
                st.session_state["crono_e_av"] = a["porcentaje_avance"]
                st.session_state["crono_e_ea"] = a["estado"]
                st.session_state["crono_e_re"] = a["responsable"]
                st.session_state["crono_e_ob"] = a.get("observaciones", "") or ""
                st.rerun()
        st.markdown("---")
        am = {f"ID {a['id']} - {a['actividad']}":a["id"] for a in acs}
        sa = st.selectbox("Actividad a eliminar",[""]+list(am.keys()),key="del_ac")
        if sa and sa in am and st.button("Eliminar actividad"):
            db.eliminar_actividad(am[sa]); _invalidar_cache(); st.success("Eliminada."); st.rerun()
    st.markdown("---")
    st.markdown("**Cronograma General**")
    fe = st.selectbox("Filtrar estado",["Todos"]+ESTADOS_ACTIVIDAD,key="f_crono")
    ta = db.obtener_todas_actividades()
    if ta:
        if fe != "Todos": ta = [a for a in ta if a.get("estado")==fe]
        st.dataframe(pd.DataFrame([{"Bloque":a.get("bloque_codigo",""),
            "Actividad":a["actividad"],"Inicio":a["fecha_inicio_plan"],
            "Fin":a["fecha_fin_plan"],"Avance":f"{a['porcentaje_avance']:.0f}%",
            "Estado":a["estado"],"Responsable":a["responsable"]} for a in ta]),
            use_container_width=True, hide_index=True)
        rc = db.obtener_resumen_cronograma(); tt = sum(rc.values())
        co = rc.get("Completado",0)
        st.info(f"Total: {tt} | Programadas: {rc.get('Programado',0)} | En ejecucion: {rc.get('En ejecucion',0)} | Completadas: {co} ({(co/tt*100) if tt>0 else 0:.0f}%) | Retrasadas: {rc.get('Retrasado',0)}")

# ══════════════════════════════════════════════════════════════════════════
# GEORREFERENCIACION
# ══════════════════════════════════════════════════════════════════════════
def pagina_georreferenciacion():
    st.subheader("Georreferenciacion")
    bloques = db.obtener_bloques()
    f1,f2 = st.columns(2)
    fe = f1.selectbox("Filtrar estado",["Todos","Pendiente","En progreso","Verificado"],key="ge")
    ft = f2.selectbox("Filtrar tipo",["Todos"]+TIPOS_INTERVENCION,key="gt")
    bf = bloques
    if fe != "Todos": bf = [b for b in bf if b.get("estado")==fe]
    if ft != "Todos": bf = [b for b in bf if b.get("tipo_intervencion")==ft]
    cm,ci = st.columns([3,1])
    with cm:
        if bf:
            md = []
            for b in bf:
                try:
                    utm_e = b.get("utm_este", 0) or 0
                    utm_n = b.get("utm_norte", 0) or 0
                    # Fallback: si las coords en BD son 0, usar las de BLOQUES_128_MAP
                    if utm_e == 0 or utm_n == 0:
                        datos_b79 = BLOQUES_128_MAP.get(b.get("codigo", ""), {})
                        utm_e = datos_b79.get("utm_este", 0)
                        utm_n = datos_b79.get("utm_norte", 0)
                    # Filtrar bloques sin coordenadas validas
                    if utm_e == 0 or utm_n == 0:
                        continue
                    zona_str = b.get("utm_zona", "17S") or "17S"
                    zn = int(zona_str.replace("S","").replace("N",""))
                    he = "S" if "S" in zona_str else "N"
                    la,lo = utm_a_latlon(float(utm_e),float(utm_n),zn,he)
                    # Validar que las coordenadas estan en rango razonable para Peru
                    if not (-20 <= la <= 0 and -82 <= lo <= -68):
                        continue
                    co = COLORES_ESTADO.get(b.get("estado",""),[149,165,166])
                    # Obtener centros poblados y comunidades del bloque
                    cp_info = _cp_bloque(b.get("codigo", ""))
                    cp_lista = ", ".join(cp_info.get("centros_poblados", [])) or "—"
                    cc_lista = ", ".join(cp_info.get("comunidades_campesinas", [])) or "—"
                    pob = cp_info.get("poblacion_total", 0)
                    viviendas = cp_info.get("viviendas", 0)
                    md.append({"lat":la,"lon":lo,"codigo":b["codigo"],
                        "tipo":b["tipo_intervencion"],"estado":b["estado"],
                        "area":b["area_hectareas"],"distrito":b.get("distrito",""),
                        "provincia":b.get("provincia",""),
                        "centros_poblados":cp_lista,"comunidades":cc_lista,
                        "poblacion":pob,"viviendas":viviendas,
                        "r":co[0],"g":co[1],"b":co[2]})
                except (ValueError,KeyError,TypeError): pass
            if md:
                import pydeck as pdk
                df = pd.DataFrame(md)
                layer = pdk.Layer("ScatterplotLayer",data=df,
                    get_position=["lon","lat"],get_color=["r","g","b",200],
                    get_radius=300,pickable=True)
                vs = pdk.ViewState(latitude=df["lat"].mean(),longitude=df["lon"].mean(),zoom=10)
                st.pydeck_chart(pdk.Deck(layers=[layer],initial_view_state=vs,
                    tooltip={"text":"Codigo: {codigo}\nTipo: {tipo}\nEstado: {estado}\nArea: {area} ha\nDistrito: {distrito} ({provincia})\nCC.PP.: {centros_poblados}\nComunidades: {comunidades}\nPoblacion: {poblacion} hab.\nViviendas: {viviendas}"}))
                st.caption(":red_circle: Pendiente | :orange_circle: En progreso | :green_circle: Verificado")
                # Tabla de ubicacion con centros poblados y comunidades
                st.markdown("---")
                st.markdown("**Ubicacion, Centros Poblados y Comunidades Campesinas**")
                df_ubic = df[["codigo","distrito","provincia","area","centros_poblados",
                              "comunidades","poblacion","viviendas"]].copy()
                df_ubic.columns = ["Bloque","Distrito","Provincia","Superficie (ha)",
                                   "Centros Poblados","Comunidades Campesinas",
                                   "Poblacion","Viviendas"]
                st.dataframe(df_ubic, use_container_width=True, hide_index=True)
            else: st.info("No se pudieron convertir coordenadas.")
        else: st.info("Sin bloques para los filtros.")
    with ci:
        st.markdown("**Resumen**")
        st.metric("Bloques",len(bf))
        st.metric("Area",f"{sum(b.get('area_hectareas',0) for b in bf):.4f} ha")
        st.markdown("---")
        st.markdown("**Conversor UTM <-> Lat/Lon**")
        t1,t2 = st.tabs(["UTM->LatLon","LatLon->UTM"])
        with t1:
            with st.form("conv_u"):
                ce = st.text_input("Este",key="ce"); cn = st.text_input("Norte",key="cn")
                cz = st.text_input("Zona","17S",key="cz")
                if st.form_submit_button("Convertir") and ce and cn:
                    try:
                        zn = int(cz.replace("S","").replace("N",""))
                        he = "S" if "S" in cz.upper() else "N"
                        la,lo = utm_a_latlon(float(ce),float(cn),zn,he)
                        st.success(f"Lat: {la:.8f}\nLon: {lo:.8f}")
                    except: st.error("Valores invalidos.")
        with t2:
            with st.form("conv_l"):
                cl = st.text_input("Latitud",key="cl"); co = st.text_input("Longitud",key="co")
                if st.form_submit_button("Convertir") and cl and co:
                    try:
                        e,n,z = latlon_a_utm(float(cl),float(co))
                        st.success(f"Este: {e:.2f}\nNorte: {n:.2f}\nZona: {z}")
                    except: st.error("Valores invalidos.")

# ══════════════════════════════════════════════════════════════════════════
# ODK / KoBoToolbox
# ══════════════════════════════════════════════════════════════════════════
def _secreto(nombre, defecto=""):
    """Lee un valor de st.secrets sin romper si no existe."""
    try:
        return str(st.secrets.get(nombre, defecto) or defecto)
    except Exception:
        return defecto


def _odk_vista_previa(preparados, origen, uid="", cliente=None):
    """Guarda la vista previa en sesion; nada se escribe hasta confirmar."""
    st.session_state["odk_preview"] = {"preparados": preparados, "origen": origen,
                                       "uid": uid, "cliente": cliente}


def _odk_mostrar_vista_previa():
    pv = st.session_state.get("odk_preview")
    if not pv:
        return
    preparados = pv["preparados"]
    n_nuevos = sum(p["estado"] == "listo" for p in preparados)
    n_dup = sum(p["estado"] == "duplicado" for p in preparados)
    n_err = sum(p["estado"] == "error" for p in preparados)
    n_alert = sum(bool(p["alertas"]) and p["estado"] == "listo" for p in preparados)
    st.markdown("#### Vista previa (aun no se ha guardado nada)")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Nuevos", n_nuevos)
    c2.metric("Ya importados", n_dup)
    c3.metric("Rechazados", n_err)
    c4.metric("Nuevos con alertas", n_alert)
    df = pd.DataFrame(odk_resumen_preparacion(preparados))
    st.dataframe(df, use_container_width=True, hide_index=True)
    if n_err:
        st.warning("Los envios rechazados no se guardan (bloque inexistente o retirado, "
                   "falta fecha o verificador). Corrijalos en KoBo y vuelva a importar.")
    descargar = False
    if pv["cliente"] is not None:
        descargar = st.checkbox("Descargar fotos de los envios nuevos", value=True,
                                key="odk_descargar_fotos")
    b1, b2 = st.columns(2)
    if b1.button(f"Registrar {n_nuevos} envio(s) nuevo(s)", type="primary",
                 disabled=n_nuevos == 0, key="odk_confirmar"):
        barra = st.progress(0.0, text="Registrando...")
        r = odk_registrar_envios(
            preparados, cliente=pv["cliente"], descargar_fotos=descargar,
            progreso=lambda i, t: barra.progress(i / max(t, 1),
                                                 text=f"Registrando {i}/{t}"))
        barra.empty()
        _invalidar_cache()
        st.session_state.pop("odk_preview", None)
        st.session_state["odk_ultimo_resultado"] = r
        st.rerun()
    if b2.button("Descartar vista previa", key="odk_descartar"):
        st.session_state.pop("odk_preview", None)
        st.rerun()


def pagina_odk():
    st.subheader("ODK / KoBoToolbox - Verificacion de campo (Paso 6)")
    st.caption("La importacion solo AGREGA registros nuevos: no crea, modifica ni borra "
               "bloques, y no duplica envios ya importados.")

    r = st.session_state.pop("odk_ultimo_resultado", None)
    if r:
        (st.success if not r["errores"] else st.warning)(odk_texto_resultado(r))
        if r.get("inspecciones_vinculadas"):
            st.info(f"{r['inspecciones_vinculadas']} envio(s) se enlazaron a una inspeccion "
                    "ya existente del mismo bloque, fecha y verificador (sin modificarla).")
        if r["errores"]:
            with st.expander(f"{len(r['errores'])} observacion(es)"):
                for e in r["errores"]:
                    st.write(f"- {e}")

    t_form, t_api, t_arch, t_reg = st.tabs([
        "1. Formulario", "2. Importar desde KoBo (API)",
        "3. Importar archivo CSV / Excel", "4. Verificaciones registradas"])

    # ── 1. Formulario ────────────────────────────────────────────────────
    with t_form:
        bloques = _cached_obtener_bloques(_cache_version())
        st.markdown(
            f"Genera el XLSForm del **Paso 6** con la lista cerrada de **{len(bloques)} bloques** "
            "activos (filtrados por distrito) y secciones de accesibilidad real, riesgo social, "
            "uso actual del suelo, evidencia de movimientos en masa, titulares de predios y "
            "dictamen. Funciona sin internet en ODK Collect / KoBoCollect.")
        if st.button("Generar formulario XLSForm", type="primary", key="odk_gen"):
            try:
                ruta = generar_xlsform(bloques=bloques)
                with open(ruta, "rb") as f:
                    st.session_state["odk_xlsform"] = (os.path.basename(ruta), f.read())
            except Exception as e:
                st.error(f"Error: {e}")
        if st.session_state.get("odk_xlsform"):
            nombre, data = st.session_state["odk_xlsform"]
            st.download_button("Descargar XLSForm", data, nombre,
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        st.info("Suba el archivo a KoBoToolbox como **formulario nuevo**: su identificador "
                f"(`{ODK_FORM_ID}`) es distinto del anterior, asi que los envios ya "
                "recolectados con el formulario anterior se conservan y siguen importandose.")
        enc = odk_encabezados_csv()
        buf = io.StringIO()
        csv.writer(buf).writerow(enc)
        st.download_button("Descargar plantilla CSV (carga manual)", buf.getvalue(),
                           "plantilla_in_piura_paso6.csv", "text/csv")

    # ── 2. API ───────────────────────────────────────────────────────────
    with t_api:
        sv_def = _secreto("KOBO_SERVER", "https://kf.kobotoolbox.org")
        servidores = ["https://kf.kobotoolbox.org", "https://eu.kobotoolbox.org",
                      "https://kobo.humanitarianresponse.info"]
        if sv_def not in servidores:
            servidores.insert(0, sv_def)
        sv = st.selectbox("Servidor", servidores, index=servidores.index(sv_def))
        token_sec = _secreto("KOBO_TOKEN")
        if token_sec:
            st.caption("Token API leido de la configuracion segura (secrets).")
            token = token_sec
        else:
            token = st.text_input(
                "Token API", type="password",
                help="Se usa solo en esta sesion y no se guarda. Para no escribirlo cada "
                     "vez, agregue KOBO_TOKEN en los secrets de Streamlit.")
        if st.button("Conectar y listar formularios", key="odk_listar"):
            if not token:
                st.warning("Ingrese el token.")
            else:
                try:
                    cl = KoBoClient(sv, token)
                    ok_, msg = cl.test_conexion()
                    if not ok_:
                        st.error(msg)
                    else:
                        st.session_state["odk_cliente"] = cl
                        st.session_state["odk_formularios"] = cl.listar_formularios()
                except Exception as e:
                    st.error(f"Error: {e}")
        forms = st.session_state.get("odk_formularios")
        if forms is not None:
            if not forms:
                st.info("La cuenta no tiene formularios.")
            else:
                uid_def = _secreto("KOBO_FORM_UID")
                opciones = {f"{f['nombre']}  ·  {f['envios']} envios  ·  {f['uid']}": f["uid"]
                            for f in forms}
                etiquetas = list(opciones)
                idx = next((i for i, k in enumerate(etiquetas) if opciones[k] == uid_def), 0)
                sel = st.selectbox("Formulario", etiquetas, index=idx)
                if st.button("Descargar envios y revisar", type="primary", key="odk_bajar"):
                    try:
                        with st.spinner("Descargando todos los envios (todas las paginas)..."):
                            cl = st.session_state["odk_cliente"]
                            envios = cl.obtener_envios(opciones[sel])
                            prep = odk_preparar_envios(envios, "api", opciones[sel])
                        _odk_vista_previa(prep, "api", opciones[sel], cl)
                    except Exception as e:
                        st.error(f"Error: {e}")
        if st.session_state.get("odk_preview", {}).get("origen") == "api":
            _odk_mostrar_vista_previa()

    # ── 3. Archivo ───────────────────────────────────────────────────────
    with t_arch:
        st.markdown("Exporte desde KoBo en **CSV o XLS** con la opcion *Valores y "
                    "encabezados XML*. Se aceptan CSV separados por coma o punto y coma.")
        uf = st.file_uploader("Archivo exportado", type=["csv", "xlsx"], key="odk_archivo")
        if uf and st.button("Revisar archivo", type="primary", key="odk_revisar"):
            sufijo = os.path.splitext(uf.name)[1].lower()
            with tempfile.NamedTemporaryFile(suffix=sufijo, delete=False) as tmp:
                tmp.write(uf.getvalue())
                tp = tmp.name
            try:
                envios = odk_leer_archivo(tp)
                _odk_vista_previa(odk_preparar_envios(envios, "csv"), "csv")
            except Exception as e:
                st.error(f"No se pudo leer el archivo: {e}")
            finally:
                os.unlink(tp)
        if st.session_state.get("odk_preview", {}).get("origen") == "csv":
            _odk_mostrar_vista_previa()

    # ── 4. Registradas ───────────────────────────────────────────────────
    with t_reg:
        try:
            verifs = db.obtener_verificaciones_odk()
        except Exception as e:
            st.error(f"No se pudo leer las verificaciones: {e}")
            verifs = []
        if not verifs:
            st.info("Aun no hay verificaciones importadas.")
        else:
            df = pd.DataFrame(verifs)
            c1, c2 = st.columns(2)
            dictamenes = sorted(x for x in df["dictamen"].dropna().unique() if x)
            f_dict = c1.multiselect("Dictamen", dictamenes)
            solo_alertas = c2.checkbox("Solo con alertas")
            if f_dict:
                df = df[df["dictamen"].isin(f_dict)]
            if solo_alertas:
                df = df[df["alertas"].fillna("") != ""]
            cols = ["codigo_bloque", "distrito", "fecha_visita", "inspector", "dictamen",
                    "accesibilidad", "riesgo_social", "uso_suelo_predominante",
                    "evidencia_mm", "aceptacion_titular", "utm_este", "utm_norte",
                    "utm_fuente", "coord_valida", "distancia_centroide_m", "n_fotos",
                    "alertas"]
            st.dataframe(df[cols], use_container_width=True, hide_index=True)
            st.download_button("Descargar tabla (CSV)",
                               df.drop(columns=["fotos"], errors="ignore")
                                 .to_csv(index=False).encode("utf-8-sig"),
                               "verificaciones_paso6.csv", "text/csv")
            etiquetas = {f"{v['codigo_bloque']} · {v['fecha_visita']} · {v['inspector']} (#{v['id']})": v
                         for v in df.to_dict("records")}
            if etiquetas:
                sel = st.selectbox("Ver detalle", list(etiquetas))
                v = etiquetas[sel]
                d1, d2 = st.columns(2)
                d1.markdown(
                    f"**Bloque:** {v['codigo_bloque']}  \n**Dictamen:** {v['dictamen'] or '-'}  \n"
                    f"**Accesibilidad:** {v['accesibilidad'] or '-'} ({v['tipo_acceso'] or '-'})  \n"
                    f"**Riesgo social:** {v['riesgo_social'] or '-'} {v['riesgo_social_factores'] or ''}  \n"
                    f"**Uso del suelo:** {v['uso_suelo_predominante'] or '-'}  \n"
                    f"**Mov. en masa:** {v['evidencia_mm'] or '-'} {v['tipos_mm'] or ''} {v['magnitud_mm'] or ''}  \n"
                    f"**Titulares:** {v['tenencia'] or '-'} · {v['aceptacion_titular'] or '-'}")
                if v.get("utm_este") is not None and not pd.isna(v.get("utm_este")):
                    d2.markdown(f"**UTM 17S:** {v['utm_este']:,.1f} E / {v['utm_norte']:,.1f} N "
                                f"({v['utm_fuente']})")
                d2.markdown(f"**Observaciones:** {v['observaciones'] or '-'}  \n"
                            f"**Alertas:** {v['alertas'] or 'ninguna'}")
                fotos = db.obtener_adjuntos_odk(v["id"])
                if fotos:
                    cols_f = st.columns(min(3, len(fotos)))
                    for i, fa in enumerate(fotos):
                        contenido = db.obtener_contenido_adjunto_odk(fa["id"])
                        if contenido:
                            cols_f[i % len(cols_f)].image(
                                contenido, caption=f"{fa['campo']} · {fa['nombre_archivo']}")

    with st.expander("Guia rapida"):
        st.markdown(f"""
1. **Generar** el XLSForm (pestana 1) y subirlo a KoBoToolbox como formulario nuevo; **desplegar**.
2. **Recolectar** con KoBoCollect / ODK Collect (sin internet). El GPS se captura en el bloque.
3. **Enviar** al servidor cuando haya señal.
4. **Importar** por API (pestana 2) o con el archivo exportado (pestana 3): revise la
   vista previa y confirme. Solo se guardan los envios nuevos.
5. La UTM 17S se calcula del GPS del celular (pyproj, EPSG:32717) y se valida en el rango
   450,000–750,000 E / 9,300,000–9,600,000 N. Se alerta si el punto queda a mas de
   {ODK_DIST_ALERTA:,} m del centroide del bloque o si hay mas de {ODK_MAX_PREDIOS} predios.
6. Para no escribir el token cada vez, agregue en los *secrets* de Streamlit:
   `KOBO_TOKEN = "..."`, opcionalmente `KOBO_SERVER` y `KOBO_FORM_UID`.""")

# ══════════════════════════════════════════════════════════════════════════
# REPORTES
# ══════════════════════════════════════════════════════════════════════════
def pagina_reportes():
    st.subheader("Generacion de Reportes")
    bm = _bloques_map()
    st.markdown("### Ficha de Inspeccion (PDF)")
    if bm:
        bl = st.selectbox("Bloque",list(bm.keys()),key="rep_bl")
        if st.button("Generar Ficha PDF", type="primary"):
            try:
                ruta = reports.generar_ficha_pdf(bm[bl])
                with open(ruta,"rb") as f: data = f.read()
                st.download_button("Descargar PDF",data,os.path.basename(ruta),"application/pdf")
                st.success("PDF generado.")
            except Exception as e: st.error(f"Error: {e}")
    else: st.info("Registre bloques primero.")
    st.markdown("---")
    st.markdown("### Fichas de Diagnostico por Bloque (PDF)")
    st.caption("Ficha independiente por bloque: una para el Diagnostico Territorial "
               "(F-DT-01..05) y otra para el Diagnostico Social (F-DS-01..07) con la "
               "relacion de centros poblados del bloque.")
    if bm:
        c_rep1, c_rep2, c_rep3 = st.columns([2, 1, 1])
        bl_diag = c_rep1.selectbox("Bloque", list(bm.keys()), key="rep_bl_diag")
        if c_rep2.button("Ficha DT (PDF)", key="rep_dt_gen", type="secondary"):
            try:
                nombre_pdf, bytes_pdf = reports.generar_ficha_dt_bloque_pdf(bm[bl_diag])
                st.session_state["rep_diag_pdf"] = (bl_diag, nombre_pdf, bytes_pdf)
            except Exception as e:
                st.error(f"Error: {e}")
        if c_rep3.button("Ficha DS (PDF)", key="rep_ds_gen", type="secondary"):
            try:
                cp_rep = _cp_bloque(bl_diag)
                nombre_pdf, bytes_pdf = reports.generar_ficha_ds_bloque_pdf(
                    bm[bl_diag], datos_cp=cp_rep)
                st.session_state["rep_diag_pdf"] = (bl_diag, nombre_pdf, bytes_pdf)
            except Exception as e:
                st.error(f"Error: {e}")
        pdf_listo = st.session_state.get("rep_diag_pdf")
        if pdf_listo and pdf_listo[0] == bl_diag:
            st.download_button(f"⬇️ Descargar {pdf_listo[1]}", data=pdf_listo[2],
                               file_name=pdf_listo[1], mime="application/pdf",
                               key="rep_diag_dl")

        # Graficos y resumenes del Diagnostico Social, equivalentes a los que
        # el Diagnostico Territorial ya ofrece en sus resumenes por bloque.
        st.markdown("#### Gráficos y resúmenes del Diagnóstico Social")
        st.caption("Acompañan a la ficha DS: libro Excel con una hoja por "
                   "sección y gráficos nativos, y anexo gráfico en PDF. Los "
                   "gráficos interactivos están en **Diagnóstico Social → "
                   "Gráficos y Resúmenes**.")
        try:
            _ds_descargas_analitica(_ds_informe_bloque(bl_diag, bm[bl_diag]),
                                    f"rep_ds_graf_{bl_diag}")
        except Exception as exc:
            st.error(f"No se pudo preparar la analítica social del bloque "
                     f"{bl_diag}: {exc}")

        # ── Descarga masiva en ZIP ─────────────────────────────────────
        st.markdown("#### Descarga masiva (ZIP)")
        st.caption("Genera de una sola vez la ficha de varios bloques y las "
                   "entrega en un archivo ZIP, con una carpeta por tipo de ficha.")
        c_z1, c_z2, c_z3 = st.columns(3)
        ambito = c_z1.selectbox("Ambito", ["Todos los bloques", "Por zona",
                                           "Por provincia", "Por distrito"],
                                key="rep_zip_ambito")
        # La zona solo vive en el catalogo; provincia y distrito, en la BD.
        zona_por_codigo = {b[1]: (b[11] if len(b) > 11 else "") for b in BLOQUES_V5}
        bloques_bd = _cached_obtener_bloques(_cache_version())
        # Cada selector lleva su propia clave: compartirla haria que Streamlit
        # intentara restaurar, por ejemplo, una zona sobre la lista de provincias.
        if ambito == "Por zona":
            valor = c_z2.selectbox("Zona", ZONAS_V5, key="rep_zip_zona")
            seleccion = [b for b in bloques_bd
                         if zona_por_codigo.get(b["codigo"], "") == valor]
        elif ambito == "Por provincia":
            provs = sorted({(b.get("provincia") or "") for b in bloques_bd if b.get("provincia")})
            valor = c_z2.selectbox("Provincia", provs, key="rep_zip_prov")
            seleccion = [b for b in bloques_bd if (b.get("provincia") or "") == valor]
        elif ambito == "Por distrito":
            dists = sorted({(b.get("distrito") or "") for b in bloques_bd if b.get("distrito")})
            valor = c_z2.selectbox("Distrito", dists, key="rep_zip_dist")
            seleccion = [b for b in bloques_bd if (b.get("distrito") or "") == valor]
        else:
            c_z2.markdown("&nbsp;", unsafe_allow_html=True)
            valor = ""
            seleccion = list(bloques_bd)
        tipo_zip = c_z3.selectbox("Fichas", ["Territorial (DT)", "Social (DS)", "Ambas"],
                                  key="rep_zip_tipo")
        codigo_tipo = {"Territorial (DT)": "DT", "Social (DS)": "DS", "Ambas": "AMBAS"}[tipo_zip]
        firma_zip = (ambito, valor, codigo_tipo)
        st.caption(f"Se generaran fichas para **{len(seleccion)}** bloque(s).")
        if st.button("Generar ZIP de fichas", key="rep_zip_gen", type="secondary",
                     disabled=not seleccion):
            try:
                with st.spinner(f"Generando fichas de {len(seleccion)} bloque(s)..."):
                    nombre_zip, bytes_zip = reports.generar_zip_fichas_diagnostico(
                        [(b["codigo"], b["id"]) for b in seleccion],
                        tipo=codigo_tipo,
                        centros_poblados_map=CENTROS_POBLADOS_BLOQUE)
                st.session_state["rep_zip"] = (firma_zip, nombre_zip, bytes_zip)
            except Exception as e:
                st.error(f"Error al generar el ZIP: {e}")
        # Solo se ofrece la descarga si el ZIP corresponde al filtro vigente,
        # para no entregar un lote distinto al que se ve en pantalla.
        zip_listo = st.session_state.get("rep_zip")
        if zip_listo and zip_listo[0] == firma_zip:
            st.download_button(f"⬇️ Descargar {zip_listo[1]}", data=zip_listo[2],
                               file_name=zip_listo[1],
                               mime="application/zip", key="rep_zip_dl")
    st.markdown("---")
    st.markdown("### Respaldo completo de la base de datos (Excel)")
    st.caption("Volcado integro de todas las tablas del aplicativo (bloques, "
               "inspecciones, indicadores, diagnosticos territoriales y sociales, "
               "elementos expuestos, presupuesto, cronograma y personal), una hoja "
               "por tabla. Conviene descargarlo antes de cualquier borrado y de "
               "forma periodica. La lectura no modifica nada.")
    if st.button("Generar respaldo completo", key="rep_respaldo_gen"):
        try:
            with st.spinner("Leyendo todas las tablas..."):
                st.session_state["respaldo_bytes"] = \
                    exp_diag.exportar_respaldo_completo(db.respaldo_completo())
                st.session_state["respaldo_nombre"] = (
                    f"Respaldo_IN_Piura_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
            st.success("Respaldo generado.")
        except Exception as e:
            st.error(f"No se pudo generar el respaldo: {e}")
    if st.session_state.get("respaldo_bytes"):
        st.download_button(
            "⬇️ Descargar respaldo (Excel)",
            data=st.session_state["respaldo_bytes"],
            file_name=st.session_state["respaldo_nombre"],
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="rep_respaldo_dl")
    st.markdown("---")
    st.markdown("### Tabla Resumen (Excel)")
    if st.button("Generar Resumen Excel"):
        try:
            ruta = reports.generar_resumen_excel()
            with open(ruta,"rb") as f: data = f.read()
            st.download_button("Descargar Excel",data,os.path.basename(ruta),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.success("Excel generado.")
        except Exception as e: st.error(f"Error: {e}")
    st.markdown("---")
    st.markdown("### Tabla UTM para ArcGIS (Excel)")
    if st.button("Generar Excel ArcGIS"):
        try:
            ruta = reports.generar_excel_arcgis()
            with open(ruta,"rb") as f: data = f.read()
            st.download_button("Descargar Excel ArcGIS",data,os.path.basename(ruta),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.success("Archivo generado.")
        except Exception as e: st.error(f"Error: {e}")

# ══════════════════════════════════════════════════════════════════════════
# ROUTER
# ══════════════════════════════════════════════════════════════════════════
# == CONVERSOR PDF -> EXCEL ================================================
# Pegar este bloque completo en streamlit_app.py, antes del bloque ROUTER
# =========================================================================

def pagina_conversor_pdf():
    """Pagina de conversion de reportes PDF a Excel con formato ANIN."""

    st.subheader("Conversor PDF → Excel")
    st.caption(
        "Carga cualquier reporte PDF del proyecto, extrae sus tablas automaticamente, "
        "agrega coordenadas UTM WGS84 Zona 17S y genera un Excel con formato institucional ANIN."
    )

    if not PDF_CONV_OK:
        st.error(
            "El modulo pdf_converter no esta disponible. "
            "Verifica que pdf_converter.py este en el repositorio "
            "y que 'pdfplumber' y 'pyproj' esten en requirements.txt."
        )
        return

    # ── Panel de carga ─────────────────────────────────────────────────
    st.markdown("### 1. Cargar archivo PDF")

    col_upload, col_opts = st.columns([2, 1])

    with col_upload:
        pdf_file = st.file_uploader(
            "Selecciona el PDF a convertir (max. 25 MB)",
            type=["pdf"],
            key="pdfconv_upload",
        )

    with col_opts:
        st.markdown("**Opciones de conversion**")
        opt_dedup = st.checkbox(
            "Eliminar duplicados",
            value=True,
            key="pdfconv_dedup",
            help="Elimina filas duplicadas del resultado final.",
        )
        opt_solo_utm = st.checkbox(
            "Solo filas con coordenadas UTM validas",
            value=False,
            key="pdfconv_solo_utm",
            help="Filtra filas que no tienen coordenadas UTM validas.",
        )
        tipos_disponibles = [
            "Auto-detectar",
            "centros_poblados",
            "bloques_intervencion",
            "areas_conservacion",
            "catastro_minero",
            "areas_degradadas",
            "meteorologico",
            "generico",
        ]
        tipo_forzado = st.selectbox(
            "Tipo de reporte",
            tipos_disponibles,
            key="pdfconv_tipo",
            help="Selecciona manualmente si la deteccion automatica no es correcta.",
        )

    # ── Procesamiento ──────────────────────────────────────────────────
    if pdf_file is None:
        st.info("Carga un archivo PDF para comenzar.")
        _mostrar_tipos_soportados()
        return

    if pdf_file.size > 25 * 1024 * 1024:
        st.error("El archivo excede el limite de 25 MB.")
        return

    pdf_bytes    = pdf_file.read()
    nombre_pdf   = pdf_file.name
    forzar_tipo  = "" if tipo_forzado == "Auto-detectar" else tipo_forzado

    # Ejecutar extraccion con spinner
    with st.spinner(f"Extrayendo tablas de '{nombre_pdf}'..."):
        try:
            resultado = pdfconv.procesar_pdf(
                pdf_bytes,
                nombre_archivo=nombre_pdf,
                forzar_tipo=forzar_tipo,
            )
        except ImportError as e:
            st.error(f"Dependencia faltante: {e}. Agrega 'pdfplumber' a requirements.txt.")
            return
        except Exception as e:
            st.error(f"Error al procesar el PDF: {e}")
            return

    df         = resultado["df"]
    tipo_det   = resultado["tipo"]
    n_tablas   = resultado["n_tablas"]
    texto_prev = resultado["texto_prev"]

    # ── Panel de resultados ────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 2. Resultado de la extraccion")

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Tablas encontradas",  n_tablas)
    m2.metric("Registros extraidos", len(df))
    m3.metric("Columnas",            len(df.columns))
    m4.metric("Tipo detectado",      tipo_det.replace("_", " ").title())

    if df.empty:
        st.warning(
            "No se encontraron tablas estructuradas en el PDF. "
            "Verifica que el archivo no sea una imagen escaneada. "
            "Si es un PDF con texto seleccionable, prueba con tipo 'generico'."
        )
        if texto_prev:
            with st.expander("Texto extraido del PDF (primeros 600 caracteres)"):
                st.text(texto_prev)
        return

    # Validacion de coordenadas UTM
    validacion = pdfconv.validar_utm(df)
    if validacion["estado"] == "ok":
        cov = validacion["cobertura"]
        val = validacion["validos"]
        tot = validacion["total"]
        if val == tot:
            st.success(f"✅ Coordenadas UTM Zona 17S: {val}/{tot} registros validos ({cov})")
        elif val > 0:
            st.warning(
                f"⚠️ Coordenadas UTM Zona 17S: {val}/{tot} validas ({cov}). "
                f"{validacion['invalidos']} registros fuera del rango de la cuenca del Piura."
            )
        else:
            st.info("ℹ️ No se encontraron columnas de latitud/longitud para convertir a UTM.")
    else:
        st.info("ℹ️ El reporte no contiene columnas de coordenadas geograficas.")

    # Preview de la tabla
    st.markdown("**Vista previa (primeros 20 registros)**")
    st.dataframe(df.head(20), use_container_width=True, hide_index=True)

    # ── Generacion del Excel ───────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 3. Generar y descargar Excel")

    col_gen, col_info = st.columns([1, 2])

    with col_gen:
        nombre_salida = st.text_input(
            "Nombre del archivo de salida",
            value=nombre_pdf.replace(".pdf", "").replace(".PDF", "") + "_ANIN",
            key="pdfconv_nombre_salida",
        )
        hoja_nombre = st.text_input(
            "Nombre de la hoja de calculo",
            value=tipo_det.replace("_", " ").title()[:31],
            key="pdfconv_hoja",
        )
        btn_generar = st.button(
            "Generar Excel ANIN",
            type="primary",
            key="pdfconv_generar",
        )

    with col_info:
        st.markdown("**El Excel incluira:**")
        st.markdown(
            "- Encabezado institucional ANIN completo\n"
            "- Columnas UTM en verde (si corresponde)\n"
            "- Filas alternas para facilitar lectura\n"
            "- Fila de totales con suma de areas\n"
            "- Paneles congelados desde la fila de datos\n"
            "- Nota metodologica UTM WGS84 Zona 17S al pie"
        )

    if btn_generar:
        opciones = {
            "deduplicar":   opt_dedup,
            "solo_con_utm": opt_solo_utm,
            "hoja_nombre":  hoja_nombre,
        }
        with st.spinner("Generando Excel con formato ANIN..."):
            try:
                excel_bytes = pdfconv.generar_excel(
                    df,
                    tipo=tipo_det,
                    nombre_origen=nombre_pdf,
                    opciones=opciones,
                )
                nombre_xlsx = (nombre_salida.strip() or "reporte") + ".xlsx"

                st.download_button(
                    label=f"⬇️ Descargar {nombre_xlsx}",
                    data=excel_bytes,
                    file_name=nombre_xlsx,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="pdfconv_download",
                )
                st.success(
                    f"Excel generado: {len(df)} registros, "
                    f"{len(df.columns)} columnas, "
                    f"tipo '{tipo_det}'."
                )

                # Registrar conversion en historial (Supabase)
                _registrar_historial_conversion(
                    nombre_archivo=nombre_pdf,
                    tipo=tipo_det,
                    n_registros=len(df),
                    n_columnas=len(df.columns),
                    utm_ok=validacion["estado"] == "ok",
                )

            except Exception as e:
                st.error(f"Error al generar el Excel: {e}")

    # ── Historial de conversiones ──────────────────────────────────────
    st.markdown("---")
    st.markdown("### Historial de conversiones")
    _mostrar_historial()


def _mostrar_tipos_soportados():
    """Muestra un panel informativo de los tipos de reporte soportados."""
    with st.expander("Tipos de reporte soportados", expanded=False):
        st.markdown("""
| Tipo | Se detecta cuando el PDF contiene |
|---|---|
| **Centros Poblados** | columnas NOMCP, CPINEI, UBIGEO, coordenadas lat/lon |
| **Bloques de Intervencion** | codigos tipo M10B1, microcuenca, area_ha |
| **Areas de Conservacion** | ACR, ACP, denominacion, resolucion ministerial |
| **Catastro Minero** | concesion, titular, derecho minero |
| **Areas Degradadas** | categoria de degradacion, ecosistema, superficie |
| **Meteorologico** | estacion, precipitacion, temperatura, altitud |
| **Generico** | cualquier tabla estructurada (fallback) |

**Nota:** Si la deteccion automatica no es correcta, usa el selector de tipo en las opciones.
        """)


def _registrar_historial_conversion(nombre_archivo, tipo, n_registros,
                                    n_columnas, utm_ok):
    """Guarda un registro de la conversion en session_state (historial en memoria)."""
    if "pdfconv_historial" not in st.session_state:
        st.session_state["pdfconv_historial"] = []
    st.session_state["pdfconv_historial"].insert(0, {
        "Fecha/Hora":  datetime.now().strftime("%d/%m/%Y %H:%M"),
        "Archivo PDF": nombre_archivo,
        "Tipo":        tipo.replace("_", " ").title(),
        "Registros":   n_registros,
        "Columnas":    n_columnas,
        "UTM 17S":     "Si" if utm_ok else "No",
    })
    # Mantener solo los ultimos 20
    st.session_state["pdfconv_historial"] = st.session_state["pdfconv_historial"][:20]


def _mostrar_historial():
    """Muestra el historial de conversiones de la sesion actual."""
    historial = st.session_state.get("pdfconv_historial", [])
    if not historial:
        st.caption("Aun no hay conversiones en esta sesion.")
        return
    st.caption(f"Conversiones en esta sesion: {len(historial)}")
    st.dataframe(
        pd.DataFrame(historial),
        use_container_width=True,
        hide_index=True,
    )

# == FIN BLOQUE CONVERSOR ==


# ══════════════════════════════════════════════════════════════════════════
# MIGRACION MASIVA DE BLOQUES — RETIRADA DE LA INTERFAZ
# ══════════════════════════════════════════════════════════════════════════
# La pagina "Migracion V4 (temporal)" ejecutaba TRUNCATE TABLE bloques
# RESTART IDENTITY CASCADE, que borraba los bloques y, en cascada,
# inspecciones, diagnosticos territoriales y sociales, elementos expuestos,
# presupuesto e indicadores. Se retiro del menu por ese riesgo.
#
# El alta de bloques se hace ahora desde "Bloques de Intervencion ->
# Sincronizar catalogo de bloques", que es aditiva y cubre tambien el caso
# de una base vacia (inserta los 132 bloques del catalogo).
#
# Si alguna vez hiciera falta reconstruir el catalogo desde cero, el script
# `migrar_bloques_v5.py` sigue disponible para ejecutarse a mano desde una
# terminal, fuera del aplicativo.

# ══════════════════════════════════════════════════════════════════════════
# ROUTER
# ══════════════════════════════════════════════════════════════════════════
if pagina == "Panel de Control": pagina_dashboard()
elif pagina == "Bloques de Intervencion": pagina_bloques()
elif pagina == "Inspeccion de Campo": pagina_inspeccion()
elif pagina == "Indicadores de Calidad": pagina_indicadores()
elif pagina == "Diagnostico Territorial": pagina_diagnostico_territorial()
elif pagina == "Diagnostico Social": pagina_diagnostico_social()
elif pagina == "Elementos Expuestos (AdR)": pagina_elementos_expuestos()
elif pagina == "Presupuesto": pagina_presupuesto()
elif pagina == "Cronograma": pagina_cronograma()
elif pagina == "Georreferenciacion": pagina_georreferenciacion()
elif pagina == "ODK / KoBoToolbox": pagina_odk()
elif pagina == "Reportes": pagina_reportes()
elif pagina == "Conversor PDF -> Excel": pagina_conversor_pdf()
