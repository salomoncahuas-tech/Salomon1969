"""Pruebas del modulo ODK / KoBoToolbox (verificacion de campo, Paso 6).

database.py no puede importarse sin `st.secrets["DATABASE_URL"]`; aqui se
reemplaza por un modulo falso en memoria para probar la logica de
importacion sin tocar ninguna base de datos. Las sentencias SQL nuevas se
verifican estaticamente leyendo database.py como texto.
"""

import csv
import os
import re
import ssl
import sys
import tempfile
import types
import unittest

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

# ── Base de datos falsa ────────────────────────────────────────────────────
BLOQUES = [
    {"id": 1, "codigo": "M17B4", "microcuenca": "C1096-Q9556", "distrito": "Chulucanas",
     "utm_este": 604926.0, "utm_norte": 9444327.0, "area_hectareas": 124.71, "activo": 1},
    {"id": 2, "codigo": "25", "microcuenca": "C1096-Q9547", "distrito": "Chulucanas",
     "utm_este": 596578.0, "utm_norte": 9442453.0, "area_hectareas": 53.48, "activo": 1},
    {"id": 3, "codigo": "3", "microcuenca": "C1096-Q9545", "distrito": "Frias",
     "utm_este": 606816.0, "utm_norte": 9458469.0, "area_hectareas": 459.29, "activo": 1},
]
RETIRADO = {"id": 9, "codigo": "54", "distrito": "Frias", "utm_este": 0, "utm_norte": 0,
            "activo": 0}

fake_db = types.ModuleType("database")
fake_db.obtener_bloques = lambda: list(BLOQUES)
fake_db.obtener_bloque_por_codigo = lambda c: RETIRADO if c == "54" else None
fake_db.obtener_claves_verificacion_odk = lambda: set()
fake_db.registros = []


def _registrar(verif, insp=None, ind=None):
    if any(v["clave_envio"] == verif["clave_envio"] for v, _, _ in fake_db.registros):
        return {"estado": "duplicado", "verificacion_id": None, "inspeccion_id": None}
    fake_db.registros.append((verif, insp, ind))
    return {"estado": "nuevo", "verificacion_id": len(fake_db.registros),
            "inspeccion_id": 100 + len(fake_db.registros), "inspeccion_existente": False}


fake_db.registrar_verificacion_odk = _registrar
fake_db.guardar_adjunto_odk = lambda *a, **k: 1
sys.modules["database"] = fake_db

import odk_kobo as ok  # noqa: E402


def _envio(uuid="u1", codigo="25", gps="-5.1 -79.88 850 6", **extra):
    d = {"_uuid": uuid, "_id": 7,
         "g_identificacion/fecha_visita": "2026-09-20",
         "g_identificacion/inspector": "Ana Ruiz",
         "g_identificacion/codigo_bloque": codigo,
         "g_ubicacion/ubicacion_gps": gps,
         "g_accesibilidad/accesibilidad": "accesible",
         "g_social/riesgo_social_factores": "conflicto_tierras conflicto_agua",
         "g_resultado/dictamen": "apto"}
    d.update(extra)
    return d


class TestCoordenadas(unittest.TestCase):

    def test_utm_17s_coincide_con_referencia(self):
        # Valores de referencia EPSG:32717 (pyproj)
        e, n = ok.latlon_a_utm17s(-5.3456, -79.6123)
        self.assertAlmostEqual(e, 653764.029, places=2)
        self.assertAlmostEqual(n, 9408959.897, places=2)

    def test_rango_ambito(self):
        self.assertTrue(ok.utm_en_rango(600000, 9450000))
        self.assertFalse(ok.utm_en_rango(449999, 9450000))
        self.assertFalse(ok.utm_en_rango(600000, 9600001))
        self.assertFalse(ok.utm_en_rango(None, None))

    def test_geopoint_texto_y_columnas(self):
        self.assertEqual(ok._parsear_geopoint({"ubicacion_gps": "-5.1 -79.8 900 4"})[:2],
                         (-5.1, -79.8))
        cols = {"_ubicacion_gps_latitude": "-5.2", "_ubicacion_gps_longitude": "-79.7",
                "_ubicacion_gps_precision": "3"}
        self.assertEqual(ok._parsear_geopoint(cols), (-5.2, -79.7, None, 3.0))


class TestPreparacion(unittest.TestCase):

    def setUp(self):
        self.cat = ok.CatalogoBloques(BLOQUES)

    def test_gps_manda_sobre_utm_digitada(self):
        p = ok.preparar_envio(_envio(**{"g_ubicacion/utm_este_ref": "600000",
                                        "g_ubicacion/utm_norte_ref": "9450000"}), self.cat)
        v = p["verificacion"]
        self.assertEqual(v["utm_fuente"], "gps")
        self.assertEqual(v["utm_este_manual"], 600000.0)
        self.assertNotAlmostEqual(v["utm_este"], 600000.0, places=0)
        self.assertTrue(any("difieren" in a for a in p["alertas"]))

    def test_sin_gps_usa_utm_manual_con_alerta(self):
        p = ok.preparar_envio(_envio(gps="", utm_este="596578", utm_norte="9442453"), self.cat)
        self.assertEqual(p["verificacion"]["utm_fuente"], "manual")
        self.assertEqual(p["verificacion"]["coord_valida"], 1)

    def test_fuera_de_rango_marcado(self):
        p = ok.preparar_envio(_envio(gps="-1.0 -75.0 0 5"), self.cat)
        self.assertEqual(p["verificacion"]["coord_valida"], 0)
        self.assertTrue(any("fuera de rango" in a for a in p["alertas"]))

    def test_bloque_inexistente_y_retirado_se_rechazan(self):
        self.assertEqual(ok.preparar_envio(_envio(codigo="ZZZ"), self.cat)["estado"], "error")
        p = ok.preparar_envio(_envio(codigo="54"), self.cat)
        self.assertEqual(p["estado"], "error")
        self.assertIn("retirado", p["errores"][0])

    def test_codigo_otro_y_mayusculas(self):
        p = ok.preparar_envio(_envio(codigo="otro", **{
            "g_identificacion/codigo_bloque_otro": "m17b4"}), self.cat)
        self.assertEqual(p["estado"], "listo")
        self.assertEqual(p["verificacion"]["codigo_bloque"], "M17B4")

    def test_etiquetas_select_multiple(self):
        p = ok.preparar_envio(_envio(), self.cat)
        self.assertEqual(p["verificacion"]["riesgo_social_factores"],
                         "Conflicto por tierras / linderos; Conflicto por uso de agua")

    def test_alertas_criterios(self):
        p = ok.preparar_envio(_envio(**{"g_titulares/n_predios": "25",
                                        "g_suelo/agricultura_activa": "si"}), self.cat)
        texto = " ".join(p["alertas"])
        self.assertIn("predios", texto)
        self.assertIn("agricultura activa", texto)

    def test_nunca_incluye_datos_de_bloque_para_actualizar(self):
        # Campos del formulario anterior (tipo, area, estado) se ignoran.
        p = ok.preparar_envio(_envio(area_hectareas="", estado="verificado",
                                     tipo_intervencion="revegetacion"), self.cat)
        self.assertNotIn("area_hectareas", p["verificacion"])
        self.assertNotIn("estado", p["verificacion"])


class TestDeduplicacion(unittest.TestCase):

    def test_repetidos_en_lote_y_ya_importados(self):
        prep = ok.preparar_envios([_envio("a"), _envio("a"), _envio("b")],
                                  catalogo=ok.CatalogoBloques(BLOQUES),
                                  claves_existentes={"b"})
        self.assertEqual([p["estado"] for p in prep], ["listo", "duplicado", "duplicado"])

    def test_huella_estable_sin_uuid(self):
        e = {"codigo_bloque": "25", "fecha_visita": "2026-09-01", "inspector": "Luis"}
        self.assertEqual(ok._clave_envio(dict(e)), ok._clave_envio(dict(e)))
        self.assertTrue(ok._clave_envio(e).startswith("hash:"))

    def test_registrar_dos_veces_no_duplica(self):
        fake_db.registros.clear()
        cat = ok.CatalogoBloques(BLOQUES)
        r1 = ok.registrar_envios(ok.preparar_envios([_envio("x1")], catalogo=cat,
                                                    claves_existentes=set()))
        r2 = ok.registrar_envios(ok.preparar_envios([_envio("x1")], catalogo=cat,
                                                    claves_existentes=set()))
        self.assertEqual(r1["verificaciones_nuevas"], 1)
        self.assertEqual(r2["duplicados_omitidos"], 1)
        self.assertEqual(len(fake_db.registros), 1)


class TestClienteKobo(unittest.TestCase):

    def test_ssl_siempre_verificado(self):
        c = ok.KoBoClient("https://kf.kobotoolbox.org", "t")
        self.assertEqual(c.ssl_context.verify_mode, ssl.CERT_REQUIRED)
        self.assertTrue(c.ssl_context.check_hostname)

    def test_rechaza_http_y_otros_dominios(self):
        with self.assertRaises(ValueError):
            ok.KoBoClient("http://kf.kobotoolbox.org", "t")
        c = ok.KoBoClient("https://kf.kobotoolbox.org", "t")
        self.assertTrue(c._url_permitida("https://kc.kobotoolbox.org/media/x.jpg"))
        self.assertFalse(c._url_permitida("https://evil.example.com/x"))
        self.assertFalse(c._url_permitida("http://kf.kobotoolbox.org/x"))

    def test_paginacion_trae_todo(self):
        datos = [{"_uuid": str(i)} for i in range(2350)]
        llamadas = []

        class C(ok.KoBoClient):
            def _get_json(self, endpoint, params=None):
                llamadas.append(dict(params))
                ini, lim = params["start"], params["limit"]
                return {"count": len(datos), "results": datos[ini:ini + lim],
                        "next": "x" if ini + lim < len(datos) else None}

        envios = C("https://kf.kobotoolbox.org", "t").obtener_envios("aUID")
        self.assertEqual(len(envios), 2350)
        self.assertEqual([c["start"] for c in llamadas], [0, 1000, 2000])
        self.assertTrue(all(c["limit"] <= 1000 for c in llamadas))


class TestArchivos(unittest.TestCase):

    def test_csv_punto_y_coma(self):
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False,
                                         encoding="utf-8", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["codigo_bloque", "inspector"])
            w.writerow(["25", "Luis"])
            ruta = f.name
        try:
            self.assertEqual(ok.leer_archivo_odk(ruta),
                             [{"codigo_bloque": "25", "inspector": "Luis"}])
        finally:
            os.unlink(ruta)


class TestFormulario(unittest.TestCase):

    def test_xlsform_convierte(self):
        try:
            from pyxform.xls2xform import convert
        except ImportError:
            self.skipTest("pyxform no instalado")
        with tempfile.TemporaryDirectory() as d:
            for bloques in (BLOQUES, None):
                ruta = ok.generar_xlsform(os.path.join(d, "f.xlsx"), bloques=bloques)
                xml = convert(xlsform=ruta).xform
                for campo in ("accesibilidad", "riesgo_social", "uso_suelo_predominante",
                              "evidencia_mm", "aceptacion_titular", "dictamen",
                              "ubicacion_gps"):
                    self.assertIn(campo, xml)

    def test_lista_cerrada_de_bloques(self):
        filas_d, filas_b = ok._opciones_bloques(BLOQUES)
        nombres = [n for _, n, _, _ in filas_b]
        self.assertIn("M17B4", nombres)
        self.assertIn("otro", nombres)
        distritos = [n for _, n, _, _ in filas_d]
        self.assertGreaterEqual(len(distritos), 15)
        self.assertIn("san_miguel_de_el_faique", distritos)


class TestSqlNoDestructivo(unittest.TestCase):
    """La seccion nueva de database.py no borra ni altera datos existentes."""

    @classmethod
    def setUpClass(cls):
        fuente = open(os.path.join(RAIZ, "database.py"), encoding="utf-8").read()
        # Funciones nuevas: desde VERIF_ODK_COLUMNAS hasta el final del archivo
        cls.seccion = fuente[fuente.index("VERIF_ODK_COLUMNAS = ("):]
        # Migracion nueva dentro de inicializar_bd()
        j = fuente.index("CREATE TABLE IF NOT EXISTS verificacion_campo_odk")
        cls.migracion = fuente[j:fuente.index("conn.commit()", j)]

    def test_sin_delete_drop_truncate(self):
        for texto in (self.seccion, self.migracion):
            self.assertIsNone(re.search(r"(?<!ON )\b(DELETE|DROP|TRUNCATE)\b", texto, re.I))

    def test_no_actualiza_bloques_ni_inspecciones(self):
        self.assertIsNone(re.search(r"UPDATE\s+(bloques|inspecciones|indicadores_calidad)\b",
                                    self.seccion, re.I))

    def test_llaves_foraneas_sin_cascade(self):
        self.assertNotIn("CASCADE", self.migracion)
        self.assertIn("ON DELETE SET NULL", self.migracion)


if __name__ == "__main__":
    unittest.main()
